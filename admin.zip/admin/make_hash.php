<?php
echo password_hash("Sura12,3#@!", PASSWORD_DEFAULT);
