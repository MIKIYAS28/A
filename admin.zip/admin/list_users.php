<?php
require_once '../db.php';
header('Content-Type: application/json');
$rows=$pdo->query('SELECT * FROM users ORDER BY joined_at DESC')->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($rows);