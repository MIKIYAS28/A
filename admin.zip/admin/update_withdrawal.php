<?php
header('Content-Type: application/json');
require_once 'db_connection.php';

// Admin authentication
if (!isset($_SERVER['PHP_AUTH_USER']) || 
    $_SERVER['PHP_AUTH_USER'] !== 'admin' || 
    $_SERVER['PHP_AUTH_PW'] !== 'your_secure_password') {
    header('WWW-Authenticate: Basic realm="Admin Dashboard"');
    header('HTTP/1.0 401 Unauthorized');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['id']) || !isset($data['status'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE withdrawal_requests 
        SET status = :status
        WHERE id = :id
    ");
    
    $stmt->execute([
        ':id' => $data['id'],
        ':status' => $data['status']
    ]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Record not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
}
?>
