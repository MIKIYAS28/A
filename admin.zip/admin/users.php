<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
$adminUsername = $_SESSION['username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ---- Admin-only access check (optional but recommended) ---- */
        :root {
            --primary: #4a90e2;
            --secondary: #357abd;
            --accent: #ff6b6b;
            --dark: #1a202c;
            --light: #f7fafc;
            --success: #48bb78;
            --warning: #ecc94b;
            --danger: #e53e3e;
            --gray: #718096;
            --gray-light: #e2e8f0;
            --sidebar-width: 260px;
            --header-height: 70px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: var(--dark);
            display: flex;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
            transition: all 0.3s;
            z-index: 100;
        }

        .logo {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .nav-links {
            padding: 0 15px;
        }

        .nav-links li {
            list-style: none;
            margin-bottom: 5px;
        }

        .nav-links a {
            color: #cbd5e0;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            transition: all 0.3s;
        }

        .nav-links a:hover, .nav-links a.active {
            background: rgba(74, 144, 226, 0.2);
            color: white;
        }

        .nav-links i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
        }

        /* Header Styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .header-actions {
            display: flex;
            gap: 15px;
        }

        .search-box {
            position: relative;
        }

        .search-box input {
            padding: 10px 15px 10px 40px;
            border-radius: 50px;
            border: 1px solid var(--gray-light);
            width: 250px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        .user-info h4 {
            font-size: 15px;
            font-weight: 600;
        }

        .user-info p {
            font-size: 13px;
            color: var(--gray);
        }

        /* Stats Section */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .stat-info h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: var(--gray);
            font-size: 14px;
        }

        .bg-blue {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
        }

        .bg-green {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success);
        }

        .bg-orange {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .bg-red {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        .bg-purple {
            background: rgba(159, 122, 234, 0.1);
            color: #9f7aea;
        }

        /* Charts Section */
        .charts-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .chart-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-title h3 {
            font-size: 18px;
            font-weight: 600;
        }

        .chart-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .chart-controls {
            display: flex;
            gap: 10px;
        }

        .chart-btn {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            background: var(--gray-light);
            border: none;
            cursor: pointer;
        }

        .chart-btn.active {
            background: var(--primary);
            color: white;
        }

        .chart-wrapper {
            height: 250px;
            position: relative;
        }

        /* User Table Section */
        .users-container {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .controls {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            border: none;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--secondary);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--gray-light);
            color: var(--gray);
        }

        .btn-outline:hover {
            background: var(--gray-light);
        }

        .filter-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-group label {
            font-size: 14px;
            color: var(--gray);
            font-weight: 500;
        }

        .filter-group select, .filter-group input {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid var(--gray-light);
            background: white;
            min-width: 150px;
        }

        .filter-group input {
            padding-left: 35px;
        }

        .search-control {
            position: relative;
        }

        .search-control i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8fafc;
            border-bottom: 2px solid var(--gray-light);
        }

        th {
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 14px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid var(--gray-light);
            font-size: 14px;
        }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--gray-light);
            overflow: hidden;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            background-color: var(--primary);
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            margin-bottom: 3px;
        }

        .user-email {
            color: var(--gray);
            font-size: 13px;
        }

        .status {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
        }

        .status-active {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success);
        }

        .status-inactive {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        .status-pending {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .role {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
        }

        .role-admin {
            background: rgba(159, 122, 234, 0.1);
            color: #9f7aea;
        }

        .role-content-creator {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
        }

        .role-viewer {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .role-moderator {
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            background: transparent;
            color: var(--gray);
        }

        .action-btn:hover {
            background: var(--gray-light);
            color: var(--dark);
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--gray-light);
        }

        .page-info {
            color: var(--gray);
            font-size: 14px;
        }

        .page-controls {
            display: flex;
            gap: 8px;
        }

        .page-btn {
            width: 36px;
            height: 36px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border: 1px solid var(--gray-light);
            cursor: pointer;
            transition: all 0.3s;
        }

        .page-btn:hover, .page-btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        /* User Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .modal-header {
            padding: 20px;
            background: var(--primary);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            font-size: 18px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background 0.3s;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.2);
        }

        .modal-body {
            padding: 20px;
            max-height: 70vh;
            overflow-y: auto;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border-radius: 6px;
            border: 1px solid var(--gray-light);
            font-size: 14px;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .modal-footer {
            padding: 15px 20px;
            background: #f8fafc;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid var(--gray-light);
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
            }
            
            .logo h1 span, .nav-links a span {
                display: none;
            }
            
            .logo h1 {
                justify-content: center;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 12px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .search-box input {
                width: 100%;
            }
            
            .stats-container {
                grid-template-columns: 1fr 1fr;
            }
            
            .filter-controls {
                flex-direction: column;
            }
            
            .controls {
                flex-wrap: wrap;
            }
            
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .page-controls {
                display: none;
            }
            
            .pagination {
                justify-content: center;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <h1><i class="fas fa-play-circle"></i> <span>VideoDash</span></h1>
        </div>
        <ul class="nav-links">
            <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="add_video.php"><i class="fas fa-video"></i> <span>Videos</span></a></li>
            <li><a href="users.php" class="active"><i class="fas fa-users"></i> <span>Users</span></a></li>
            <li><a href="new-users.php"><i class="fas fa-user-plus"></i> <span>New Users</span></a></li>
            <li><a href="analytics.php"><i class="fas fa-chart-line"></i> <span>Analytics</span></a></li>
            <li><a href="redemptions.php"><i class="fas fa-gift"></i> <span>Redemptions</span></a></li>
            <li><a href="tasks.php"><i class="fas fa-tasks"></i> <span>Tasks</span></a></li>
            <li><a href="rewards.php"><i class="fas fa-coins"></i> <span>Rewards</span></a></li>
            <li><a href="setting.php"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
            <li><a href="security.php"><i class="fas fa-lock"></i> <span>Security</span></a></li>
            <li><a href="alerts.php"><i class="fas fa-exclamation-triangle"></i> <span>Alerts</span></a></li>
            <li><a href="database.php"><i class="fas fa-database"></i> <span>Database</span></a></li>
            <li><a href="integration.php"><i class="fas fa-plug"></i> <span>Integrations</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <h1>User Management</h1>
                <p>Manage and analyze your user base</p>
            </div>
            <div class="header-actions">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search users...">
                </div>
                <div class="user-profile">
                    <img src="https://randomuser.me/api/portraits/men/41.jpg" alt="Admin">
                    <div class="user-info">
                        <h4><?= htmlspecialchars($adminUsername) ?></h4>
                        <p>User Manager</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Section - Updated to use API data -->
        <div class="stats-container" id="statsContainer">
            <!-- Stats will be populated dynamically via AJAX -->
        </div>

        <!-- Charts Section -->
        <div class="charts-container">
            <!-- User Acquisition Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <h3>User Acquisition</h3>
                        <p>New users over time</p>
                    </div>
                    <div class="chart-controls">
                        <button class="chart-btn active" data-period="30">30 Days</button>
                        <button class="chart-btn" data-period="90">90 Days</button>
                        <button class="chart-btn" data-period="365">1 Year</button>
                    </div>
                </div>
                <div class="chart-wrapper">
                    <canvas id="acquisitionChart"></canvas>
                </div>
            </div>
            
            <!-- User Roles Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <h3>User Roles</h3>
                        <p>Distribution by role</p>
                    </div>
                </div>
                <div class="chart-wrapper">
                    <canvas id="rolesChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Users Table Section -->
        <div class="users-container">
            <div class="section-header">
                <div class="section-title">
                    <h2>All Users</h2>
                    <p>Manage platform users</p>
                </div>
                <div class="controls">
                    <button class="btn btn-outline" id="exportBtn">
                        <i class="fas fa-download"></i> Export
                    </button>
                    <button class="btn btn-primary" id="addUserBtn">
                        <i class="fas fa-user-plus"></i> Add User
                    </button>
                </div>
            </div>

            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-group">
                    <label>Status</label>
                    <select id="statusFilter">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="pending">Pending</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Role</label>
                    <select id="roleFilter">
                        <option value="">All Roles</option>
                        <option value="admin">Admin</option>
                        <option value="content-creator">Content Creator</option>
                        <option value="viewer">Viewer</option>
                        <option value="moderator">Moderator</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Join Date</label>
                    <select id="dateFilter">
                        <option value="">All Time</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="month">This Month</option>
                        <option value="year">This Year</option>
                    </select>
                </div>
                <div class="filter-group search-control">
                    <label>Search Users</label>
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search by name or email" id="userSearch">
                </div>
            </div>

            <!-- Users Table -->
            <div class="table-container">
                <table id="usersTable">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>User ID</th>
                            <th>Role</th>
                            <th>Join Date</th>
                            <th>Videos Watched</th>
                            <th>Points</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <!-- Users will be populated dynamically -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="pagination">
                <div class="page-info" id="pageInfo">
                    Showing <span id="startRange">1</span> to <span id="endRange">10</span> of <span id="totalUsers">100</span> users
                </div>
                <div class="page-controls" id="pageControls">
                    <!-- Pagination controls will be generated dynamically -->
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div class="modal" id="userModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Add New User</h3>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="userForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    <input type="hidden" name="user_id" id="userId" value="">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="firstName">First Name</label>
                            <input type="text" id="firstName" name="first_name" required>
                        </div>
                        <div class="form-group">
                            <label for="lastName">Last Name</label>
                            <input type="text" id="lastName" name="last_name" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="role">Role</label>
                            <select id="role" name="role" required>
                                <option value="viewer">Viewer</option>
                                <option value="content-creator">Content Creator</option>
                                <option value="moderator">Moderator</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password">
                            <small id="passwordHint">Leave blank to keep current password (for editing)</small>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="pending">Pending</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="points">Points</label>
                        <input type="number" id="points" name="points" min="0" value="0">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" id="cancelBtn">Cancel</button>
                <button class="btn btn-primary" id="saveUserBtn">Save User</button>
            </div>
        </div>
    </div>

    <script>
        // Sample data for demonstration - In production, this would come from your database
        let users = [
            {
                id: 1,
                firstName: "John",
                lastName: "Doe",
                email: "john.doe@example.com",
                username: "johndoe",
                role: "admin",
                joinDate: "2023-01-15",
                videosWatched: 125,
                points: 1500,
                status: "active"
            },
            {
                id: 2,
                firstName: "Jane",
                lastName: "Smith",
                email: "jane.smith@example.com",
                username: "janesmith",
                role: "content-creator",
                joinDate: "2023-02-20",
                videosWatched: 87,
                points: 950,
                status: "active"
            },
            {
                id: 3,
                firstName: "Mike",
                lastName: "Johnson",
                email: "mike.johnson@example.com",
                username: "mikej",
                role: "viewer",
                joinDate: "2023-03-10",
                videosWatched: 42,
                points: 420,
                status: "inactive"
            },
            {
                id: 4,
                firstName: "Sarah",
                lastName: "Williams",
                email: "sarah.w@example.com",
                username: "sarahw",
                role: "moderator",
                joinDate: "2023-04-05",
                videosWatched: 65,
                points: 780,
                status: "active"
            },
            {
                id: 5,
                firstName: "David",
                lastName: "Brown",
                email: "david.brown@example.com",
                username: "davidb",
                role: "viewer",
                joinDate: "2023-05-12",
                videosWatched: 23,
                points: 320,
                status: "pending"
            }
        ];

        // DOM Elements
        const usersTableBody = document.getElementById('usersTableBody');
        const userModal = document.getElementById('userModal');
        const closeModal = document.getElementById('closeModal');
        const addUserBtn = document.getElementById('addUserBtn');
        const cancelBtn = document.getElementById('cancelBtn');
        const saveUserBtn = document.getElementById('saveUserBtn');
        const userForm = document.getElementById('userForm');
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const roleFilter = document.getElementById('roleFilter');
        const dateFilter = document.getElementById('dateFilter');
        const userSearch = document.getElementById('userSearch');
        const exportBtn = document.getElementById('exportBtn');
        const pageInfo = document.getElementById('pageInfo');
        const pageControls = document.getElementById('pageControls');
        const modalTitle = document.getElementById('modalTitle');
        const passwordHint = document.getElementById('passwordHint');

        // Current page and items per page for pagination
        let currentPage = 1;
        const itemsPerPage = 10;

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Load stats and render charts
            loadStats();
            initCharts();
            
            // Render users table with pagination
            renderUsersTable();
            updatePagination();
            
            // Modal functionality
            addUserBtn.addEventListener('click', () => {
                openUserModal();
            });

            closeModal.addEventListener('click', () => {
                userModal.style.display = 'none';
            });

            cancelBtn.addEventListener('click', () => {
                userModal.style.display = 'none';
            });

            saveUserBtn.addEventListener('click', saveUser);
            
            // Export functionality
            exportBtn.addEventListener('click', () => {
                alert('User data exported successfully!');
            });

            // Search and filter functionality
            searchInput.addEventListener('input', filterUsers);
            statusFilter.addEventListener('change', filterUsers);
            roleFilter.addEventListener('change', filterUsers);
            dateFilter.addEventListener('change', filterUsers);
            userSearch.addEventListener('input', filterUsers);
            
            // Fetch user data from API (simulation)
            fetchUsers();
        });

        function fetchUsers() {
            // In a real application, this would fetch data from your API
            // Simulating a server request
            setTimeout(() => {
                // We're using the sample data for demonstration
                updateStats();
                renderUsersTable();
                updatePagination();
            }, 500);
        }

        function loadStats() {
            // Simulating an API call to get user statistics
            const statsContainer = document.getElementById('statsContainer');
            
            // Calculate statistics
            const totalUsers = users.length;
            const activeUsers = users.filter(user => user.status === 'active').length;
            const totalPoints = users.reduce((sum, user) => sum + user.points, 0);
            const totalVideosWatched = users.reduce((sum, user) => sum + user.videosWatched, 0);
            
            statsContainer.innerHTML = `
                <div class="stat-card">
                    <div class="stat-icon bg-blue">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <h3>${totalUsers}</h3>
                        <p>Total Users</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon bg-green">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-info">
                        <h3>${activeUsers}</h3>
                        <p>Active Users</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon bg-orange">
                        <i class="fas fa-coins"></i>
                    </div>
                    <div class="stat-info">
                        <h3>${totalPoints.toLocaleString()}</h3>
                        <p>Total Points</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon bg-purple">
                        <i class="fas fa-video"></i>
                    </div>
                    <div class="stat-info">
                        <h3>${totalVideosWatched.toLocaleString()}</h3>
                        <p>Videos Watched</p>
                    </div>
                </div>
            `;
        }

        function initCharts() {
            // User Acquisition Chart
            const acquisitionCtx = document.getElementById('acquisitionChart').getContext('2d');
            new Chart(acquisitionCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: [{
                        label: 'New Users',
                        data: [12, 19, 15, 22, 18, 25, 30, 28, 22, 35, 40, 45],
                        backgroundColor: 'rgba(74, 144, 226, 0.2)',
                        borderColor: 'rgba(74, 144, 226, 1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
            
            // User Roles Chart
            const rolesCtx = document.getElementById('rolesChart').getContext('2d');
            new Chart(rolesCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Viewers', 'Content Creators', 'Moderators', 'Admins'],
                    datasets: [{
                        data: [65, 20, 10, 5],
                        backgroundColor: [
                            '#ecc94b',
                            '#4a90e2',
                            '#667eea',
                            '#9f7aea'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    cutout: '70%'
                }
            });
        }

        function renderUsersTable() {
            // Filter users based on current filters
            const filteredUsers = filterUsersList();
            
            // Calculate pagination
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, filteredUsers.length);
            const paginatedUsers = filteredUsers.slice(startIndex, endIndex);
            
            // Update page info
            document.getElementById('startRange').textContent = filteredUsers.length > 0 ? startIndex + 1 : 0;
            document.getElementById('endRange').textContent = endIndex;
            document.getElementById('totalUsers').textContent = filteredUsers.length;
            
            usersTableBody.innerHTML = '';
            
            if (paginatedUsers.length === 0) {
                usersTableBody.innerHTML = `
                    <tr>
                        <td colspan="8" class="text-center">No users found matching your criteria</td>
                    </tr>
                `;
                return;
            }
            
            paginatedUsers.forEach(user => {
                const row = document.createElement('tr');
                
                // Create user initials for avatar if no image
                const initials = user.firstName.charAt(0) + user.lastName.charAt(0);
                
                row.innerHTML = `
                    <td>
                        <div class="user-cell">
                            <div class="user-avatar">
                                ${initials}
                            </div>
                            <div class="user-info">
                                <div class="user-name">${user.firstName} ${user.lastName}</div>
                                <div class="user-email">${user.email}</div>
                            </div>
                        </div>
                    </td>
                    <td>${user.id}</td>
                    <td><span class="role role-${user.role}">${formatRole(user.role)}</span></td>
                    <td>${formatDate(user.joinDate)}</td>
                    <td>${user.videosWatched}</td>
                    <td>${user.points.toLocaleString()}</td>
                    <td><span class="status status-${user.status}">${capitalizeFirstLetter(user.status)}</span></td>
                    <td>
                        <button class="action-btn" onclick="editUser(${user.id})"><i class="fas fa-edit"></i></button>
                        <button class="action-btn" onclick="deleteUser(${user.id})"><i class="fas fa-trash"></i></button>
                        <button class="action-btn" onclick="viewUserDetails(${user.id})"><i class="fas fa-eye"></i></button>
                    </td>
                `;
                
                usersTableBody.appendChild(row);
            });
        }

        function updatePagination() {
            const filteredUsers = filterUsersList();
            const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
            
            let paginationHTML = `
                <div class="page-btn" onclick="changePage(${Math.max(1, currentPage - 1)})">
                    <i class="fas fa-chevron-left"></i>
                </div>
            `;
            
            // Generate page buttons
            for (let i = 1; i <= Math.min(totalPages, 5); i++) {
                paginationHTML += `
                    <div class="page-btn ${i === currentPage ? 'active' : ''}" onclick="changePage(${i})">
                        ${i}
                    </div>
                `;
            }
            
            // Add ellipsis if there are more pages
            if (totalPages > 5) {
                paginationHTML += `
                    <div class="page-btn">
                        <i class="fas fa-ellipsis-h"></i>
                    </div>
                    <div class="page-btn" onclick="changePage(${totalPages})">
                        ${totalPages}
                    </div>
                `;
            }
            
            paginationHTML += `
                <div class="page-btn" onclick="changePage(${Math.min(totalPages, currentPage + 1)})">
                    <i class="fas fa-chevron-right"></i>
                </div>
            `;
            
            pageControls.innerHTML = paginationHTML;
        }

        function changePage(page) {
            currentPage = page;
            renderUsersTable();
            updatePagination();
        }

        function filterUsersList() {
            const searchTerm = searchInput.value.toLowerCase();
            const statusValue = statusFilter.value.toLowerCase();
            const roleValue = roleFilter.value.toLowerCase();
            const dateValue = dateFilter.value.toLowerCase();
            const userSearchTerm = userSearch.value.toLowerCase();
            
            return users.filter(user => {
                // Main search
                const matchesSearch = 
                    user.firstName.toLowerCase().includes(searchTerm) || 
                    user.lastName.toLowerCase().includes(searchTerm) || 
                    user.email.toLowerCase().includes(searchTerm) ||
                    user.username.toLowerCase().includes(searchTerm);
                
                // Status filter
                const matchesStatus = !statusValue || user.status === statusValue;
                
                // Role filter
                const matchesRole = !roleValue || user.role === roleValue;
                
                // User search
                const matchesUserSearch = 
                    user.firstName.toLowerCase().includes(userSearchTerm) || 
                    user.lastName.toLowerCase().includes(userSearchTerm) || 
                    user.email.toLowerCase().includes(userSearchTerm) ||
                    user.username.toLowerCase().includes(userSearchTerm);
                
                // Date filter (simplified for demo)
                let matchesDate = true;
                if (dateValue) {
                    const joinDate = new Date(user.joinDate);
                    const now = new Date();
                    
                    if (dateValue === 'today') {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        matchesDate = joinDate >= today;
                    } else if (dateValue === 'week') {
                        const weekAgo = new Date();
                        weekAgo.setDate(weekAgo.getDate() - 7);
                        matchesDate = joinDate >= weekAgo;
                    } else if (dateValue === 'month') {
                        const monthAgo = new Date();
                        monthAgo.setMonth(monthAgo.getMonth() - 1);
                        matchesDate = joinDate >= monthAgo;
                    } else if (dateValue === 'year') {
                        const yearAgo = new Date();
                        yearAgo.setFullYear(yearAgo.getFullYear() - 1);
                        matchesDate = joinDate >= yearAgo;
                    }
                }
                
                return matchesSearch && matchesStatus && matchesRole && matchesUserSearch && matchesDate;
            });
        }

        function filterUsers() {
            currentPage = 1; // Reset to first page
            renderUsersTable();
            updatePagination();
        }

        function openUserModal(user = null) {
            const isEdit = !!user;
            
            // Set modal title
            modalTitle.textContent = isEdit ? 'Edit User' : 'Add New User';
            
            // Clear the form
            userForm.reset();
            
            // If editing, populate form with user data
            if (isEdit) {
                document.getElementById('userId').value = user.id;
                document.getElementById('firstName').value = user.firstName;
                document.getElementById('lastName').value = user.lastName;
                document.getElementById('email').value = user.email;
                document.getElementById('username').value = user.username;
                document.getElementById('role').value = user.role;
                document.getElementById('status').value = user.status;
                document.getElementById('points').value = user.points;
                
                // Show password hint for edit mode
                passwordHint.style.display = 'block';
            } else {
                document.getElementById('userId').value = '';
                
                // Hide password hint for new user
                passwordHint.style.display = 'none';
            }
            
            // Show modal
            userModal.style.display = 'flex';
        }

        function saveUser() {
            const formData = new FormData(userForm);
            const userId = formData.get('user_id');
            
            // In a real app, you would submit this to your backend
            // For demo, we'll update the users array directly
            
            const userData = {
                id: userId ? parseInt(userId) : users.length + 1,
                firstName: formData.get('first_name'),
                lastName: formData.get('last_name'),
                email: formData.get('email'),
                username: formData.get('username'),
                role: formData.get('role'),
                status: formData.get('status'),
                points: parseInt(formData.get('points')),
                joinDate: userId ? getUserById(userId).joinDate : new Date().toISOString().split('T')[0],
                videosWatched: userId ? getUserById(userId).videosWatched : 0
            };
            
            if (userId) {
                // Update existing user
                const index = users.findIndex(u => u.id === parseInt(userId));
                if (index !== -1) {
                    users[index] = userData;
                }
            } else {
                // Add new user
                users.push(userData);
            }
            
            // Update UI
            loadStats();
            renderUsersTable();
            updatePagination();
            
            // Close modal
            userModal.style.display = 'none';
            
            // Show success message
            alert(`User ${userId ? 'updated' : 'added'} successfully!`);
        }

        function editUser(userId) {
            const user = getUserById(userId);
            if (user) {
                openUserModal(user);
            }
        }

        function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user?')) {
                const index = users.findIndex(u => u.id === userId);
                if (index !== -1) {
                    users.splice(index, 1);
                    
                    // Update UI
                    loadStats();
                    renderUsersTable();
                    updatePagination();
                    
                    alert('User deleted successfully!');
                }
            }
        }

        function viewUserDetails(userId) {
            const user = getUserById(userId);
            if (user) {
                // In a real app, you might open a detailed view or navigate to a user profile page
                alert(`Viewing details for ${user.firstName} ${user.lastName}`);
            }
        }

        function getUserById(userId) {
            return users.find(u => u.id === parseInt(userId));
        }

        function updateStats() {
            loadStats();
        }

        // Helper functions
        function formatDate(dateString) {
            const options = { year: 'numeric', month: 'short', day: 'numeric' };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        function formatRole(role) {
            return role.split('-').map(capitalizeFirstLetter).join(' ');
        }

        function capitalizeFirstLetter(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }
    </script>
</body>
</html>
