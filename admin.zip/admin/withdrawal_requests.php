<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
$adminUsername = $_SESSION['username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal Requests - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a90e2;
            --secondary: #357abd;
            --accent: #ff6b6b;
            --dark: #1a202c;
            --light: #f7fafc;
            --success: #48bb78;
            --warning: #ecc94b;
            --danger: #e53e3e;
            --gray: #718096;
            --gray-light: #e2e8f0;
            --sidebar-width: 260px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: var(--dark);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
            z-index: 100;
        }

        .logo {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .nav-links {
            padding: 0 15px;
        }

        .nav-links li {
            list-style: none;
            margin-bottom: 5px;
        }

        .nav-links a {
            color: #cbd5e0;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            transition: all 0.3s;
        }

        .nav-links a:hover, .nav-links a.active {
            background: rgba(74, 144, 226, 0.2);
            color: white;
        }

        .nav-links i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }

        .user-info h4 {
            font-size: 15px;
            font-weight: 600;
        }

        .user-info p {
            font-size: 13px;
            color: var(--gray);
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .stat-info h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: var(--gray);
            font-size: 14px;
        }

        .bg-blue { background: rgba(74, 144, 226, 0.1); color: var(--primary); }
        .bg-green { background: rgba(72, 187, 120, 0.1); color: var(--success); }
        .bg-orange { background: rgba(236, 201, 75, 0.1); color: var(--warning); }
        .bg-red { background: rgba(229, 62, 62, 0.1); color: var(--danger); }

        /* Request Container */
        .requests-container {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .controls {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            border: none;
        }

        .btn-primary { background: var(--primary); color: white; }
        .btn-success { background: var(--success); color: white; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-outline { background: transparent; border: 1px solid var(--gray-light); color: var(--gray); }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        /* Filters */
        .filter-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-group label {
            font-size: 14px;
            color: var(--gray);
            font-weight: 500;
        }

        .filter-group select, .filter-group input {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid var(--gray-light);
            background: white;
            min-width: 150px;
        }

        /* Table Styles */
        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8fafc;
            border-bottom: 2px solid var(--gray-light);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--gray-light);
        }

        th {
            font-weight: 600;
            color: var(--gray);
            font-size: 14px;
        }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .status {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
        }

        .status-pending { background: rgba(236, 201, 75, 0.1); color: var(--warning); }
        .status-approved { background: rgba(72, 187, 120, 0.1); color: var(--success); }
        .status-rejected { background: rgba(229, 62, 62, 0.1); color: var(--danger); }

        .amount {
            font-weight: 600;
            font-size: 16px;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: none;
            background: transparent;
            color: var(--gray);
            margin-right: 5px;
        }

        .action-btn:hover {
            background: var(--gray-light);
            color: var(--dark);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .modal-header {
            padding: 20px;
            background: var(--primary);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 10px 10px 0 0;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .modal-body {
            padding: 20px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid var(--gray-light);
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            font-weight: 600;
            color: var(--gray);
        }

        .modal-footer {
            padding: 15px 20px;
            background: #f8fafc;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-radius: 0 0 10px 10px;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-light);
            border-radius: 6px;
            resize: vertical;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--gray-light);
        }

        .page-info {
            color: var(--gray);
            font-size: 14px;
        }

        .page-controls {
            display: flex;
            gap: 8px;
        }

        .page-btn {
            width: 36px;
            height: 36px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border: 1px solid var(--gray-light);
            cursor: pointer;
            transition: all 0.3s;
        }

        .page-btn:hover, .page-btn.active {
            background: var(--primary);
            color: white;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .filter-controls {
                flex-direction: column;
            }
            
            .section-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <h1><i class="fas fa-play-circle"></i> <span>VideoDash</span></h1>
        </div>
        <ul class="nav-links">
            <li><a href="index.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="add_video.php"><i class="fas fa-video"></i> <span>Videos</span></a></li>
            <li><a href="users.php"><i class="fas fa-users"></i> <span>Users</span></a></li>
            <li><a href="new-users.php"><i class="fas fa-user-plus"></i> <span>New Users</span></a></li>
            <li><a href="analytics.php"><i class="fas fa-chart-line"></i> <span>Analytics</span></a></li>
            <li><a href="redemptions.php"><i class="fas fa-gift"></i> <span>Redemptions</span></a></li>
            <li><a href="tasks.php"><i class="fas fa-tasks"></i> <span>Tasks</span></a></li>
            <li><a href="rewards.php"><i class="fas fa-coins"></i> <span>Rewards</span></a></li>
            <li><a href="withdrawal_requests.php" class="active"><i class="fas fa-money-bill-wave"></i> <span>Withdrawals</span></a></li>
            <li><a href="setting.php"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
            <li><a href="security.php"><i class="fas fa-lock"></i> <span>Security</span></a></li>
            <li><a href="alerts.php"><i class="fas fa-exclamation-triangle"></i> <span>Alerts</span></a></li>
            <li><a href="database.php"><i class="fas fa-database"></i> <span>Database</span></a></li>
            <li><a href="integration.php"><i class="fas fa-plug"></i> <span>Integrations</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <h1>Withdrawal Requests</h1>
                <p>Manage user withdrawal requests</p>
            </div>
            <div class="user-profile">
                <img src="https://randomuser.me/api/portraits/men/41.jpg" alt="Admin">
                <div class="user-info">
                    <h4><?= htmlspecialchars($adminUsername) ?></h4>
                    <p>Admin</p>
                </div>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon bg-orange">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <h3 id="pendingCount">12</h3>
                    <p>Pending Requests</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-green">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3 id="approvedCount">45</h3>
                    <p>Approved Today</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-blue">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalAmount">$2,450</h3>
                    <p>Total Amount</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-red">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div class="stat-info">
                    <h3 id="rejectedCount">3</h3>
                    <p>Rejected Today</p>
                </div>
            </div>
        </div>

        <!-- Withdrawal Requests Section -->
        <div class="requests-container">
            <div class="section-header">
                <div class="section-title">
                    <h2>Withdrawal Requests</h2>
                    <p>Review and manage user withdrawal requests</p>
                </div>
                <div class="controls">
                    <button class="btn btn-success" id="bulkApproveBtn">
                        <i class="fas fa-check"></i> Bulk Approve
                    </button>
                    <button class="btn btn-outline" id="exportBtn">
                        <i class="fas fa-download"></i> Export
                    </button>
                </div>
            </div>

            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-group">
                    <label>Status</label>
                    <select id="statusFilter">
                        <option value="">All Status</option>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Date Range</label>
                    <select id="dateFilter">
                        <option value="">All Time</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="month">This Month</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Amount Range</label>
                    <select id="amountFilter">
                        <option value="">All Amounts</option>
                        <option value="small">Under $100</option>
                        <option value="medium">$100 - $500</option>
                        <option value="large">Over $500</option>
                    </select>
                </div>
            </div>

            <!-- Requests Table -->
            <div class="table-container">
                <table id="requestsTable">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" id="selectAll">
                            </th>
                            <th>User</th>
                            <th>Request ID</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="requestsTableBody">
                        <!-- Requests will be populated dynamically -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="pagination">
                <div class="page-info">
                    Showing <span id="startRange">1</span> to <span id="endRange">10</span> of <span id="totalRequests">25</span> requests
                </div>
                <div class="page-controls" id="pageControls">
                    <!-- Pagination will be generated dynamically -->
                </div>
            </div>
        </div>
    </div>

    <!-- Request Details Modal -->
    <div class="modal" id="requestModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Request Details</h3>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Request details will be populated dynamically -->
            </div>
            <div class="modal-footer">
                <button class="btn btn-success" id="approveBtn">
                    <i class="fas fa-check"></i> Approve
                </button>
                <button class="btn btn-danger" id="rejectBtn">
                    <i class="fas fa-times"></i> Reject
                </button>
                <button class="btn btn-outline" id="cancelBtn">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div class="modal" id="rejectionModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reject Request</h3>
                <button class="modal-close" id="closeRejectionModal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="rejectionReason">Reason for rejection:</label>
                    <textarea id="rejectionReason" rows="4" placeholder="Please provide a reason for rejecting this withdrawal request..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" id="confirmRejectBtn">
                    <i class="fas fa-times"></i> Reject Request
                </button>
                <button class="btn btn-outline" id="cancelRejectBtn">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        // Sample withdrawal requests data
        let withdrawalRequests = [
            {
                id: 'WR001',
                userId: 'U001',
                userName: 'John Doe',
                userEmail: 'john.doe@example.com',
                amount: 250.00,
                method: 'PayPal',
                methodDetails: 'john.doe@paypal.com',
                requestDate: '2024-01-15T10:30:00',
                status: 'pending',
                notes: 'Regular monthly withdrawal',
                userPoints: 2500
            },
            {
                id: 'WR002',
                userId: 'U002',
                userName: 'Jane Smith',
                userEmail: 'jane.smith@example.com',
                amount: 100.00,
                method: 'Bank Transfer',
                methodDetails: 'Account: ****1234',
                requestDate: '2024-01-15T09:15:00',
                status: 'approved',
                notes: 'First withdrawal request',
                userPoints: 1000,
                processedDate: '2024-01-15T11:00:00',
                processedBy: 'Admin'
            },
            {
                id: 'WR003',
                userId: 'U003',
                userName: 'Mike Johnson',
                userEmail: 'mike.j@example.com',
                amount: 75.00,
                method: 'Cash App',
                methodDetails: '$mikej2024',
                requestDate: '2024-01-14T16:45:00',
                status: 'pending',
                notes: 'Accumulated points withdrawal',
                userPoints: 750
            },
            {
                id: 'WR004',
                userId: 'U004',
                userName: 'Sarah Williams',
                userEmail: 'sarah.w@example.com',
                amount: 500.00,
                method: 'Bank Transfer',
                methodDetails: 'Account: ****5678',
                requestDate: '2024-01-14T14:20:00',
                status: 'rejected',
                notes: 'Large withdrawal request',
                userPoints: 5000,
                processedDate: '2024-01-14T15:30:00',
                processedBy: 'Admin',
                rejectionReason: 'Insufficient verification documents'
            },
            {
                id: 'WR005',
                userId: 'U005',
                userName: 'David Brown',
                userEmail: 'david.b@example.com',
                amount: 180.00,
                method: 'PayPal',
                methodDetails: 'davidbrown@paypal.com',
                requestDate: '2024-01-13T11:10:00',
                status: 'approved',
                notes: 'Content creator payout',
                userPoints: 1800,
                processedDate: '2024-01-13T13:45:00',
                processedBy: 'Admin'
            }
        ];

        // DOM Elements
        const requestsTableBody = document.getElementById('requestsTableBody');
        const requestModal = document.getElementById('requestModal');
        const rejectionModal = document.getElementById('rejectionModal');
        const closeModal = document.getElementById('closeModal');
        const closeRejectionModal = document.getElementById('closeRejectionModal');
        const statusFilter = document.getElementById('statusFilter');
        const dateFilter = document.getElementById('dateFilter');
        const amountFilter = document.getElementById('amountFilter');
        const selectAll = document.getElementById('selectAll');
        const bulkApproveBtn = document.getElementById('bulkApproveBtn');
        const exportBtn = document.getElementById('exportBtn');

        // Current selected request
        let currentRequest = null;
        let currentPage = 1;
        const itemsPerPage = 10;

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            updateStats();
            renderRequestsTable();
            updatePagination();

            // Event listeners
            closeModal.addEventListener('click', () => {
                requestModal.style.display = 'none';
            });

            closeRejectionModal.addEventListener('click', () => {
                rejectionModal.style.display = 'none';
            });

            document.getElementById('cancelBtn').addEventListener('click', () => {
                requestModal.style.display = 'none';
            });

            document.getElementById('cancelRejectBtn').addEventListener('click', () => {
                rejectionModal.style.display = 'none';
            });

            document.getElementById('approveBtn').addEventListener('click', () => {
                if (currentRequest) {
                    approveRequest(currentRequest.id);
                }
            });

            document.getElementById('rejectBtn').addEventListener('click', () => {
                requestModal.style.display = 'none';
                rejectionModal.style.display = 'flex';
            });

            document.getElementById('confirmRejectBtn').addEventListener('click', () => {
                if (currentRequest) {
                    const reason = document.getElementById('rejectionReason').value;
                    rejectRequest(currentRequest.id, reason);
                }
            });

            // Filters
            statusFilter.addEventListener('change', filterRequests);
            dateFilter.addEventListener('change', filterRequests);
            amountFilter.addEventListener('change', filterRequests);

            // Select all checkbox
            selectAll.addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('.request-checkbox');
                checkboxes.forEach(cb => cb.checked = this.checked);
            });

            // Bulk approve
            bulkApproveBtn.addEventListener('click', bulkApprove);

            // Export
            exportBtn.addEventListener('click', exportRequests);
        });

        function updateStats() {
            const pending = withdrawalRequests.filter(r => r.status === 'pending').length;
            const approved = withdrawalRequests.filter(r => r.status === 'approved').length;
            const rejected = withdrawalRequests.filter(r => r.status === 'rejected').length;
            const totalAmount = withdrawalRequests.reduce((sum, r) => sum + r.amount, 0);

            document.getElementById('pendingCount').textContent = pending;
            document.getElementById('approvedCount').textContent = approved;
            document.getElementById('rejectedCount').textContent = rejected;
            document.getElementById('totalAmount').textContent = '$' + totalAmount.toLocaleString();
        }

        function renderRequestsTable() {
            const filteredRequests = filterRequestsList();
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, filteredRequests.length);
            const paginatedRequests = filteredRequests.slice(startIndex, endIndex);

            // Update page info
            document.getElementById('startRange').textContent = filteredRequests.length > 0 ? startIndex + 1 : 0;
            document.getElementById('endRange').textContent = endIndex;
            document.getElementById('totalRequests').textContent = filteredRequests.length;

            requestsTableBody.innerHTML = '';

            if (paginatedRequests.length === 0) {
                requestsTableBody.innerHTML = `
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            No withdrawal requests found
                        </td>
                    </tr>
                `;
                return;
            }

            paginatedRequests.forEach(request => {
                const row = document.createElement('tr');
                const initials = request.userName.split(' ').map(n => n[0]).join('');
                
                row.innerHTML = `
                    <td>
                        <input type="checkbox" class="request-checkbox" value="${request.id}">
                    </td>
                    <td>
                        <div class="user-cell">
                            <div class="user-avatar">${initials}</div>
                            <div>
                                <div style="font-weight: 600;">${request.userName}</div>
                                <div style="color: var(--gray); font-size: 13px;">${request.userEmail}</div>
                            </div>
                        </div>
                    </td>
                    <td>${request.id}</td>
                    <td class="amount">$${request.amount.toFixed(2)}</td>
                    <td>${request.method}</td>
                    <td>${formatDate(request.requestDate)}</td>
                    <td><span class="status status-${request.status}">${capitalizeFirstLetter(request.status)}</span></td>
                    <td>
                        <button class="action-btn" onclick="viewRequest('${request.id}')" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${request.status === 'pending' ? `
                            <button class="action-btn" onclick="quickApprove('${request.id}')" title="Quick Approve" style="color: var(--success);">
                                <i class="fas fa-check"></i>
                            </button>
                            <button class="action-btn" onclick="quickReject('${request.id}')" title="Quick Reject" style="color: var(--danger);">
                                <i class="fas fa-times"></i>
                            </button>
                        ` : ''}
                    </td>
                `;
                
                requestsTableBody.appendChild(row);
            });
        }

        function filterRequestsList() {
            const statusValue = statusFilter.value;
            const dateValue = dateFilter.value;
            const amountValue = amountFilter.value;

            return withdrawalRequests.filter(request => {
                // Status filter
                const matchesStatus = !statusValue || request.status === statusValue;

                // Date filter
                let matchesDate = true;
                if (dateValue) {
                    const requestDate = new Date(request.requestDate);
                    const now = new Date();

                    if (dateValue === 'today') {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        matchesDate = requestDate >= today;
                    } else if (dateValue === 'week') {
                        const weekAgo = new Date();
                        weekAgo.setDate(weekAgo.getDate() - 7);
                        matchesDate = requestDate >= weekAgo;
                    } else if (dateValue === 'month') {
                        const monthAgo = new Date();
                        monthAgo.setMonth(monthAgo.getMonth() - 1);
                        matchesDate = requestDate >= monthAgo;
                    }
                }

                // Amount filter
                let matchesAmount = true;
                if (amountValue) {
                    if (amountValue === 'small') {
                        matchesAmount = request.amount < 100;
                    } else if (amountValue === 'medium') {
                        matchesAmount = request.amount >= 100 && request.amount <= 500;
                    } else if (amountValue === 'large') {
                        matchesAmount = request.amount > 500;
                    }
                }

                return matchesStatus && matchesDate && matchesAmount;
            });
        }

        function filterRequests() {
            currentPage = 1;
            renderRequestsTable();
            updatePagination();
        }

        function updatePagination() {
            const filteredRequests = filterRequestsList();
            const totalPages = Math.ceil(filteredRequests.length / itemsPerPage);
            
            let paginationHTML = `
                <div class="page-btn" onclick="changePage(${Math.max(1, currentPage - 1)})">
                    <i class="fas fa-chevron-left"></i>
                </div>
            `;
            
            for (let i = 1; i <= Math.min(totalPages, 5); i++) {
                paginationHTML += `
                    <div class="page-btn ${i === currentPage ? 'active' : ''}" onclick="changePage(${i})">
                        ${i}
                    </div>
                `;
            }
            
            if (totalPages > 5) {
                paginationHTML += `
                    <div class="page-btn">...</div>
                    <div class="page-btn" onclick="changePage(${totalPages})">${totalPages}</div>
                `;
            }
            
            paginationHTML += `
                <div class="page-btn" onclick="changePage(${Math.min(totalPages, currentPage + 1)})">
                    <i class="fas fa-chevron-right"></i>
                </div>
            `;
            
            document.getElementById('pageControls').innerHTML = paginationHTML;
        }

        function changePage(page) {
            currentPage = page;
            renderRequestsTable();
            updatePagination();
        }

        function viewRequest(requestId) {
            const request = withdrawalRequests.find(r => r.id === requestId);
            if (!request) return;

            currentRequest = request;

            const modalBody = document.getElementById('modalBody');
            modalBody.innerHTML = `
                <div class="detail-row">
                    <span class="detail-label">Request ID:</span>
                    <span>${request.id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">User:</span>
                    <span>${request.userName} (${request.userEmail})</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Amount:</span>
                    <span style="font-weight: 600; color: var(--primary);">$${request.amount.toFixed(2)}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">User Points:</span>
                    <span>${request.userPoints.toLocaleString()} points</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Withdrawal Method:</span>
                    <span>${request.method}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Method Details:</span>
                    <span>${request.methodDetails}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Request Date:</span>
                    <span>${formatDateTime(request.requestDate)}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span class="status status-${request.status}">${capitalizeFirstLetter(request.status)}</span>
                </div>
                ${request.processedDate ? `
                    <div class="detail-row">
                        <span class="detail-label">Processed Date:</span>
                        <span>${formatDateTime(request.processedDate)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Processed By:</span>
                        <span>${request.processedBy}</span>
                    </div>
                ` : ''}
                ${request.rejectionReason ? `
                    <div class="detail-row">
                        <span class="detail-label">Rejection Reason:</span>
                        <span style="color: var(--danger);">${request.rejectionReason}</span>
                    </div>
                ` : ''}
                <div class="detail-row">
                    <span class="detail-label">Notes:</span>
                    <span>${request.notes}</span>
                </div>
            `;

            // Hide action buttons if already processed
            const approveBtn = document.getElementById('approveBtn');
            const rejectBtn = document.getElementById('rejectBtn');
            
            if (request.status !== 'pending') {
                approveBtn.style.display = 'none';
                rejectBtn.style.display = 'none';
            } else {
                approveBtn.style.display = 'block';
                rejectBtn.style.display = 'block';
            }

            requestModal.style.display = 'flex';
        }

        function quickApprove(requestId) {
            if (confirm('Are you sure you want to approve this withdrawal request?')) {
                approveRequest(requestId);
            }
        }

        function quickReject(requestId) {
            const request = withdrawalRequests.find(r => r.id === requestId);
            if (!request) return;

            currentRequest = request;
            rejectionModal.style.display = 'flex';
        }

        function approveRequest(requestId) {
            const request = withdrawalRequests.find(r => r.id === requestId);
            if (!request) return;

            request.status = 'approved';
            request.processedDate = new Date().toISOString();
            request.processedBy = 'Admin';

            updateStats();
            renderRequestsTable();
            requestModal.style.display = 'none';

            alert('Request approved successfully!');
        }

        function rejectRequest(requestId, reason) {
            const request = withdrawalRequests.find(r => r.id === requestId);
            if (!request) return;

            if (!reason.trim()) {
                alert('Please provide a reason for rejection.');
                return;
            }

            request.status = 'rejected';
            request.processedDate = new Date().toISOString();
            request.processedBy = 'Admin';
            request.rejectionReason = reason;

            updateStats();
            renderRequestsTable();
            rejectionModal.style.display = 'none';
            
            // Clear the rejection reason
            document.getElementById('rejectionReason').value = '';

            alert('Request rejected successfully!');
        }

        function bulkApprove() {
            const selectedRequests = document.querySelectorAll('.request-checkbox:checked');
            
            if (selectedRequests.length === 0) {
                alert('Please select requests to approve.');
                return;
            }

            if (confirm(`Are you sure you want to approve ${selectedRequests.length} requests?`)) {
                selectedRequests.forEach(checkbox => {
                    approveRequest(checkbox.value);
                });

                // Uncheck all
                selectAll.checked = false;
                selectedRequests.forEach(cb => cb.checked = false);
            }
        }

        function exportRequests() {
            // In a real application, this would generate and download a CSV/Excel file
            alert('Withdrawal requests exported successfully!');
        }

        // Helper functions
        function formatDate(dateString) {
            const options = { year: 'numeric', month: 'short', day: 'numeric' };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        function formatDateTime(dateString) {
            const options = { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        function capitalizeFirstLetter(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }
    </script>
</body>
</html>
