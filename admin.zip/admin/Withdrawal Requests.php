<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Withdrawal Requests</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a90e2;
            --secondary: #357abd;
            --accent: #ff6b6b;
            --dark: #1a202c;
            --light: #f7fafc;
            --success: #48bb78;
            --warning: #ecc94b;
            --danger: #e53e3e;
            --gray: #718096;
            --gray-light: #e2e8f0;
            --sidebar-width: 260px;
            --header-height: 70px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: var(--dark);
            display: flex;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
            transition: all 0.3s;
            z-index: 100;
        }

        .logo {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .nav-links {
            padding: 0 15px;
        }

        .nav-links li {
            list-style: none;
            margin-bottom: 5px;
        }

        .nav-links a {
            color: #cbd5e0;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            transition: all 0.3s;
        }

        .nav-links a:hover, .nav-links a.active {
            background: rgba(74, 144, 226, 0.2);
            color: white;
        }

        .nav-links i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
        }

        /* Header Styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .header-actions {
            display: flex;
            gap: 15px;
        }

        .search-box {
            position: relative;
        }

        .search-box input {
            padding: 10px 15px 10px 40px;
            border-radius: 50px;
            border: 1px solid var(--gray-light);
            width: 250px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        .user-info h4 {
            font-size: 15px;
            font-weight: 600;
        }

        .user-info p {
            font-size: 13px;
            color: var(--gray);
        }

        /* Stats Section */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .stat-info h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: var(--gray);
            font-size: 14px;
        }

        .bg-blue {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
        }

        .bg-green {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success);
        }

        .bg-orange {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .bg-red {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        /* Withdrawal Table Section */
        .requests-container {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .controls {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            border: none;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--secondary);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--gray-light);
            color: var(--gray);
        }

        .btn-outline:hover {
            background: var(--gray-light);
        }

        .filter-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-group label {
            font-size: 14px;
            color: var(--gray);
            font-weight: 500;
        }

        .filter-group select, .filter-group input {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid var(--gray-light);
            background: white;
            min-width: 150px;
        }

        .filter-group input {
            padding-left: 35px;
        }

        .search-control {
            position: relative;
        }

        .search-control i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8fafc;
            border-bottom: 2px solid var(--gray-light);
        }

        th {
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 14px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid var(--gray-light);
            font-size: 14px;
        }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--gray-light);
            overflow: hidden;
            position: relative;
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info-cell {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            margin-bottom: 3px;
        }

        .user-email {
            color: var(--gray);
            font-size: 13px;
        }

        .status {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
        }

        .status-pending {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .status-approved {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success);
        }

        .status-rejected {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }
        
        .status-completed {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            background: transparent;
            color: var(--gray);
        }

        .action-btn:hover {
            background: var(--gray-light);
            color: var(--dark);
        }

        .action-btns {
            display: flex;
            gap: 8px;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--gray-light);
        }

        .page-info {
            color: var(--gray);
            font-size: 14px;
        }

        .page-controls {
            display: flex;
            gap: 8px;
        }

        .page-btn {
            width: 36px;
            height: 36px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border: 1px solid var(--gray-light);
            cursor: pointer;
            transition: all 0.3s;
        }

        .page-btn:hover, .page-btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: white;
            border-radius: 10px;
            width: 500px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--gray);
        }

        .modal-body {
            padding: 20px;
        }

        .info-group {
            margin-bottom: 20px;
        }

        .info-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: var(--gray);
            font-size: 13px;
        }

        .info-group div {
            font-size: 15px;
            padding: 8px 0;
            border-bottom: 1px solid #f1f1f1;
        }

        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid var(--gray-light);
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .payment-info {
            background: #f8fafc;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
        }

        /* Loading spinner */
        .spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border-left-color: var(--primary);
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .loading {
            text-align: center;
            padding: 20px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
            }
            
            .logo h1 span, .nav-links a span {
                display: none;
            }
            
            .logo h1 {
                justify-content: center;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 12px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .search-box input {
                width: 100%;
            }
            
            .stats-container {
                grid-template-columns: 1fr 1fr;
            }
            
            .filter-controls {
                flex-direction: column;
            }
            
            .controls {
                flex-wrap: wrap;
            }
            
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .page-controls {
                display: none;
            }
            
            .pagination {
                justify-content: center;
            }
            
            .modal-content {
                width: 95%;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <h1><i class="fas fa-play-circle"></i> <span>UC Forge</span></h1>
        </div>
        <ul class="nav-links">
            <li><a href="#"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="#"><i class="fas fa-video"></i> <span>Videos</span></a></li>
            <li><a href="#"><i class="fas fa-users"></i> <span>Users</span></a></li>
            <li><a href="#"><i class="fas fa-chart-line"></i> <span>Analytics</span></a></li>
            <li><a href="#" class="active"><i class="fas fa-money-bill-wave"></i> <span>Withdrawals</span></a></li>
            <li><a href="#"><i class="fas fa-tasks"></i> <span>Tasks</span></a></li>
            <li><a href="#"><i class="fas fa-coins"></i> <span>Rewards</span></a></li>
            <li><a href="#"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <h1>Withdrawal Requests</h1>
                <p>Manage user withdrawal requests</p>
            </div>
            <div class="header-actions">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search requests..." id="searchInput">
                </div>
                <div class="user-profile">
                    <img src="https://randomuser.me/api/portraits/men/41.jpg" alt="Admin">
                    <div class="user-info">
                        <h4>Admin User</h4>
                        <p>Withdrawal Manager</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon bg-blue">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalRequests">0</h3>
                    <p>Total Requests</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-green">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3 id="completedRequests">0</h3>
                    <p>Approved</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-orange">
                    <i class="fas fa-hourglass-half"></i>
                </div>
                <div class="stat-info">
                    <h3 id="pendingRequests">0</h3>
                    <p>Pending</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-red">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div class="stat-info">
                    <h3 id="rejectedRequests">0</h3>
                    <p>Rejected</p>
                </div>
            </div>
        </div>

        <!-- Requests Table Section -->
        <div class="requests-container">
            <div class="section-header">
                <div class="section-title">
                    <h2>Withdrawal Requests</h2>
                    <p>Manage user withdrawal requests</p>
                </div>
                <div class="controls">
                    <button class="btn btn-outline" id="exportBtn">
                        <i class="fas fa-download"></i> Export
                    </button>
                    <button class="btn btn-primary" id="refreshBtn">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
            </div>

            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-group">
                    <label>Status</label>
                    <select id="statusFilter">
                        <option>All Status</option>
                        <option>Pending</option>
                        <option>Approved</option>
                        <option>Rejected</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Date Range</label>
                    <select id="dateFilter">
                        <option>All Time</option>
                        <option>Today</option>
                        <option>This Week</option>
                        <option>This Month</option>
                    </select>
                </div>
                <div class="filter-group search-control">
                    <label>Search by User</label>
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search by username..." id="userSearch">
                </div>
            </div>

            <!-- Requests Table -->
            <div class="table-container">
                <table id="requestsTable">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Payment Method</th>
                            <th>Account Number</th>
                            <th>Amount</th>
                            <th>Request Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="requestsTableBody">
                        <tr>
                            <td colspan="7" class="loading">
                                <div class="spinner"></div>
                                <p>Loading withdrawal requests...</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="pagination">
                <div class="page-info" id="pageInfo">
                    Showing 0 to 0 of 0 requests
                </div>
                <div class="page-controls">
                    <div class="page-btn" id="prevPage"><i class="fas fa-chevron-left"></i></div>
                    <div class="page-btn active">1</div>
                    <div class="page-btn">2</div>
                    <div class="page-btn">3</div>
                    <div class="page-btn">4</div>
                    <div class="page-btn">5</div>
                    <div class="page-btn" id="nextPage"><i class="fas fa-chevron-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Request Details Modal -->
    <div class="modal" id="detailsModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Withdrawal Request Details</h2>
                <button class="close-btn" id="closeModal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="info-group">
                    <label>User</label>
                    <div class="user-cell">
                        <div class="user-avatar">
                            <img id="userAvatar" src="https://randomuser.me/api/portraits/women/32.jpg" alt="User">
                        </div>
                        <div class="user-info-cell">
                            <div id="userName" class="user-name">Loading...</div>
                            <div id="userEmail" class="user-email">Loading...</div>
                        </div>
                    </div>
                </div>
                
                <div class="info-group">
                    <label>Amount</label>
                    <div id="withdrawalAmount">Loading...</div>
                </div>
                
                <div class="info-group">
                    <label>Payment Method</label>
                    <div id="paymentMethod">Loading...</div>
                </div>
                
                <div class="info-group">
                    <label>Account Number</label>
                    <div id="accountNumber">Loading...</div>
                </div>
                
                <div class="info-group">
                    <label>Account Holder Name</label>
                    <div id="accountHolderName">Loading...</div>
                </div>
                
                <div class="info-group">
                    <label>Request Date</label>
                    <div id="requestDate">Loading...</div>
                </div>
                
                <div class="info-group">
                    <label>Status</label>
                    <div><span id="requestStatus" class="status status-pending">Loading...</span></div>
                </div>
                
                <div class="action-buttons">
                    <button class="btn btn-outline" id="rejectBtn">Reject</button>
                    <button class="btn btn-primary" id="approveBtn">Approve</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // API endpoints
        const API_ENDPOINTS = {
            GET_REQUESTS: 'https://api.mocki.io/v2/ec0a0c5d/withdrawals', // Mock API endpoint
            UPDATE_STATUS: 'https://api.mocki.io/v2/ec0a0c5d/update' // Mock update endpoint
        };

        // Current selected request
        let currentRequestId = null;
        let allRequests = [];

        // DOM Elements
        const requestsTableBody = document.getElementById('requestsTableBody');
        const detailsModal = document.getElementById('detailsModal');
        const closeModal = document.getElementById('closeModal');
        const refreshBtn = document.getElementById('refreshBtn');
        const exportBtn = document.getElementById('exportBtn');
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const dateFilter = document.getElementById('dateFilter');
        const userSearch = document.getElementById('userSearch');
        const rejectBtn = document.getElementById('rejectBtn');
        const approveBtn = document.getElementById('approveBtn');

        // Modal content elements
        const modalTitle = document.getElementById('modalTitle');
        const userAvatar = document.getElementById('userAvatar');
        const userName = document.getElementById('userName');
        const userEmail = document.getElementById('userEmail');
        const withdrawalAmount = document.getElementById('withdrawalAmount');
        const paymentMethod = document.getElementById('paymentMethod');
        const accountNumber = document.getElementById('accountNumber');
        const accountHolderName = document.getElementById('accountHolderName');
        const requestDate = document.getElementById('requestDate');
        const requestStatus = document.getElementById('requestStatus');

        // Initialize and fetch data
        document.addEventListener('DOMContentLoaded', function() {
            fetchWithdrawalRequests();
            
            // Modal functionality
            closeModal.addEventListener('click', () => {
                detailsModal.style.display = 'none';
            });

            // Refresh functionality
            refreshBtn.addEventListener('click', () => {
                fetchWithdrawalRequests();
            });

            // Export functionality
            exportBtn.addEventListener('click', () => {
                alert('Withdrawal data exported successfully!');
            });

            // Search functionality
            searchInput.addEventListener('input', filterRequests);
            statusFilter.addEventListener('change', filterRequests);
            dateFilter.addEventListener('change', filterRequests);
            userSearch.addEventListener('input', filterRequests);
            
            // Action buttons
            rejectBtn.addEventListener('click', () => {
                updateRequestStatus(currentRequestId, 'Rejected');
            });
            
            approveBtn.addEventListener('click', () => {
                updateRequestStatus(currentRequestId, 'Approved');
            });
        });

        // Fetch withdrawal requests from API
        function fetchWithdrawalRequests() {
            requestsTableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="loading">
                        <div class="spinner"></div>
                        <p>Loading withdrawal requests...</p>
                    </td>
                </tr>
            `;
            
            fetch(API_ENDPOINTS.GET_REQUESTS)
                .then(response => response.json())
                .then(data => {
                    allRequests = data.requests;
                    renderRequestsTable(allRequests);
                    updateStats();
                })
                .catch(error => {
                    console.error('Error fetching withdrawal requests:', error);
                    requestsTableBody.innerHTML = `
                        <tr>
                            <td colspan="7" class="loading">
                                <p>Error loading withdrawal requests. Please try again.</p>
                                <button class="btn btn-primary" onclick="fetchWithdrawalRequests()">Retry</button>
                            </td>
                        </tr>
                    `;
                });
        }

        // Function to render requests table
        function renderRequestsTable(requests) {
            if (requests.length === 0) {
                requestsTableBody.innerHTML = `
                    <tr>
                        <td colspan="7" class="loading">
                            <p>No withdrawal requests found</p>
                        </td>
                    </tr>
                `;
                return;
            }
            
            requestsTableBody.innerHTML = '';
            
            requests.forEach(request => {
                const row = document.createElement('tr');
                
                // Add mouseover effect for better UX
                row.addEventListener('mouseenter', () => {
                    row.style.backgroundColor = '#f8fafc';
                });
                
                row.addEventListener('mouseleave', () => {
                    row.style.backgroundColor = '';
                });
                
                // Add click to view details
                row.addEventListener('click', () => {
                    viewRequestDetails(request);
                });
                
                row.innerHTML = `
                    <td>
                        <div class="user-cell">
                            <div class="user-avatar">
                                <img src="${request.user.avatar}" alt="${request.user.name}">
                            </div>
                            <div class="user-info-cell">
                                <div class="user-name">${request.user.name}</div>
                                <div class="user-email">${request.user.email}</div>
                            </div>
                        </div>
                    </td>
                    <td>${request.method}</td>
                    <td>${request.accountNumber}</td>
                    <td>${request.currency} ${request.amount.toLocaleString()}</td>
                    <td>${formatDate(request.date)}</td>
                    <td><span class="status status-${request.status.toLowerCase()}">${request.status}</span></td>
                    <td>
                        <div class="action-btns">
                            <button class="action-btn" onclick="viewRequestDetails(${request.id})"><i class="fas fa-eye"></i></button>
                            <button class="action-btn" onclick="editRequest(${request.id})"><i class="fas fa-edit"></i></button>
                        </div>
                    </td>
                `;
                
                requestsTableBody.appendChild(row);
            });
            
            document.getElementById('pageInfo').textContent = 
                `Showing 1 to ${requests.length} of ${requests.length} requests`;
        }

        // Function to view request details
        function viewRequestDetails(request) {
            currentRequestId = request.id;
            modalTitle.textContent = `Withdrawal Request #${request.id}`;
            userAvatar.src = request.user.avatar;
            userName.textContent = request.user.name;
            userEmail.textContent = request.user.email;
            withdrawalAmount.textContent = `${request.currency} ${request.amount.toLocaleString()}`;
            paymentMethod.textContent = request.method;
            accountNumber.textContent = request.accountNumber;
            accountHolderName.textContent = request.accountHolder;
            requestDate.textContent = formatDate(request.date, true);
            
            // Set status
            requestStatus.className = `status status-${request.status.toLowerCase()}`;
            requestStatus.textContent = request.status;
            
            // Show modal
            detailsModal.style.display = 'flex';
        }

        // Function to update request status
        function updateRequestStatus(id, status) {
            // Find the request
            const request = allRequests.find(r => r.id === id);
            if (!request) return;
            
            // Show loading state on buttons
            approveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing';
            rejectBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing';
            approveBtn.disabled = true;
            rejectBtn.disabled = true;
            
            // Simulate API call to update status
            fetch(API_ENDPOINTS.UPDATE_STATUS, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: id,
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update local data
                    request.status = status;
                    
                    // Update UI
                    renderRequestsTable(allRequests);
                    updateStats();
                    
                    // Update modal if open
                    if (currentRequestId === id) {
                        requestStatus.className = `status status-${status.toLowerCase()}`;
                        requestStatus.textContent = status;
                    }
                    
                    alert(`Request #${id} has been ${status.toLowerCase()}!`);
                } else {
                    alert(`Error updating request: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error updating request:', error);
                alert('Error updating request. Please try again.');
            })
            .finally(() => {
                // Reset buttons
                approveBtn.innerHTML = 'Approve';
                rejectBtn.innerHTML = 'Reject';
                approveBtn.disabled = false;
                rejectBtn.disabled = false;
            });
        }

        // Function to update stats
        function updateStats() {
            const totalRequests = allRequests.length;
            const approvedRequests = allRequests.filter(r => r.status === 'Approved').length;
            const pendingRequests = allRequests.filter(r => r.status === 'Pending').length;
            const rejectedRequests = allRequests.filter(r => r.status === 'Rejected').length;
            
            document.getElementById('totalRequests').textContent = totalRequests;
            document.getElementById('completedRequests').textContent = approvedRequests;
            document.getElementById('pendingRequests').textContent = pendingRequests;
            document.getElementById('rejectedRequests').textContent = rejectedRequests;
        }

        // Function to filter requests
        function filterRequests() {
            const searchTerm = searchInput.value.toLowerCase();
            const statusValue = statusFilter.value;
            const userTerm = userSearch.value.toLowerCase();
            
            const filtered = allRequests.filter(request => {
                const matchesSearch = request.user.name.toLowerCase().includes(searchTerm) || 
                                     request.user.email.toLowerCase().includes(searchTerm) || 
                                     request.method.toLowerCase().includes(searchTerm);
                const matchesStatus = statusValue === 'All Status' || request.status === statusValue;
                const matchesUser = request.user.name.toLowerCase().includes(userTerm) || 
                                  request.user.email.toLowerCase().includes(userTerm);
                
                return matchesSearch && matchesStatus && matchesUser;
            });
            
            renderRequestsTable(filtered);
        }

        // Helper function to format date
        function formatDate(dateString, withTime = false) {
            const date = new Date(dateString);
            const options = { year: 'numeric', month: 'short', day: 'numeric' };
            
            if (withTime) {
                options.hour = '2-digit';
                options.minute = '2-digit';
            }
            
            return date.toLocaleDateString('en-US', options);
        }
    </script>
</body>
</html>