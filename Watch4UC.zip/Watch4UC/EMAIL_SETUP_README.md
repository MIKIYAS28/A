# Email Welcome System Setup

This system automatically sends welcome emails to users when they sign up and log in to your Watch4UC platform.

## 🚀 Quick Setup

### 1. Configure Email Settings
Edit `includes/email_config.php` and update the following:

```php
// SMTP Server Settings
define('SMTP_HOST', 'your-smtp-server.com');     // e.g., smtp.gmail.com
define('SMTP_PORT', 587);                         // 587 for TLS, 465 for SSL
define('SMTP_SECURE', 'tls');                     // 'tls' or 'ssl'
define('SMTP_USERNAME', 'your-email@domain.com'); // Your email address
define('SMTP_PASSWORD', 'your-password');         // Your email password

// Sender Information
define('FROM_EMAIL', 'noreply@yourdomain.com');   // Email that appears as sender
define('FROM_NAME', 'Your Site Name');            // Name that appears as sender
```

### 2. Gmail Setup (Most Common)
If using Gmail:
1. Enable 2-Factor Authentication in your Google Account
2. Go to Google Account Settings > Security > App passwords
3. Generate a new App Password for "Mail"
4. Use this App Password (not your regular password) in the config

```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USERNAME', 'your-gmail@gmail.com');
define('SMTP_PASSWORD', 'your-16-char-app-password'); // App password, not regular password
```

### 3. Test Email System
1. Visit: `http://localhost/Watch4UC/test_email.php`
2. Enter your email address
3. Click "Send Welcome Email" to test signup emails
4. Click "Send Welcome Back Email" to test login emails

### 4. Verify Integration
The system is now integrated with:
- **Signup**: `auth/signup.php` - Sends welcome email after successful registration
- **Login**: `auth/login.php` - Sends welcome back email after successful login

## 📧 Email Templates

### Welcome Email (Signup)
- **Subject**: "Welcome to Watch4UC! 🎉"
- **Content**: Account creation confirmation + getting started info
- **Features**: Responsive HTML template with your branding

### Welcome Back Email (Login)
- **Subject**: "Welcome back to Watch4UC! 👋"
- **Content**: Login confirmation + reminders about daily tasks
- **Features**: Same responsive design as welcome email

## 🔧 Customization

### Email Templates
Edit `includes/email_functions.php` to customize:
- Email subjects
- HTML templates
- Plain text versions
- Styling and branding

### Add More Email Types
You can easily add more email types by creating new functions in `email_functions.php`:
```php
function sendPasswordResetEmail($email, $username, $resetLink) {
    // Your custom email logic here
}
```

## 📊 Other SMTP Providers

### Yahoo Mail
```php
define('SMTP_HOST', 'smtp.mail.yahoo.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
```

### Outlook/Hotmail
```php
define('SMTP_HOST', 'smtp-mail.outlook.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
```

### Custom/VPS SMTP
```php
define('SMTP_HOST', 'mail.yourdomain.com');
define('SMTP_PORT', 587); // Check with your provider
define('SMTP_SECURE', 'tls');
```

## 🛡️ Security Notes

1. **Never commit sensitive credentials** to version control
2. **Use environment variables** in production:
   ```php
   define('SMTP_PASSWORD', $_ENV['SMTP_PASSWORD'] ?? 'fallback-password');
   ```
3. **Remove test_email.php** from production servers
4. **Enable error logging** to monitor email failures

## 🐛 Troubleshooting

### Emails Not Sending
1. Check `includes/email_config.php` settings
2. Verify SMTP credentials are correct
3. Check server error logs for PHPMailer errors
4. Test with `test_email.php`
5. For Gmail: Ensure App Password is used, not regular password

### Common Errors
- **Authentication failed**: Wrong username/password
- **Connection refused**: Wrong SMTP host/port
- **SSL/TLS errors**: Wrong security protocol
- **Rate limiting**: Too many emails sent too quickly

### Error Logs
Check your PHP error logs for detailed error messages:
- **Windows/XAMPP**: `C:\xampp\apache\logs\error.log`
- **Linux**: `/var/log/apache2/error.log` or `/var/log/nginx/error.log`

## ✅ Verification Checklist

- [ ] Email configuration updated in `includes/email_config.php`
- [ ] SMTP credentials tested and working
- [ ] Test emails sent successfully via `test_email.php`
- [ ] Signup process tested (new user receives welcome email)
- [ ] Login process tested (user receives welcome back email)
- [ ] Email templates look good on mobile and desktop
- [ ] Production security measures implemented
- [ ] Test file removed from production

## 🎯 Features

✅ **Automatic Welcome Emails**: Sent immediately after signup
✅ **Welcome Back Emails**: Sent on each login
✅ **Responsive HTML Templates**: Look great on all devices
✅ **Plain Text Fallback**: For email clients that don't support HTML
✅ **Error Handling**: Graceful failure without breaking authentication
✅ **Multiple SMTP Support**: Gmail, Yahoo, Outlook, custom servers
✅ **Easy Customization**: Modify templates, subjects, and styling
✅ **Testing Tools**: Built-in test functionality

Your email welcome system is now ready! Users will receive professional welcome messages that enhance their experience on your platform.
