-- Drop and recreate the database
DROP DATABASE IF EXISTS watch4uc;
CREATE DATABASE watch4uc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE watch4uc;

-- ============================
-- USERS TABLE
-- ============================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    points INT DEFAULT 0,
    role ENUM('user','admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin (password will be hashed later)
INSERT INTO users (username, password, role)
VALUES (
  'Surafel',
  '$2y$10$hIyxSWmQ5K1xBTrjQepkAOUwNTl0rGmU6Dw0kj3z3guYhD1TkBgcK', -- hash of Sura12,3#@!
  'admin'
)
ON DUPLICATE KEY UPDATE password = VALUES(password), role = 'admin';

-- ============================
-- VIDEOS TABLE
-- ============================
CREATE TABLE videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    youtube_url VARCHAR(255) NOT NULL,
    verification_code VARCHAR(20) NOT NULL,
    points INT NOT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE video_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    video_id INT NOT NULL,
    verified TINYINT(1) DEFAULT 0,
    earned_points INT DEFAULT 0,
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, video_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE
);

-- ============================
-- TASKS TABLE
-- ============================
CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('social','video','referral') NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    url VARCHAR(255),
    reward INT NOT NULL,
    target_count INT DEFAULT 1,
    enabled TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    task_id INT NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reward_given TINYINT(1) DEFAULT 0,
    UNIQUE(user_id, task_id, DATE(completed_at)),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

-- ============================
-- WITHDRAWALS TABLE
-- ============================
CREATE TABLE withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    method ENUM('bank','paypal','phone') NOT NULL,
    account_info VARCHAR(255) NOT NULL,
    points INT NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================
-- PUBG UC REDEMPTIONS TABLE
-- ============================
CREATE TABLE pubg_redemptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    pubg_username VARCHAR(100) NOT NULL,
    pubg_id VARCHAR(50) NOT NULL,
    uc_package VARCHAR(50) NOT NULL,
    points INT NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================
-- NOTIFICATIONS TABLE
-- ============================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    status ENUM('unread','read') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================
-- PASSWORD RESET TABLE
-- ============================
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(100) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

