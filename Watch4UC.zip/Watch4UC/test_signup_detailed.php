<?php
echo "<h2>Comprehensive Signup and Email Testing</h2>";

// Include necessary files
require_once 'config.php';

// Test 1: Database Structure
echo "<h3>1. Database Structure Check</h3>";
try {
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $columnNames = array_column($columns, 'Field');
    $requiredColumns = ['email_verification_token', 'email_verification_expires'];
    
    echo "<p><strong>Current columns:</strong> " . implode(', ', $columnNames) . "</p>";
    
    $missingColumns = array_diff($requiredColumns, $columnNames);
    if (empty($missingColumns)) {
        echo "<div style='color: green; background: #e8f5e8; padding: 10px; border-radius: 5px;'>✓ All required email verification columns exist</div>";
    } else {
        echo "<div style='color: red; background: #ffebee; padding: 10px; border-radius: 5px;'>";
        echo "✗ Missing columns: " . implode(', ', $missingColumns);
        echo "<br><strong>Solution:</strong> You need to add these columns to your users table.";
        echo "</div>";
        
        // Show SQL to fix the issue
        echo "<h4>SQL to fix the database:</h4>";
        echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px;'>";
        foreach ($missingColumns as $column) {
            if ($column === 'email_verification_token') {
                echo "ALTER TABLE users ADD COLUMN email_verification_token VARCHAR(64) NULL;\n";
            } elseif ($column === 'email_verification_expires') {
                echo "ALTER TABLE users ADD COLUMN email_verification_expires DATETIME NULL;\n";
            }
        }
        echo "</pre>";
    }
} catch (Exception $e) {
    echo "<div style='color: red;'>Database Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

// Test 2: Email Configuration
echo "<h3>2. Email Configuration Check</h3>";
if (file_exists(__DIR__ . '/includes/email_config.php')) {
    require_once __DIR__ . '/includes/email_config.php';
    echo "<div style='color: green;'>✓ Email configuration file found</div>";
    
    if (SMTP_USERNAME === 'yourrealemail@gmail.com' || FROM_EMAIL === 'yourrealemail@gmail.com') {
        echo "<div style='color: orange; background: #fff3cd; padding: 10px; border-radius: 5px;'>";
        echo "<strong>⚠️ Email Configuration Issue:</strong><br>";
        echo "The email settings are using placeholder values. Update these in <code>includes/email_config.php</code>:<br>";
        echo "- SMTP_USERNAME: " . SMTP_USERNAME . "<br>";
        echo "- FROM_EMAIL: " . FROM_EMAIL;
        echo "</div>";
    } else {
        echo "<div style='color: green;'>✓ Email settings appear to be configured</div>";
    }
} else {
    echo "<div style='color: red;'>✗ Email configuration file missing</div>";
}

// Test 3: PHPMailer Files
echo "<h3>3. PHPMailer Files Check</h3>";
$phpmailerPath = __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
if (file_exists($phpmailerPath)) {
    echo "<div style='color: green;'>✓ PHPMailer files found</div>";
} else {
    echo "<div style='color: red;'>✗ PHPMailer files not found at: " . $phpmailerPath . "</div>";
    echo "<p><strong>Solution:</strong> Download PHPMailer and place it in the includes/ directory</p>";
}

// Test 4: Signup Script Issues
echo "<h3>4. Signup Script Analysis</h3>";
if (file_exists(__DIR__ . '/auth/signup.php')) {
    echo "<div style='color: green;'>✓ Signup script exists</div>";
    
    // Check for duplicate session_start in signup.php
    $signupContent = file_get_contents(__DIR__ . '/auth/signup.php');
    if (strpos($signupContent, 'session_start()') !== false) {
        echo "<div style='color: orange; background: #fff3cd; padding: 10px; border-radius: 5px;'>";
        echo "<strong>⚠️ Potential Issue:</strong> signup.php has session_start() but config.php also starts sessions. This might cause conflicts.";
        echo "</div>";
    }
    
} else {
    echo "<div style='color: red;'>✗ Signup script not found</div>";
}

// Test 5: Test Form Submission
echo "<h3>5. Manual Signup Test</h3>";
echo "<form method='post' action='test_signup_manual.php' target='_blank'>";
echo "<p><input type='text' name='username' placeholder='Test Username' value='testuser_" . time() . "' required></p>";
echo "<p><input type='email' name='email' placeholder='Test Email' value='test" . time() . "@example.com' required></p>";
echo "<p><input type='password' name='password' placeholder='Password' value='testpassword123' required></p>";
echo "<p><button type='submit'>Test Signup Process</button></p>";
echo "</form>";

echo "<hr>";
echo "<h3>Quick Fixes Summary:</h3>";
echo "<ol>";
echo "<li><strong>Database:</strong> Add missing email verification columns if any</li>";
echo "<li><strong>Email Config:</strong> Update email settings in includes/email_config.php</li>";
echo "<li><strong>PHPMailer:</strong> Ensure PHPMailer is properly installed</li>";
echo "<li><strong>Session Conflicts:</strong> Remove duplicate session_start() calls</li>";
echo "</ol>";

echo "<p><strong>Test Links:</strong></p>";
echo "<ul>";
echo "<li><a href='login.html' target='_blank'>Go to Login/Signup Page</a></li>";
echo "<li><a href='test_login_session.php' target='_blank'>Test Login Session</a></li>";
echo "<li><a href='debug_session.php' target='_blank'>Debug Session Info</a></li>";
echo "</ul>";
?>
