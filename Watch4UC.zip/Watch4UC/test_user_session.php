<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

echo "Session Debug Info:\n";
echo "===================\n";
echo "Session ID: " . session_id() . "\n";
echo "Session Data: " . print_r($_SESSION, true) . "\n";

if (!empty($_SESSION['uid'])) {
    echo "\nQuerying database for user ID: " . $_SESSION['uid'] . "\n";
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['uid']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo "User found in database:\n";
            echo print_r($user, true);
        } else {
            echo "User NOT found in database\n";
        }
    } catch (Exception $e) {
        echo "Database error: " . $e->getMessage() . "\n";
    }
} else {
    echo "\nNo UID in session\n";
}

echo "\n\nTesting me.php endpoint:\n";
echo "========================\n";

// Simulate the me.php response
$response = ['loggedIn' => false, 'role' => null];

if (!empty($_SESSION['uid'])) {
    $stmt = $pdo->prepare("SELECT username, role, joined_at, balance FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        $response = [
            'loggedIn' => true,
            'role'     => $row['role'],
            'username' => $row['username'],
            'joined_at' => $row['joined_at'],
            'balance'  => $row['balance'] ?? 0,
            'profile_pic' => null
        ];
    }
}

echo "me.php would return: " . json_encode($response, JSON_PRETTY_PRINT);
?>
