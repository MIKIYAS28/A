// Centralized User Data Manager for Watch4UC
(() => {
  const STORAGE_KEY = 'w4uc:user';
  const API_ME = '/Watch4UC/api/auth/me.php';

  // Helper to get data from localStorage
  function getLocal() {
    try {
      const s = localStorage.getItem(STORAGE_KEY);
      return s ? JSON.parse(s) : null;
    } catch (e) {
      console.error('Failed to parse localStorage:', e);
      return null;
    }
  }

  // Helper to save data to localStorage
  function setLocal(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }

  // Fetch user data from API
  async function fetchUserData() {
    try {
      const res = await fetch(API_ME, {
        method: 'GET',
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      });
      
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      
      const data = await res.json();
      
      // Ensure consistent shape
      if (typeof data.loggedIn !== 'boolean') {
        throw new Error('Invalid response shape');
      }
      
      // Cache the data
      setLocal(data);
      return data;
      
    } catch (e) {
      console.error('Failed to fetch user data:', e);
      
      // Return cached data if available, otherwise guest
      const cached = getLocal();
      return cached || {
        loggedIn: false,
        id: null,
        username: 'Guest',
        email: null,
        role: 'guest',
        balance: 0,
        points: 0,
        joined_at: null,
        avatar: '/assets/img/default-avatar.png'
      };
    }
  }

  // Update navbar elements
  function hydrateNavbar(user) {
    // Username in navbar
    const nameElements = document.querySelectorAll('#nav-username, [data-nav-username]');
    nameElements.forEach(el => {
      el.textContent = user?.loggedIn ? user.username : 'Guest';
    });
    
    // Avatar in navbar
    const avatarElements = document.querySelectorAll('#nav-avatar, [data-nav-avatar]');
    avatarElements.forEach(el => {
      if (el.tagName === 'IMG') {
        el.src = user?.loggedIn && user.avatar ? user.avatar : '/assets/img/default-avatar.png';
        el.alt = user?.loggedIn ? `${user.username}'s avatar` : 'Guest avatar';
      }
    });
    
    // Points/balance in navbar
    const pointsElements = document.querySelectorAll('.nav-points, [data-nav-points]');
    pointsElements.forEach(el => {
      el.textContent = user?.loggedIn ? (user.points || 0) : 0;
    });
  }

  // Update dashboard greeting
  function hydrateGreeting(user) {
    const greetElements = document.querySelectorAll('#dashboard-greeting, #welcomeMessage, [data-greeting]');
    greetElements.forEach(el => {
      const name = user?.loggedIn ? user.username : 'Guest';
      el.textContent = `Welcome, ${name} 👋`;
    });
    
    // Member since
    const memberElements = document.querySelectorAll('#memberSince, [data-member-since]');
    memberElements.forEach(el => {
      if (user?.loggedIn && user.joined_at) {
        const date = new Date(user.joined_at);
        el.textContent = date.toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'short', 
          day: 'numeric' 
        });
      } else {
        el.textContent = '';
      }
    });
  }

  // Update all user data elements on the page
  function hydrateAll(user) {
    hydrateNavbar(user);
    hydrateGreeting(user);
    
    // Update any other user data elements
    document.querySelectorAll('[data-user-field]').forEach(el => {
      const field = el.getAttribute('data-user-field');
      if (user && field in user) {
        el.textContent = user[field];
      }
    });
  }

  // Main refresh function
  async function refreshUserData(options = {}) {
    const { hydrate = true, force = false } = options;
    
    // Use cache if available and not forcing refresh
    let data = null;
    if (!force) {
      data = getLocal();
    }
    
    // Fetch fresh data if no cache or forcing
    if (!data || force) {
      data = await fetchUserData();
    }
    
    // Update UI if requested
    if (hydrate) {
      hydrateAll(data);
    }
    
    return data;
  }

  // Check if page requires authentication
  async function ensureAuth() {
    const body = document.body;
    const requires = body && (body.getAttribute('data-auth-required') === 'true');
    
    if (!requires) return true;
    
    const data = await refreshUserData({ hydrate: true });
    
    if (!data.loggedIn) {
      // Get current page for redirect back
      const currentPath = window.location.pathname + window.location.search;
      const loginUrl = '/Watch4UC/login.html';
      const redirectUrl = `${loginUrl}?next=${encodeURIComponent(currentPath)}`;
      
      // Redirect to login
      window.location.replace(redirectUrl);
      return false;
    }
    
    return true;
  }

  // Clear user data (for logout)
  function clearUserData() {
    localStorage.removeItem(STORAGE_KEY);
    hydrateAll({
      loggedIn: false,
      username: 'Guest',
      avatar: '/assets/img/default-avatar.png',
      points: 0,
      balance: 0
    });
  }

  // Generate avatar URL with initials
  function generateAvatar(username) {
    const initials = (username || 'G').substring(0, 2).toUpperCase();
    // Use UI Avatars service as fallback
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=FFD700&color=000&bold=true`;
  }

  // Export public API
  window.UserData = {
    refresh: refreshUserData,
    ensureAuth: ensureAuth,
    clear: clearUserData,
    getLocal: getLocal,
    generateAvatar: generateAvatar
  };

  // Auto-initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
      await refreshUserData({ hydrate: true });
      await ensureAuth();
    });
  } else {
    // DOM already loaded
    Promise.resolve().then(async () => {
      await refreshUserData({ hydrate: true });
      await ensureAuth();
    });
  }
})();
