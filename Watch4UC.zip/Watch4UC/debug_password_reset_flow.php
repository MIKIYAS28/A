<?php
session_start();
require_once 'config.php';

echo "<h2>🔍 Debug Password Reset Flow</h2>";

$token = $_GET['token'] ?? '';
$step = $_GET['step'] ?? '1';

// CSS for better readability
echo "<style>
.debug-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; margin: 10px 0; }
.success { background: #d4edda; border-color: #c3e6cb; color: #155724; }
.error { background: #f8d7da; border-color: #f5c6cb; color: #721c24; }
.warning { background: #fff3cd; border-color: #ffeaa7; color: #856404; }
.info { background: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
code { background: #f1f3f4; padding: 2px 6px; border-radius: 4px; font-family: monospace; }
.btn { padding: 10px 15px; margin: 5px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; display: inline-block; }
</style>";

echo "<h3>Step $step: Debug Information</h3>";

if ($step == '1') {
    // Step 1: Show current session and create test token
    echo "<div class='debug-box info'>";
    echo "<h4>🔍 Current Session Status</h4>";
    echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";
    echo "<p><strong>Current User ID:</strong> " . ($_SESSION['uid'] ?? 'Not logged in') . "</p>";
    echo "<p><strong>Current Username:</strong> " . ($_SESSION['username'] ?? 'Not logged in') . "</p>";
    echo "</div>";
    
    echo "<div class='debug-box'>";
    echo "<h4>📧 Generate Test Reset Token</h4>";
    echo "<form method='post'>";
    echo "<p>Enter email address to generate test token:</p>";
    echo "<input type='email' name='test_email' placeholder='user@example.com' style='padding: 8px; width: 250px;' required>";
    echo "<button type='submit' name='generate_token' style='padding: 8px 15px; background: #28a745; color: white; border: none; border-radius: 4px; margin-left: 10px;'>Generate Token</button>";
    echo "</form>";
    echo "</div>";
    
    // Handle token generation
    if (isset($_POST['generate_token'])) {
        $testEmail = trim($_POST['test_email']);
        
        try {
            $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
            $stmt->execute([$testEmail]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                $resetToken = bin2hex(random_bytes(32));
                $expiryTime = date('Y-m-d H:i:s', time() + 3600);
                
                $stmt = $pdo->prepare("UPDATE users SET password_reset_token = ?, password_reset_expires = ? WHERE id = ?");
                $stmt->execute([$resetToken, $expiryTime, $user['id']]);
                
                echo "<div class='debug-box success'>";
                echo "<h4>✅ Token Generated Successfully!</h4>";
                echo "<p><strong>User:</strong> " . htmlspecialchars($user['username']) . "</p>";
                echo "<p><strong>Email:</strong> " . htmlspecialchars($testEmail) . "</p>";
                echo "<p><strong>Token:</strong> <code>" . htmlspecialchars($resetToken) . "</code></p>";
                echo "<p><strong>Expires:</strong> " . $expiryTime . "</p>";
                echo "<p><strong>Test Reset URL:</strong><br>";
                echo "<a href='debug_password_reset_flow.php?step=2&token=" . urlencode($resetToken) . "' class='btn'>🔗 Test Reset Form</a></p>";
                echo "</div>";
            } else {
                echo "<div class='debug-box error'>❌ User not found with email: " . htmlspecialchars($testEmail) . "</div>";
            }
        } catch (Exception $e) {
            echo "<div class='debug-box error'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
    
} elseif ($step == '2') {
    // Step 2: Test token validation and show reset form
    echo "<div class='debug-box info'>";
    echo "<h4>🔍 Token Validation Test</h4>";
    echo "<p><strong>Token:</strong> <code>" . htmlspecialchars($token) . "</code></p>";
    echo "<p><strong>Token Length:</strong> " . strlen($token) . " characters</p>";
    echo "</div>";
    
    $validToken = false;
    $user = null;
    
    try {
        $stmt = $pdo->prepare("SELECT id, username, email, role FROM users WHERE password_reset_token = ? AND password_reset_expires > NOW()");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $validToken = true;
            echo "<div class='debug-box success'>";
            echo "<h4>✅ Token Valid!</h4>";
            echo "<p><strong>User ID:</strong> " . $user['id'] . "</p>";
            echo "<p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>";
            echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
            echo "<p><strong>Role:</strong> " . ($user['role'] ?? 'Not set') . "</p>";
            echo "</div>";
        } else {
            echo "<div class='debug-box error'>";
            echo "<h4>❌ Token Invalid or Expired</h4>";
            
            // Check if token exists but expired
            $stmt = $pdo->prepare("SELECT id, username, email, password_reset_expires FROM users WHERE password_reset_token = ?");
            $stmt->execute([$token]);
            $expiredUser = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($expiredUser) {
                echo "<p>Token exists but expired at: " . $expiredUser['password_reset_expires'] . "</p>";
                echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";
            } else {
                echo "<p>Token not found in database</p>";
            }
            echo "</div>";
        }
    } catch (Exception $e) {
        echo "<div class='debug-box error'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
    
    // Show reset form if token is valid
    if ($validToken) {
        echo "<div class='debug-box'>";
        echo "<h4>🔑 Test Password Reset</h4>";
        echo "<form method='post'>";
        echo "<input type='hidden' name='token' value='" . htmlspecialchars($token) . "'>";
        echo "<p><input type='password' name='new_password' placeholder='New Password' style='padding: 8px; width: 200px;' required></p>";
        echo "<p><input type='password' name='confirm_password' placeholder='Confirm Password' style='padding: 8px; width: 200px;' required></p>";
        echo "<button type='submit' name='test_reset' style='padding: 8px 15px; background: #dc3545; color: white; border: none; border-radius: 4px;'>🔄 Test Reset Password</button>";
        echo "</form>";
        echo "</div>";
    }
    
    // Handle password reset test
    if (isset($_POST['test_reset'])) {
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        $resetToken = $_POST['token'] ?? '';
        
        if ($newPassword !== $confirmPassword) {
            echo "<div class='debug-box error'>❌ Passwords don't match</div>";
        } else {
            try {
                // Get user info BEFORE updating
                $stmt = $pdo->prepare("SELECT id, username, role FROM users WHERE password_reset_token = ?");
                $stmt->execute([$resetToken]);
                $resetUser = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($resetUser) {
                    echo "<div class='debug-box info'>";
                    echo "<h4>🔍 Before Reset - User Info</h4>";
                    echo "<p><strong>User ID:</strong> " . $resetUser['id'] . "</p>";
                    echo "<p><strong>Username:</strong> " . htmlspecialchars($resetUser['username']) . "</p>";
                    echo "<p><strong>Role:</strong> " . ($resetUser['role'] ?? 'viewer') . "</p>";
                    echo "</div>";
                    
                    // Update password
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, password_reset_token = NULL, password_reset_expires = NULL WHERE password_reset_token = ?");
                    $stmt->execute([$hashedPassword, $resetToken]);
                    
                    if ($stmt->rowCount() > 0) {
                        echo "<div class='debug-box success'>";
                        echo "<h4>✅ Password Updated Successfully!</h4>";
                        echo "<p>Rows affected: " . $stmt->rowCount() . "</p>";
                        echo "</div>";
                        
                        // Set session variables
                        $_SESSION['uid'] = $resetUser['id'];
                        $_SESSION['user_id'] = $resetUser['id'];
                        $_SESSION['username'] = $resetUser['username'];
                        $_SESSION['role'] = $resetUser['role'] ?? 'viewer';
                        
                        echo "<div class='debug-box success'>";
                        echo "<h4>✅ Session Variables Set!</h4>";
                        echo "<p><strong>Session UID:</strong> " . $_SESSION['uid'] . "</p>";
                        echo "<p><strong>Session Username:</strong> " . $_SESSION['username'] . "</p>";
                        echo "<p><strong>Session Role:</strong> " . $_SESSION['role'] . "</p>";
                        echo "</div>";
                        
                        echo "<div class='debug-box info'>";
                        echo "<h4>🚀 Test Redirect</h4>";
                        echo "<p><a href='debug_password_reset_flow.php?step=3' class='btn'>Test Dashboard Access</a></p>";
                        echo "<p><a href='users/Dashboard.html' class='btn'>Go to Real Dashboard</a></p>";
                        echo "<p><a href='auth/me.php' class='btn'>Test me.php API</a></p>";
                        echo "</div>";
                        
                    } else {
                        echo "<div class='debug-box error'>❌ Password update failed - no rows affected</div>";
                    }
                } else {
                    echo "<div class='debug-box error'>❌ User not found for reset token</div>";
                }
            } catch (Exception $e) {
                echo "<div class='debug-box error'>❌ Reset error: " . htmlspecialchars($e->getMessage()) . "</div>";
            }
        }
    }
    
} elseif ($step == '3') {
    // Step 3: Test final session state
    echo "<div class='debug-box info'>";
    echo "<h4>🔍 Final Session Test</h4>";
    echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";
    echo "<p><strong>Session UID:</strong> " . ($_SESSION['uid'] ?? 'NOT SET') . "</p>";
    echo "<p><strong>Session Username:</strong> " . ($_SESSION['username'] ?? 'NOT SET') . "</p>";
    echo "<p><strong>Session Role:</strong> " . ($_SESSION['role'] ?? 'NOT SET') . "</p>";
    echo "</div>";
    
    if (isset($_SESSION['uid'])) {
        echo "<div class='debug-box success'>";
        echo "<h4>✅ User is Logged In!</h4>";
        echo "<p>The password reset and auto-login worked successfully.</p>";
        echo "</div>";
        
        // Test database verification
        try {
            $stmt = $pdo->prepare("SELECT username, role, joined_at FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['uid']]);
            $dbUser = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($dbUser) {
                echo "<div class='debug-box success'>";
                echo "<h4>✅ Database Verification Passed</h4>";
                echo "<p><strong>DB Username:</strong> " . htmlspecialchars($dbUser['username']) . "</p>";
                echo "<p><strong>DB Role:</strong> " . ($dbUser['role'] ?? 'viewer') . "</p>";
                echo "<p><strong>Member Since:</strong> " . $dbUser['joined_at'] . "</p>";
                echo "</div>";
            }
        } catch (Exception $e) {
            echo "<div class='debug-box error'>❌ Database verification failed: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    } else {
        echo "<div class='debug-box error'>";
        echo "<h4>❌ Session Not Set</h4>";
        echo "<p>The auto-login failed. Session variables were not properly set.</p>";
        echo "</div>";
    }
    
    echo "<div class='debug-box'>";
    echo "<h4>🧪 Final Tests</h4>";
    echo "<p><a href='users/Dashboard.html' class='btn'>Test Dashboard Access</a></p>";
    echo "<p><a href='login.html' class='btn'>Back to Login Page</a></p>";
    echo "<p><a href='debug_password_reset_flow.php?step=1' class='btn'>Start Over</a></p>";
    echo "</div>";
}

echo "<hr>";
echo "<div class='debug-box'>";
echo "<h4>📋 Debug Steps</h4>";
echo "<p><strong>Step 1:</strong> <a href='debug_password_reset_flow.php?step=1'>Generate Test Token</a></p>";
echo "<p><strong>Step 2:</strong> Test Token Validation & Reset Form</p>";
echo "<p><strong>Step 3:</strong> Test Final Session State</p>";
echo "</div>";
?>
