<?php
require_once 'config.php';

// Check if profile_pic column exists
$stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'profile_pic'");
if ($stmt->fetch()) {
    echo "✅ profile_pic column EXISTS\n";
} else {
    echo "❌ profile_pic column NOT FOUND\n";
    
    // Add the column
    echo "Adding profile_pic column...\n";
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN profile_pic VARCHAR(255) DEFAULT NULL AFTER email_verification_expires");
        echo "✅ profile_pic column added successfully\n";
    } catch (PDOException $e) {
        echo "❌ Failed to add column: " . $e->getMessage() . "\n";
    }
}

// Check all columns
echo "\nAll columns in users table:\n";
$stmt = $pdo->query("SHOW COLUMNS FROM users");
while ($col = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "  - " . $col['Field'] . " (" . $col['Type'] . ")\n";
}
?>
