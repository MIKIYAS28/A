<?php
// Prevent any HTML output and errors
ini_set('display_errors', 0);
error_reporting(0);
ob_start();

// Set JSON content type header first
header('Content-Type: application/json');

// Include config
try {
    require __DIR__ . '/../config.php';
} catch (Exception $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode(['error' => 'Server configuration error']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (!$username || !$email || !$password) {
    http_response_code(400);
    echo json_encode(['error' => 'All fields required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    // Create user with email already verified for testing
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, balance, email_verified) VALUES (?, ?, ?, 0, 1)");
    $stmt->execute([$username, $email, $hash]);

    $userId = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true, 
        'message' => 'Account created successfully! You can now log in.',
        'user_id' => $userId
    ]);
    
} catch (PDOException $e) {
    http_response_code(409);
    if (strpos($e->getMessage(), 'Duplicate') !== false) {
        echo json_encode(['error' => 'Username or email already exists']);
    } else {
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}
?>
