<?php
// auth/login.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

try {
    // Expect JSON: { "email": "...", "password": "..." }
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);

    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if ($email === '' || $password === '') {
        echo json_encode(['success' => false, 'error' => 'Email and password are required.']);
        exit;
    }

    // Look up user by email
    $stmt = $pdo->prepare("SELECT id, username, email, password, role, email_verified FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'Invalid credentials.']);
        exit;
    }

    if (!password_verify($password, $user['password'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid credentials.']);
        exit;
    }

    // If you want to enforce email verification:
    if ((int)$user['email_verified'] === 0) {
        echo json_encode([
            'success' => false,
            'email_unverified' => true,
            'message' => 'Your email is not verified. Please verify your email to continue.'
        ]);
        exit;
    }

    // Set session
    $_SESSION['uid']      = (int)$user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email']    = $user['email'];
    $_SESSION['role']     = $user['role'] ?: 'user';

    // Redirect choice (your front-end defaults to users/Dashboard.html, but most of your files should be .php)
    $redirect = ($_SESSION['role'] === 'admin')
        ? '../admin/index.php'
        : '../users/Dashboard.php';

    echo json_encode(['success' => true, 'redirect' => $redirect]);
} catch (Throwable $e) {
    // For dev, you can log the details:
    // error_log("LOGIN ERROR: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error occurred']);
}
