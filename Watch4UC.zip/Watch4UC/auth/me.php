<?php
// Return current logged-in user info from session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

try {
    require __DIR__ . '/../config.php';
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server configuration error']);
    exit;
}

$uid = $_SESSION['uid'] ?? null;
if (!$uid) {
    echo json_encode([
        'loggedIn' => false,
        'message' => 'Not authenticated'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, username, email, role, balance, joined_at, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // Invalidate session if user no longer exists
        session_destroy();
        echo json_encode(['loggedIn' => false]);
        exit;
    }

    $avatar = $user['profile_pic'] ?: null;
    if (!$avatar) {
        // Fallback avatar (initials based via data URL is handled on frontend too)
        $avatar = 'https://ui-avatars.com/api/?name=' . urlencode($user['username']) . '&background=FFD700&color=111827';
    }

    echo json_encode([
        'loggedIn' => true,
        'id' => (int)$user['id'],
        'username' => $user['username'],
        'email' => $user['email'] ?? null,
        'role' => $user['role'] ?? 'user',
        'points' => (int)($user['balance'] ?? 0),
        'balance' => (int)($user['balance'] ?? 0),
        'tasks_done' => 0,
        'joined_at' => $user['joined_at'] ?? null,
        'member_since' => isset($user['joined_at']) ? date('Y-m-d', strtotime($user['joined_at'])) : null,
        'avatar' => $avatar
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load user profile']);
}
