<?php
// auth/signup.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

try {
    // Expect form-urlencoded (from your login.html)
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $email === '' || $password === '') {
        echo json_encode(['success' => false, 'error' => 'All fields are required.']);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Invalid email address.']);
        exit;
    }

    // Check duplicates
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email OR username = :username LIMIT 1");
    $stmt->execute([':email' => $email, ':username' => $username]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Username or email already in use.']);
        exit;
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    // If you want activation, set email_verified = 0 and generate token
    $emailVerified = 1; // change to 0 if you want to enforce verification
    $verifyToken   = bin2hex(random_bytes(32));

    $ins = $pdo->prepare("
        INSERT INTO users (username, email, password, role, email_verified, email_verification_token)
        VALUES (:username, :email, :password, 'user', :verified, :token)
    ");
    $ins->execute([
        ':username' => $username,
        ':email'    => $email,
        ':password' => $hash,
        ':verified' => $emailVerified,
        ':token'    => $verifyToken
    ]);

    // For local dev, log the “activation link” to a file instead of sending email
    if ($emailVerified === 0) {
        $link = sprintf('%s://%s%s/verify.php?token=%s',
            isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http',
            $_SERVER['HTTP_HOST'],
            rtrim(dirname($_SERVER['REQUEST_URI']), '/\\') === '/auth' ? '/..' : '',
            $verifyToken
        );

        $logfile = __DIR__ . '/../storage/mail_log/activation-links.log';
        @file_put_contents($logfile, date('c') . " | $email | $link\n", FILE_APPEND);
    }

    echo json_encode([
        'success' => true,
        'message' => 'Signup successful.',
        // front-end checks this flag to show “verify your email” UI
        'activation_required' => ($emailVerified === 0)
    ]);
} catch (Throwable $e) {
    // error_log("SIGNUP ERROR: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error occurred']);
}
