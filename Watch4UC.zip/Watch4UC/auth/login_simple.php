<?php
// Prevent any HTML output and errors
ini_set('display_errors', 0);
error_reporting(0);
ob_start();

// Ensure session is started before setting any session variables
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include config
try {
    require __DIR__ . '/../config.php';
} catch (Exception $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode(['error' => 'Server configuration error']);
    exit;
}

// Handle non-POST requests
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    if (!empty($_SESSION['uid'])) {
        // User is already logged in, redirect to dashboard
        header('Location: ../users/dashboard.php');
        exit;
    }
    // Not logged in, redirect to login page
    header('Location: ../login.html');
    exit;
}

// Set JSON content type header for POST requests
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$email = trim($data['email'] ?? '');
$pass  = $data['password'] ?? '';

if (!$email || !$pass) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password required']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, username, role, password_hash, email_verified FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($pass, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid credentials']);
        exit;
    }

    if (!$user['email_verified']) {
        http_response_code(403);
        echo json_encode([
            'error' => 'Please verify your email first',
            'email_unverified' => true,
            'email' => $email,
            'message' => 'Your account exists but email verification is required.'
        ]);
        exit;
    }

    // Set session variables
    $_SESSION['uid']      = $user['id'];
    $_SESSION['user_id']  = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role']     = $user['role'];

    echo json_encode([
        'success'  => true,
        'redirect' => ($user['role'] === 'admin') ? 'admin/users.html' : 'users/dashboard.php',
        'user' => [
            'username' => $user['username'],
            'role' => $user['role']
        ]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    exit;
}
?>
