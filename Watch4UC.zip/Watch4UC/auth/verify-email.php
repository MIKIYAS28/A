<?php
require '../config.php';
$token = $_GET['token'] ?? '';
$stmt  = $pdo->prepare("UPDATE users
                       SET email_verified = 1, email_verification_token = NULL
                       WHERE email_verification_token = ?");
$stmt->execute([$token]);
if ($stmt->rowCount()) {
    echo 'Email confirmed! You can now log in.';
} else {
    echo 'Invalid or expired link.';
}