<?php
// auth/forgot_password.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

try {
    // Expect JSON: { "email": "..." }
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    $email = trim($data['email'] ?? '');

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Please enter a valid email address.']);
        exit;
    }

    // Check user exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $u = $stmt->fetch();

    // To avoid account enumeration, always respond success.
    if (!$u) {
        echo json_encode(['success' => true, 'message' => 'If that email exists, a reset link has been sent.']);
        exit;
    }

    $token   = bin2hex(random_bytes(32));
    $expires = (new DateTime('+1 hour'))->format('Y-m-d H:i:s');

    $upd = $pdo->prepare("UPDATE users SET reset_token = :t, reset_expires = :e WHERE id = :id");
    $upd->execute([':t' => $token, ':e' => $expires, ':id' => $u['id']]);

    // Local dev: log the reset link to file instead of sending email
    $base = sprintf('%s://%s', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http', $_SERVER['HTTP_HOST']);
    // Point this to your actual reset page path. Example: /admin/admin_reset.php for admin, or /reset.php for users
    $resetLink = $base . '/Watch4UC/reset.php?token=' . urlencode($token);

    $logfile = __DIR__ . '/../storage/mail_log/reset-links.log';
    @file_put_contents($logfile, date('c') . " | $email | $resetLink\n", FILE_APPEND);

    echo json_encode(['success' => true, 'message' => 'If that email exists, a reset link has been sent.']);
} catch (Throwable $e) {
    // error_log("FORGOT ERROR: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error occurred']);
}
