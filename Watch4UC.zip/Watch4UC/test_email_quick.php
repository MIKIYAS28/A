<?php
echo "<h2>🧪 Quick Email Test</h2>";

// Test email configuration
require_once 'config.php';
require_once 'includes/email_config.php';

echo "<h3>Current Configuration:</h3>";
echo "<p><strong>SMTP Host:</strong> " . SMTP_HOST . "</p>";
echo "<p><strong>SMTP Username:</strong> " . SMTP_USERNAME . "</p>";
echo "<p><strong>FROM Email:</strong> " . FROM_EMAIL . "</p>";

if (SMTP_PASSWORD === 'YOUR_APP_PASSWORD_HERE') {
    echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
    echo "<h3>❌ App Password Not Set</h3>";
    echo "<p><strong>You need to replace 'YOUR_APP_PASSWORD_HERE' with your actual Gmail app password!</strong></p>";
    echo "<p>Steps:</p>";
    echo "<ol>";
    echo "<li>Go to <a href='https://myaccount.google.com/security' target='_blank'>Google Account Security</a></li>";
    echo "<li>Enable 2-Factor Authentication if not already enabled</li>";
    echo "<li>Go to App Passwords</li>";
    echo "<li>Generate a new app password for 'Mail'</li>";
    echo "<li>Copy the 16-character password (like: abcdefghijklmnop)</li>";
    echo "<li>Edit <code>includes/email_config.php</code> and replace 'YOUR_APP_PASSWORD_HERE' with your app password</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
    echo "<h3>✅ Configuration Looks Good</h3>";
    echo "<p>App password appears to be set. Let's test sending an email.</p>";
    echo "</div>";
    
    // Test sending email
    if (isset($_POST['send_test'])) {
        $testEmail = trim($_POST['test_email']);
        
        if (filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
            echo "<h3>📧 Testing Email Send...</h3>";
            
            try {
                require_once 'includes/email_functions.php';
                
                // Create test token
                $testToken = bin2hex(random_bytes(32));
                
                // Try sending activation email
                $result = sendActivationEmail($testEmail, 'TestUser', $testToken);
                
                if ($result) {
                    echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
                    echo "<h4>✅ SUCCESS! Email sent successfully!</h4>";
                    echo "<p>Check <strong>$testEmail</strong> for the test activation email.</p>";
                    echo "<p><strong>Activation link in email:</strong><br>";
                    echo "<small>http://localhost/Watch4UC/activate_account.php?token=$testToken</small></p>";
                    echo "</div>";
                } else {
                    echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
                    echo "<h4>❌ Email sending failed</h4>";
                    echo "<p>The email function returned false. Check your Gmail settings:</p>";
                    echo "<ul>";
                    echo "<li>Make sure 2-Factor Authentication is enabled</li>";
                    echo "<li>Make sure you're using an App Password (not your regular password)</li>";
                    echo "<li>Make sure the App Password is correct (16 characters, no spaces)</li>";
                    echo "</ul>";
                    echo "</div>";
                }
                
            } catch (Exception $e) {
                echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
                echo "<h4>❌ Error occurred:</h4>";
                echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<div style='color: red;'>❌ Please enter a valid email address.</div>";
        }
    }
    
    // Test form
    echo "<h3>📧 Send Test Email:</h3>";
    echo "<form method='post'>";
    echo "<p><input type='email' name='test_email' placeholder='Enter your email' value='mikiyasolana@gmail.com' style='padding: 10px; width: 300px;' required></p>";
    echo "<p><button type='submit' name='send_test' style='padding: 10px 20px; background: #10b981; color: white; border: none; border-radius: 5px;'>📧 Send Test Email</button></p>";
    echo "</form>";
}

echo "<hr>";
echo "<h3>📋 Next Steps:</h3>";
echo "<ol>";
echo "<li>Set your Gmail app password in the config file</li>";
echo "<li>Test email sending using the form above</li>";
echo "<li>Once emails work, try signing up again</li>";
echo "<li>Check your email for the activation link</li>";
echo "</ol>";

echo "<p><a href='setup_email.php'>← Back to Email Setup</a></p>";
?>
