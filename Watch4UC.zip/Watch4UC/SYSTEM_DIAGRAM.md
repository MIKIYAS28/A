# 🎯 Watch4UC System Architecture & Flow Diagram

## 📊 **SYSTEM OVERVIEW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           🎬 WATCH4UC PLATFORM                                 │
│                         Video Reward System                                     │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 🏗️ **SYSTEM ARCHITECTURE**

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   👥 USERS      │    │   🔧 ADMIN      │    │   📊 DATABASE   │
│                 │    │                 │    │                 │
│ • Regular Users │◄──►│ • surafel       │◄──►│ • MySQL         │
│ • Viewers       │    │ • User Mgmt     │    │ • 10 Tables     │
│ • Earners       │    │ • Task Control  │    │ • Relationships │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         ▲                       ▲                       ▲
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                    🌐 WEB APPLICATION                            │
│                                                                 │
│  Frontend (HTML/CSS/JS)          Backend (PHP APIs)            │
│  ┌─────────────────┐            ┌─────────────────┐            │
│  │ User Interface  │            │ API Endpoints   │            │
│  │ • Dashboard     │◄──────────►│ • Authentication│            │
│  │ • Login/Signup  │            │ • User Management│           │
│  │ • Video Watch   │            │ • Task System   │            │
│  │ • Tasks         │            │ • Balance System│            │
│  │ • Profile       │            │ • Withdrawals   │            │
│  │ • Withdrawals   │            │ • PUBG UC       │            │
│  └─────────────────┘            └─────────────────┘            │
└─────────────────────────────────────────────────────────────────┘
```

## 🔄 **USER FLOW DIAGRAM**

### **👤 Regular User Journey:**

```
    START
      │
      ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  📱 SIGNUP  │────►│ 📧 VERIFY   │────►│ 🏠 DASHBOARD│
│  New User   │     │ Email       │     │ Main Hub    │
└─────────────┘     └─────────────┘     └─────────────┘
      │                     │                     │
      ▼                     ▼                     ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ 🔐 LOGIN    │◄────│ ✅ VERIFIED │────►│ 🎯 ACTIVITIES│
│ Credentials │     │ Account     │     │ Earn Points │
└─────────────┘     └─────────────┘     └─────────────┘
                                                │
                                                ▼
        ┌─────────────────────────────────────────────────────┐
        │                🎬 EARNING ACTIVITIES                │
        │                                                     │
        │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
        │  │📹 WATCH     │  │✅ DAILY     │  │👥 REFERRAL  │ │
        │  │ Videos      │  │ Tasks       │  │ Friends     │ │
        │  │ +100 Points │  │ +50 Points  │  │ +200 Points │ │
        │  └─────────────┘  └─────────────┘  └─────────────┘ │
        └─────────────────────────────────────────────────────┘
                                │
                                ▼
        ┌─────────────────────────────────────────────────────┐
        │                💰 BALANCE MANAGEMENT                 │
        │                                                     │
        │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
        │  │💳 DEPOSIT   │  │💸 WITHDRAW  │  │🎮 PUBG UC   │ │
        │  │ Add Funds   │  │ Cash Out    │  │ Redeem      │ │
        │  │ (Future)    │  │ To Bank     │  │ Game Points │ │
        │  └─────────────┘  └─────────────┘  └─────────────┘ │
        └─────────────────────────────────────────────────────┘
```

### **🔧 Admin Journey (surafel):**

```
    ADMIN START
      │
      ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ 🔐 SECURE   │────►│ ✅ VERIFIED │────►│ 📊 ADMIN    │
│ LOGIN       │     │ Admin Role  │     │ DASHBOARD   │
│ surafel     │     │ Check       │     │ Control Hub │
└─────────────┘     └─────────────┘     └─────────────┘
                                                │
                                                ▼
        ┌─────────────────────────────────────────────────────┐
        │                🎛️ ADMIN CONTROLS                    │
        │                                                     │
        │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
        │  │👥 USER      │  │🎬 VIDEO     │  │✅ TASK      │ │
        │  │ Management  │  │ Management  │  │ Management  │ │
        │  │ View/Edit   │  │ Add/Remove  │  │ Create/Edit │ │
        │  └─────────────┘  └─────────────┘  └─────────────┘ │
        │                                                     │
        │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
        │  │💸 WITHDRAWAL│  │🎮 REDEMPTION│  │📈 ANALYTICS │ │
        │  │ Requests    │  │ Requests    │  │ & Reports   │ │
        │  │ Approve/Deny│  │ PUBG UC     │  │ Statistics  │ │
        │  └─────────────┘  └─────────────┘  └─────────────┘ │
        └─────────────────────────────────────────────────────┘
```

## 🗄️ **DATABASE STRUCTURE**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           📊 DATABASE SCHEMA                                   │
│                              (MySQL)                                           │
└─────────────────────────────────────────────────────────────────────────────────┘

         ┌─────────────┐
         │    USERS    │ ◄─────────────┐
         │ (Central)   │               │ (Foreign Keys)
         │ • id        │               │
         │ • surafel   │               │
         │ • balance   │               │
         │ • role      │               │
         └─────────────┘               │
              │ │ │                   │
              │ │ └──────────┐        │
              │ │            │        │
              ▼ ▼            ▼        │
    ┌─────────────┐  ┌─────────────┐  │  ┌─────────────┐
    │   VIDEOS    │  │DAILY_TASKS  │  │  │VIDEO_WATCHES│
    │ • YouTube   │  │ • Social    │  │  │ • Tracking  │
    │ • Points    │  │ • Video     │  │  │ • Rewards   │
    │ • Active    │  │ • Referral  │  │  │ • Daily     │
    └─────────────┘  └─────────────┘  │  └─────────────┘
                             │        │         │
                             ▼        │         ▼
                   ┌─────────────┐    │  ┌─────────────┐
                   │TASK_COMPLET.│    │  │TRANSACTIONS │
                   │ • User+Task │    │  │ • History   │
                   │ • Daily     │    │  │ • Types     │
                   │ • Rewards   │    │  │ • Tracking  │
                   └─────────────┘    │  └─────────────┘
                                      │
                   ┌─────────────┐    │  ┌─────────────┐
                   │ WITHDRAWALS │    │  │REDEMPTIONS  │
                   │ • Requests  │────┘  │ • PUBG UC   │
                   │ • Status    │       │ • Items     │
                   │ • Admin     │       │ • Status    │
                   └─────────────┘       └─────────────┘
```

## 🔐 **AUTHENTICATION FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         🔐 AUTHENTICATION SYSTEM                               │
└─────────────────────────────────────────────────────────────────────────────────┘

    USER INPUT                   VALIDATION                    AUTHORIZATION
        │                           │                             │
        ▼                           ▼                             ▼
┌─────────────┐            ┌─────────────┐              ┌─────────────┐
│ Username:   │           │ ✅ Check DB  │             │ 🎯 Role     │
│ surafel     │──────────►│ • Password   │────────────►│ Check       │
│             │           │ • Hash       │             │ • admin     │
│ Password:   │           │ • Verified   │             │ • viewer    │
│ 8suraman... │           │ • Active     │             │ • creator   │
└─────────────┘           └─────────────┘             └─────────────┘
        │                           │                             │
        ▼                           ▼                             ▼
┌─────────────┐            ┌─────────────┐              ┌─────────────┐
│ 📱 Form     │           │ 🔒 Security  │             │ ✅ Session  │
│ Submit      │           │ • bcrypt     │             │ Create      │
│ POST Data   │           │ • Salt       │             │ • uid       │
│ validation  │           │ • Timing     │             │ • username  │
└─────────────┘           └─────────────┘             │ • role      │
                                                      └─────────────┘
                                                              │
                                                              ▼
                                                      ┌─────────────┐
                                                      │ 🏠 Redirect │
                                                      │ to Dashboard│
                                                      │ Based on    │
                                                      │ Role        │
                                                      └─────────────┘
```

## 💰 **POINTS SYSTEM FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          💰 REWARD SYSTEM                                      │
└─────────────────────────────────────────────────────────────────────────────────┘

    EARNING ACTIVITIES              POINT VALUES                 BALANCE UPDATE
           │                            │                            │
           ▼                            ▼                            ▼
┌─────────────────┐             ┌─────────────┐              ┌─────────────┐
│ 🎬 Watch Video  │────────────►│ +100 Points │─────────────►│ 💳 Balance  │
│ • Verification  │             │ (per video) │              │ • Real-time │
│ • Daily Limit   │             └─────────────┘              │ • Database  │
└─────────────────┘                     │                   │ • Display   │
                                        ▼                    └─────────────┘
┌─────────────────┐             ┌─────────────┐                      │
│ ✅ Daily Tasks  │────────────►│ +50 Points  │──────────────────────┤
│ • Social Media  │             │ (per task)  │                      │
│ • Instagram     │             └─────────────┘                      │
│ • Facebook      │                     │                            │
└─────────────────┘                     ▼                            │
                                ┌─────────────┐                      │
┌─────────────────┐             │ +200 Points │──────────────────────┤
│ 👥 Referrals    │────────────►│ (per friend)│                      │
│ • Invite Code   │             └─────────────┘                      │
│ • New User      │                     │                            │
│ • Reward Both   │                     ▼                            │
└─────────────────┘             ┌─────────────────────────────────┐  │
                                │     📊 TRANSACTION LOG          │◄─┘
                                │ • Type: earned/withdrawn        │
                                │ • Amount: +/- points           │
                                │ • Reference: video/task/ref    │
                                │ • Timestamp: tracking          │
                                └─────────────────────────────────┘
```

## 🎮 **WITHDRAWAL & REDEMPTION SYSTEM**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                      💸 WITHDRAWAL & REDEMPTION                                │
└─────────────────────────────────────────────────────────────────────────────────┘

    USER REQUEST                 ADMIN REVIEW                   PROCESSING
         │                           │                             │
         ▼                           ▼                             ▼
┌─────────────────┐          ┌─────────────┐             ┌─────────────┐
│ 💸 Withdrawal   │         │ 🔧 Admin     │            │ ✅ Process  │
│ • Amount        │────────►│ surafel      │───────────►│ • Approve   │
│ • Method        │         │ • Review     │            │ • Reject    │
│ • PayPal/Bank   │         │ • Approve    │            │ • Complete  │
└─────────────────┘         │ • Reject     │            └─────────────┘
         │                  └─────────────┘                     │
         ▼                           │                          ▼
┌─────────────────┐                 ▼                  ┌─────────────┐
│ 🎮 PUBG UC      │         ┌─────────────┐           │ 📧 Notify   │
│ • UC Amount     │         │ 📊 Status   │           │ User        │
│ • Player ID     │────────►│ • Pending   │──────────►│ • Email     │
│ • Game Items    │         │ • Approved  │           │ • Dashboard │
└─────────────────┘         │ • Completed │           │ • History   │
                            │ • Failed    │           └─────────────┘
                            └─────────────┘
```

## 📊 **ADMIN DASHBOARD OVERVIEW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        🎛️ ADMIN CONTROL PANEL                                  │
│                           (surafel access)                                     │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ 👥 USER MGMT    │    │ 🎬 VIDEO MGMT   │    │ ✅ TASK MGMT    │
│                 │    │                 │    │                 │
│ • View All      │    │ • Add Videos    │    │ • Create Tasks  │
│ • Search Users  │    │ • YouTube IDs   │    │ • Set Rewards   │
│ • Edit Profiles │    │ • Verification  │    │ • Enable/Disable│
│ • Ban/Unban     │    │ • Point Values  │    │ • Daily Reset   │
│ • Balances      │    │ • Active Status │    │ • Categories    │
└─────────────────┘    └─────────────────┘    └─────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ 💸 WITHDRAWALS  │    │ 🎮 REDEMPTIONS  │    │ 📈 ANALYTICS    │
│                 │    │                 │    │                 │
│ • Pending Queue │    │ • PUBG UC Req   │    │ • User Stats    │
│ • Review Req    │    │ • Game Items    │    │ • Revenue       │
│ • Approve/Deny  │    │ • Process       │    │ • Activity      │
│ • Transaction   │    │ • Player IDs    │    │ • Growth        │
│ • Bank Details  │    │ • Status Track  │    │ • Reports       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🔍 **KEY SYSTEM INSIGHTS I UNDERSTAND:**

### **✅ Core Functionality:**
1. **User Registration/Login** with email verification
2. **Point-based reward system** for watching videos
3. **Daily task system** with social media integration
4. **Referral program** for user growth
5. **Withdrawal system** with admin approval
6. **PUBG UC redemption** for gamers
7. **Admin control panel** for full system management

### **🎯 Business Model:**
- Users earn points by watching videos
- Complete daily social tasks for bonus points
- Refer friends for higher rewards
- Redeem points for real money or game currency
- Admin controls all operations and approvals

### **🔒 Security Features:**
- Password hashing with bcrypt
- Session management
- Role-based access control
- Admin-only authentication
- Input validation and sanitization

### **📊 Data Flow:**
- User actions → Points earned → Balance updated → Transaction logged
- Admin oversight → Approval workflows → Payment processing
- Real-time updates and notifications

This system is a comprehensive **video reward platform** that incentivizes user engagement through a point-based economy with multiple earning methods and redemption options!

