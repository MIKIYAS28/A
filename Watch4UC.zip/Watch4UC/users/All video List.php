<?php
require_once __DIR__ . '/includes/user-data.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Videos</title
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
<script src="https://cdn.tailwindcss.com/3.4.16"></script>
 <link rel="stylesheet" href="styles.css">
<!-- 1. Tailwind CDN (already identical) -->
<scrip src="https://cdn.tailwindcss.com/3.4.16">
 </script>

<!-- 2. Fonts & Icons (already identical) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD',
                        videoInfoBg: '#1F2937'
                    },
                    borderRadius: {
                        'none': '0px',
                        'sm': '4px',
                        DEFAULT: '8px',
                        'md': '12px',
                        'lg': '16px',
                        'xl': '20px',
                        '2xl': '24px',
                        '3xl': '32px',
                        'full': '9999px',
                        'button': '8px'
                    }
                }
            }
        };
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <!-- Mobile optimization -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">

<!-- Global JavaScript -->
    <script src="assests/js/global.js"></script>
    
    <!-- Tailwind Configuration -->
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'button': '8px'
                    }
                }
            }
        }
    </script>
    <style>
        :root {
            --primary: #FFD700;
            --secondary: #357ABD;
            --accent: #ff6b6b;
            --dark: #1a202c;
            --light: #f7fafc;
            --success: #48bb78;
            --warning: #ecc94b;
            --danger: #e53e3e;
            --gray: #718096;
            --gray-light: #e2e8f0;
            --card-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        /* Existing styles from your file */
        .icon-shadow { text-shadow: 0 0 8px #FFD700; }
        body { font-family: 'Inter', sans-serif; background-color: #f9fafb; transition: background-color 0.3s ease; }
        .sidebar-item.active { background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%); border-left: 3px solid #FFD700; }
        .sidebar-item:hover:not(.active) { background-color: rgba(74, 144, 226, 0.1); }
        /* ... (all your existing styles) ... */
        
        /* Add these styles to your existing CSS */

/* Tablet adjustments */
@media (max-width: 768px) {
  .instruction-verification {
    padding: 15px;
    gap: 12px;
  }
  
  .instruction-icon-verification {
    width: 32px;
    height: 32px;
    font-size: 16px;
  }
  
  .instruction-content-verification h4 {
    font-size: 0.95rem;
  }
  
  .instruction-content-verification p {
    font-size: 0.85rem;
  }
  
  .agreement-verification {
    padding: 12px;
  }
  
  .agreement-verification label {
    font-size: 0.9rem;
  }
}

 /* Added new styles for header layout */
        .header-content {
            display: flex;
            flex-direction: column;
            position: relative;
            padding-top: 60px; /* Space for notification on mobile */
        }
        
        .profile-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            width: 100%;
        }
        
        .profile-info {
            margin-top: 15px;
        }
        
        .points-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            margin-top: 15px;
        }
        
        .notification-container {
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 10;
        }
        
        @media (min-width: 768px) {
            .header-content {
                flex-direction: row;
                justify-content: space-between;
                align-items: flex-start;
                padding-top: 0;
            }
            
            .profile-container {
                flex-direction: row;
                align-items: center;
                text-align: left;
            }
            
            .profile-info {
                margin-top: 0;
                margin-left: 20px;
            }
            
            .points-container {
                flex-direction: row;
                justify-content: flex-start;
                gap: 20px;
            }
            
            .notification-container {
                position: static;
                align-self: center;
            }
        }

        /* Fixed mobile menu button positioning */
        #mobileMenuButton {
            position: fixed;
            top: 15px;
            left: 15px; /* Changed to left side */
            z-index: 100;
        }

/* Mobile adjustments */
/* Mobile adjustments */
@media (max-width: 576px) {
  .instruction-verification {
    flex-direction: column;
    align-items: flex-start;
    padding: 12px;
    gap: 8px;
  }
  
  .instruction-icon-verification {
    margin-bottom: 5px;
  }
  
  .instruction-content-verification h4 {
    font-size: 0.9rem;
  }
  
  .instruction-content-verification p {
    font-size: 0.8rem;
    line-height: 1.5;
  }
  
  .agreement-verification {
    padding: 10px;
  }
  
  .agreement-verification label {
    font-size: 0.85rem;
  }
}

/* Very small mobile devices */
@media (max-width: 400px) {
  .instruction-verification {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .instruction-icon-verification {
    align-self: flex-start;
  }
}
/* Very small mobile devices */
@media (max-width: 400px) {
  .instruction-verification {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .instruction-icon-verification {
    align-self: flex-start;
  }
}

@media (max-width: 768px) {
  .modal-header-verification {
    padding: 0 10px;
  }
  
  .modal-title-verification {
    font-size: 1.5rem;
  }
  
  .modal-subtitle-verification {
    font-size: 0.95rem;
  }
}

@media (max-width: 576px) {
  .modal-title-verification {
    font-size: 1.3rem;
  }
  
  .modal-subtitle-verification {
    font-size: 0.9rem;
  }
}
 .header-container {
            background: linear-gradient(135deg, #1f2937, #111827);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            position: relative;
            overflow: hidden;
        }
        
        .header-container::before {
            content: "";
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(255,215,0,0.15) 0%, rgba(255,215,0,0) 70%);
            border-radius: 50%;
            transform: translate(50%, -50%);
        }
        
        .profile-image {
            border: 3px solid var(--primary);
            box-shadow: 0 0 15px rgba(255,215,0,0.5);
        }
        
        .points-badge {
            background: rgba(255,215,0,0.1);
            border: 2px solid var(--primary);
            color: var(--primary);
            box-shadow: 0 0 10px rgba(255,215,0,0.3);
        }
        
        .notification-icon {
            position: relative;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 20px;
            height: 20px;
            background-color: #ef4444;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }
        
        .last-watched {
            background: rgba(74, 144, 226, 0.1);
            border-left: 3px solid var(--primary);
        }
        
        @media (max-width: 768px) {
            .header-container {
                padding: 15px;
            }
            
            .profile-container {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-info {
                margin-top: 15px;
            }
            
            .points-container {
                flex-direction: column;
                gap: 10px;
                align-items: center;
            }
            
            .notification-container {
                position: absolute;
                top: 20px;
                right: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header-container {
                padding: 12px;
            }
            
            .notification-container {
                top: 15px;
                right: 15px;
            }
            
            .notification-button {
                padding: 6px;
            }
        }

        /* New styles for verification system */
        .video-grid-verification {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 30px;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .video-card-verification {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
            transition: all 0.3s ease;
        }
        
        .dark .video-card-verification {
            background: #1f2937;
        }
        
        .video-card-verification:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        
        .thumbnail-verification {
            width: 100%;
            height: 200px;
            position: relative;
            overflow: hidden;
        }
        
        .thumbnail-verification img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .video-card-verification:hover .thumbnail-verification img {
            transform: scale(1.05);
        }
        
        .play-overlay-verification {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .video-card-verification:hover .play-overlay-verification {
            opacity: 1;
        }
        
        .play-icon-verification {
            width: 60px;
            height: 60px;
            background: rgba(255,255,255,0.8);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: var(--primary);
        }
        
        .video-info-verification {
            padding: 20px;
        }
        
        .dark .video-info-verification {
            background: #1f2937;
            color: white;
        }
        
        .video-title-verification {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 12px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            color: var(--dark);
            line-height: 1.4;
        }
        
        .dark .video-title-verification {
            color: white;
        }
        
        .video-meta-verification {
            display: flex;
            justify-content: space-between;
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 15px;
        }
        
        .category-verification {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .points-verification {
            font-weight: 700;
            color: var(--success);
            font-size: 1.05rem;
        }
        
        .watch-btn-verification {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: 10px;
            padding: 12px 20px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            font-weight: 600;
            font-size: 1.05rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .watch-btn-verification:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(74, 144, 226, 0.4);
        }
        
        /* Modals */
        .modal-overlay-verification {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            backdrop-filter: blur(5px);
        }
        
        .modal-content-verification {
            background: white;
            border-radius: 20px;
            max-width: 550px;
            width: 90%;
            padding: 30px;
            position: relative;
            animation: modalIn 0.4s ease-out;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        }
        
        .dark .modal-content-verification {
            background: #1f2937;
            color: white;
        }
        
        @keyframes modalIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .modal-header-verification {
            margin-bottom: 25px;
            text-align: center;
            padding: 0 20px;
        }
        
        .modal-title-verification {
            font-size: 1.7rem;
            color: var(--primary);
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .modal-subtitle-verification {
            color: var(--gray);
            font-size: 1.05rem;
        }
        
        .instruction-list-verification {
            margin: 25px 0;
        }
        
        .instruction-verification {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            margin-bottom: 20px;
            padding: 18px;
            background: rgba(74, 144, 226, 0.05);
            border-radius: 15px;
            border-left: 4px solid var(--primary);
        }
        
        .dark .instruction-verification {
            background: rgba(74, 144, 226, 0.1);
        }
        
        .instruction-icon-verification {
            width: 36px;
            height: 36px;
            background: rgba(74, 144, 226, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: var(--primary);
            flex-shrink: 0;
        }
        
        .instruction-content-verification h4 {
            margin-bottom: 8px;
            font-size: 1.05rem;
            color: var(--dark);
        }
        
        .dark .instruction-content-verification h4 {
            color: white;
        }
        
        .instruction-content-verification p {
            color: var(--gray);
            font-size: 0.9rem;
            line-height: 1.6;
        }
        
        .dark .instruction-content-verification p {
            color: #e5e7eb;
        }
        
        .agreement-verification {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 20px 0;
            padding: 15px;
            background: rgba(74, 144, 226, 0.05);
            border-radius: 10px;
        }
        
        .dark .agreement-verification {
            background: rgba(74, 144, 226, 0.1);
        }
        
        .agreement-verification input {
            width: 20px;
            height: 20px;
        }
        
        .agreement-verification label {
            color: var(--dark);
            font-weight: 500;
            font-size: 0.95rem;
        }
        
        .dark .agreement-verification label {
            color: white;
        }
        
        .modal-buttons-verification {
            display: flex;
            gap: 15px;
            margin-top: 10px;
        }
        
        .modal-btn-verification {
            flex: 1;
            padding: 14px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .cancel-btn-verification {
            background: #f3f4f6;
            border: 2px solid #e5e7eb;
            color: #4b5563;
        }
        
        .dark .cancel-btn-verification {
            background: #1f2937;
            border-color: #374151;
            color: #d1d5db;
        }
        
        .cancel-btn-verification:hover {
            background: #e5e7eb;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .watch-video-btn-verification {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
        }
        
        .watch-video-btn-verification:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(74, 144, 226, 0.4);
        }
        
        .watch-video-btn-verification:disabled {
            background: #9ca3af;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .verification-input-verification {
            width: 100%;
            padding: 16px;
            margin: 25px 0;
            border: 3px solid var(--primary);
            border-radius: 12px;
            font-size: 1.4rem;
            text-align: center;
            letter-spacing: 8px;
            font-weight: 700;
            color: var(--dark);
        }
        
        .dark .verification-input-verification {
            background: #1f2937;
            color: white;
            border-color: var(--primary);
        }
        
        .verification-input-verification::placeholder {
            letter-spacing: normal;
            font-weight: normal;
            color: #cbd5e0;
        }
        
        .verification-message-verification {
            margin-top: 15px;
            padding: 15px;
            border-radius: 10px;
            display: none;
            text-align: center;
            font-weight: 500;
        }
        
        .verification-success-verification {
            background: rgba(72, 187, 120, 0.15);
            color: var(--success);
            display: block;
            border: 2px solid var(--success);
        }
        
        .verification-error-verification {
            background: rgba(229, 62, 62, 0.15);
            color: var(--danger);
            display: block;
            border: 2px solid var(--danger);
        }
        
        .close-modal-verification {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            font-size: 26px;
            cursor: pointer;
            color: var(--gray);
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .close-modal-verification:hover {
            background: #f3f4f6;
            color: var(--dark);
        }
        
        .user-points-verification {
            position: fixed;
            top: 20px;
            right: 70px;
            background: white;
            padding: 10px 18px;
            border-radius: 50px;
            box-shadow: var(--card-shadow);
            font-weight: 700;
            color: var(--success);
            display: flex;
            align-items: center;
            gap: 8px;
            z-index: 50;
        }

        @media (max-width: 768px) {
            .user-points-verification {
                right: 80px;
                top: 15px;
                padding: 8px 15px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            .user-points-verification {
                right: 70px;
                top: 10px;
                padding: 6px 12px;
                font-size: 13px;
            }
        }
        
        .dark .user-points-verification {
            background: #1f2937;
            color: var(--success);
        }
        
        .user-points-verification i {
            color: var(--warning);
        }
        
        .return-notification-verification {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--primary);
            color: white;
            padding: 15px 25px;
            border-radius: 50px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 100;
            animation: slideDown 0.5s ease-out;
            display: none;
        }
        
        @keyframes slideDown {
            from { top: -100px; opacity: 0; }
            to { top: 20px; opacity: 1; }
        }
        
        /* Countdown styling */
        .countdown-container-verification {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 30px 0;
        }
        
        .countdown-circle-verification {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            font-weight: bold;
            margin-bottom: 20px;
            box-shadow: 0 8px 20px rgba(74, 144, 226, 0.3);
        }
        
        .countdown-text-verification {
            font-size: 18px;
            color: var(--dark);
            font-weight: 500;
            text-align: center;
        }
        
        .dark .countdown-text-verification {
            color: white;
        }

        @media (max-width: 768px) {
            .video-grid-verification {
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                gap: 20px;
            }
            
            .modal-buttons-verification {
                flex-direction: column;
            }
            
            .return-notification-verification {
                width: 90%;
                text-align: center;
                font-size: 14px;
                padding: 12px 20px;
            }
            
            .countdown-circle-verification {
                width: 80px;
                height: 80px;
                font-size: 32px;
            }
        }
        
        @media (max-width: 576px) {
            .video-grid-verification {
                grid-template-columns: 1fr;
            }
            
            .modal-content-verification {
                padding: 20px;
            }
            
            .instruction-verification {
                padding: 15px;
            }
            
            .verification-input-verification {
                font-size: 1.1rem;
                padding: 12px;
            }
            
            .return-notification-verification {
                width: 95%;
                padding: 10px 15px;
                font-size: 13px;
            }
            
            .countdown-circle-verification {
                width: 70px;
                height: 70px;
                font-size: 28px;
            }
            @media (max-width: 480px) {
  .video-grid-verification {
    grid-template-columns: 1fr;
    padding: 10px;
  }
}
        }
        
         /* Modal overlay */
.modal-overlay-verification {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px; /* New: allows spacing on small screens */
    overflow-y: auto; /* New: scroll if content overflows */
    z-index: 1000;
    backdrop-filter: blur(5px);
}

/* Modal content box */
.modal-content-verification {
    background: white;
    border-radius: 20px;
    width: 90%;
    max-width: 550px;
    padding: 30px;
    position: relative;
    animation: modalIn 0.4s ease-out;
    box-shadow: 0 25px 50px rgba(0,0,0,0.3);

    /* ✅ New additions */
    max-height: 90vh; /* Limit modal height */
    overflow-y: auto; /* Scrollable if content is too long */
}

/* Dark mode for modal content */
.dark .modal-content-verification {
    background: #1f2937;
    color: white;
}

/* Modal header */
.modal-header-verification {
    margin-bottom: 25px;
    text-align: center;
    padding: 0 20px;
}

/* Modal title */
.modal-title-verification {
    font-size: 1.7rem;
    color: var(--primary);
    margin-bottom: 10px;
    font-weight: 700;
}

/* Modal subtitle */
.modal-subtitle-verification {
    color: var(--gray);
    font-size: 1.05rem;
}

/* Close button (X) */
.close-modal-verification {
    position: absolute;
    top: 20px;
    right: 20px;
    background: none;
    border: none;
    font-size: 26px;
    cursor: pointer;
    color: var(--gray);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.3s ease;
}

.close-modal-verification:hover {
    background: #f3f4f6;
    color: var(--dark);
}

/* Modal buttons container */
.modal-buttons-verification {
    display: flex;
    gap: 15px;
    margin-top: 10px;
    flex-wrap: wrap;
}

/* Responsive for small screens */
@media (max-width: 576px) {
    .modal-content-verification {
        padding: 20px;
    }

    .modal-title-verification {
        font-size: 1.3rem;
    }

    .modal-subtitle-verification {
        font-size: 0.9rem;
    }

    .modal-buttons-verification {
        flex-direction: column;
    }
}

</style>
    
    <!-- Verification Modal -->
    <div class="modal-overlay-verification" id="verificationModal">
        <div class="modal-content-verification">
            <button class="close-modal-verification" id="closeVerificationModal">&times;</button>
            <div class="modal-header-verification">
                <h2 class="modal-title-verification">Enter Verification Code</h2>
                <p class="modal-subtitle-verification">Complete your reward claim</p>
            </div>
            
            <div class="countdown-container-verification" id="countdownContainer">
                <div class="countdown-circle-verification" id="countdownCircle">3</div>
                <div class="countdown-text-verification">Preparing verification</div>
            </div>
            
            <div id="verificationForm" style="display: none;">
                <input type="text" id="verificationCode" 
                       class="verification-input-verification" 
                       maxlength="6"
                       placeholder="XXXXXX">
                <div id="verificationMessage" class="verification-message-verification"></div>
                <div class="modal-buttons-verification">
                    <button class="modal-btn-verification cancel-btn-verification" id="cancelVerification">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button class="modal-btn-verification watch-video-btn-verification" id="submitVerification">
                        <i class="fas fa-check"></i> Submit Code
                    </button>
                </div>
            </div>
        </div>
    </div>
    <style>
 .frosted-panel {
  background: rgba(255, 255, 255, 0.6); /* Light overlay */
  backdrop-filter: blur(12px); /* Higher values for stronger effect */
  -webkit-backdrop-filter: blur(12px); /* Safari support */
  
  /* Optional enhancements */
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}
    </style>
</head>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white transition-colors duration-300">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
   <!-- Mobile menu button - moved to left side -->
    <button id="mobileMenuButton" class="md:hidden fixed top-4 left-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
  <i class="ri-menu-line text-xl text-primary"></i>
</button>
    
    <!-- Main Content -->
    <main class="flex-1 ml-0 md:ml-72 p-4 md:p-8 transition-all duration-300">
        <!-- Header Container -->
        <div class="bg-gradient-to-r from-primary to-secondary rounded-lg p-6 mb-8 text-white shadow-lg">
            <div class="header-content">
                <div class="profile-container">
                    <div class="profile-image w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden bg-white">
                        <img src="<?= $profilePic ?>" alt="Profile" class="w-full h-full object-cover">
                    </div>
                    
                    <div class="profile-info">

                        <h1 class="text-xl md:text-2xl font-bold text-center" style="color: var(--secondary);">All videos</h1>
                        <p class="text-sm md:text-base mb-2" style="color: #ffffffff;">
                            Watch videos and enter verification codes to earn rewards
                        </p>
                        
                        <div class="points-container">
                            <div  class="text-xl md:test-2xl font-bold text-center" style="color: var(--secondary --primary);">
                                <span style="color: #FFD700;">Points:</span>
                                <span id="pointsBalance" class="font-semibold text-primary ml-1">0</span>
                            </div>
                            
                            <div class="flex items-center">
                                <i class="fas fa-calendar-alt mr-2 text-gray-500"></i>
                                <span class="text-sm text-gray-500">
                                    Last watched: <span id="lastWatched"><?= $lastWatched ?></span>
                                </span>
                            </div>
                        </div>
                    </div>
           

       <!-- Notification icon and dropdown -->
        <div class="flex items-center justify-end mb-4">
            <div class="relative mr-4">
                <button id="notificationButton" class="w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center cursor-pointer text-gray-300 hover:text-primary">
                    <i class="ri-notification-3-line ri-lg"></i>
                    <span id="notificationCount" class="absolute top-0 right-0 h-4 w-4 sm:h-5 sm:w-5 bg-red-500 rounded-full flex items-center justify-center text-xs text-white">2</span>
                </button>
                <div id="notificationDropdown" class="hidden absolute right-0 mt-2 w-80 bg-gray-800 rounded-lg shadow-lg border border-gray-700 z-50">
                    <div class="p-4 border-b border-gray-700">
                        <h3 class="font-semibold text-white">Notifications</h3>
                    </div>
                    <div id="notificationList" class="max-h-80 overflow-y-auto">
                        <div class="p-4 border-b border-gray-700">
                            <p class="text-gray-300">Your UC redemption is being processed</p>
                            <p class="text-xs text-gray-500 mt-1">1 hour ago</p>
                        </div>
                        <div class="p-4 border-b border-gray-700">
                            <p class="text-gray-300">New UC redemption options available</p>
                            <p class="text-xs text-gray-500 mt-1">3 hours ago</p>
                        </div>
                    </div>
                    <a href="#" class="block p-3 text-center text-sm font-medium text-primary hover:bg-gray-700">View All Notifications</a>
                </div>
            </div>
        </div>
         </div>
            </div>
        </div>

<!-- Add this script at the bottom of the file: -->

<script>
     const notificationButton = document.getElementById('notificationButton');
  const notificationDropdown = document.getElementById('notificationDropdown');
  const profileButton = document.getElementById('profileButton');
  const profileDropdown = document.getElementById('profileDropdown');

  notificationButton.addEventListener('click', (e) => {
      e.stopPropagation();
      notificationDropdown.classList.toggle('hidden');
      profileDropdown.classList.add('hidden');
  });
function fetchNotifications() {
    fetch('api/get-notifications.php', { credentials: 'include' })
        .then(res => res.json())
        .then(data => {
            const notifCount = document.getElementById('notificationCount');
            const notifList = document.getElementById('notificationList');

            // Update badge count
            if (data.unreadCount > 0) {
                notifCount.textContent = data.unreadCount;
                notifCount.classList.remove('hidden');
            } else {
                notifCount.classList.add('hidden');
            }
            

            // Clear old notifications
            notifList.innerHTML = '';

            // Inject new ones
            data.notifications.forEach(n => {
                const div = document.createElement('div');
                div.className = 'p-4 border-b border-gray-200 dark:border-gray-700';

                const p = document.createElement('p');
                p.className = 'text-gray-700 dark:text-gray-300';
                p.textContent = n.message;

                const time = document.createElement('p');
                time.className = 'text-xs text-gray-500 dark:text-gray-400 mt-1';
                time.textContent = 'Just now'; // Optional: update with real timestamps if you have them

                div.appendChild(p);
                div.appendChild(time);
                div.addEventListener('click', () => {
                    if (n.url) {
                        window.location = n.url;
                    }
                });

                notifList.appendChild(div);
            });
        });
}

// Load every 15 seconds
fetchNotifications();
setInterval(fetchNotifications, 15000);
</script>

        <div id="loadingSkeleton" class="hidden">
        <!-- Return Notification -->
        <div class="return-notification-verification" id="returnNotification">
            <i class="fas fa-info-circle"></i>
            Welcome back! Verification will appear in <span id="countdown">3</span> seconds.
        </div>
        
        <!-- Videos Grid -->
        <div class="video-grid-verification" id="videoGrid">
            <!-- Videos will be populated here dynamically -->
        </div>
        <div class="no-videos-container" id="noVideosMessage" style="display: none;">
            <div class="no-videos-icon">
                <i class="ri-video-line"></i>
            </div>
            <div class="no-videos-text">
                No videos available yet
            </div>
        </div>
            
        <!-- Footer -->
        <footer class="bg-white dark:bg-gray-800 p-4 md:p-6 border-t border-gray-200 dark:border-gray-700 mt-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-500 dark:text-gray-400 text-sm mb-4 md:mb-0">© MIKIYAS OLANA Rewards Platform. All rights reserved. </p>
                <div class="flex items-center gap-4">
                    <a href="#" class="text-gray-500 dark:text-gray-400 hover:text-primary transition-colors duration-300">Terms of Service</a>
                    <a href="#" class="text-gray-500 dark:text-gray-400 hover:text-primary transition-colors duration-300">Privacy Policy</a>
                    <a href="#" class="text-gray-500 dark:text-gray-400 hover:text-primary transition-colors duration-300">Help Center</a>
                </div>
            </div>
        </footer>
    </div>
    
    <!-- VPN Instructions Modal -->
    <div class="modal-overlay-verification" id="vpnModal">
        <div class="modal-content-verification">
            <button class="close-modal-verification" id="closeVpnModal">&times;</button>
            <div class="modal-header-verification" style="padding: 0 10px;">
                <h2 class="modal-title-verification" style="font-size: 1.3rem;">Important Instructions</h2>
                <p class="modal-subtitle-verification" style="font-size: 0.9rem;">Before watching the video</p>
            </div>
            <div class="instruction-list-verification">
                <div class="instruction-verification" style="padding: 12px; gap: 10px;">
                    <div class="instruction-icon-verification" style="width: 30px; height: 30px; font-size: 16px;">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="instruction-content-verification">
                        <h4 style="font-size: 0.95rem;">Turn on VPN to USA location</h4>
                        <p style="font-size: 0.85rem;">You must connect to a US server to access this content</p>
                    </div>
                </div>
                <div class="instruction-verification">
                    <div class="instruction-icon-verification">
                        <i class="fas fa-sync-alt"></i>
                    </div>
                    <div class="instruction-content-verification">
                        <h4>Refresh if video doesn't load</h4>
                        <p>Refresh the page if the video doesn't appear properly</p>
                    </div>
                </div>
                <div class="instruction-verification">
                    <div class="instruction-icon-verification">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="instruction-content-verification">
                        <h4>Watch the full video</h4>
                        <p>You must watch the entire video to receive your reward</p>
                    </div>
                </div>
                <div class="instruction-verification">
                    <div class="instruction-icon-verification">
                        <i class="fas fa-key"></i>
                    </div>
                    <div class="instruction-content-verification">
                        <h4>Verification code</h4>
                        <p>At the end of the video, you'll receive a verification code</p>
                    </div>
                </div>
            </div>
            <div class="agreement-verification" style="padding: 10px; margin: 15px 0;">
                <input type="checkbox" id="agreeCheckbox" style="width: 18px; height: 18px;">
                <label for="agreeCheckbox" style="font-size: 0.9rem;">I understand and agree to these instructions</label>
            </div>
            <div class="modal-buttons-verification">
                <button class="modal-btn-verification cancel-btn-verification" id="cancelVpnBtn">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button class="modal-btn-verification watch-video-btn-verification" id="watchVideoBtn" disabled>
                    <i class="fas fa-play"></i> Watch Video
                </button>
            </div>
        </div>
    </div>
</div>
   
    <div class="blur-background" style="text-align: center; padding: 12px; font-weight: 500; position: fixed; bottom: 0; left: 0; right: 0; z-index: 100;">
        Note: This system will redirect you to YouTube. After watching, return to this page to enter your verification code.
    </div>

    <script>
       
             document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }
            // Dark mode toggle
            const darkModeToggle = document.getElementById('darkModeToggle');
            const html = document.documentElement;
            
            // Initialize dark mode
            if (localStorage.getItem('darkMode') === 'true') {
                html.classList.add('dark');
                darkModeToggle.checked = true;
            }
            
            darkModeToggle.addEventListener('change', function() {
                const isDark = this.checked;
                html.classList.toggle('dark', isDark);
                localStorage.setItem('darkMode', isDark);
            });
            
            // Initialize video system
            initVideoSystem();
        window.addEventListener('DOMContentLoaded', () => {
  initVideoSystem();
});

const isNotificationButton = event.target.closest('#notificationButton');
        // Initialize video system function
        function initVideoSystem() {
            // Implementation remains the same
        }
        // Close dropdowns when clicking outside
        document.addEventListener('click', function(event) {
            const isNotificationButton = event.target.closest('#notificationButton');
            const isProfileButton = event.target.closest('#profileButton');
            
            if (!isNotificationButton) {
                document.getElementById('notificationDropdown').classList.add('hidden');
            }
            
            if (!isProfileButton) {
                document.getElementById('profileDropdown').classList.add('hidden');
            }
        });

        // Prevent dropdown from closing when clicking inside it
        document.querySelectorAll('.notification-dropdown, .profile-dropdown').forEach(dropdown => {
            dropdown.addEventListener('click', function(event) {
                event.stopPropagation();
            });
        });
        
        // VIDEO VERIFICATION SYSTEM CODE
        // Get videos from admin storage
        const adminVideos = JSON.parse(localStorage.getItem('youtube_videos')) || [
            {
                id: 1,
                title: "How to Master Digital Marketing in 2025",
                category: "Education",
                views: 15248,
                points: 1850,
                status: "Active",
                thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80",
                verificationCode: "ABCD1234",
                youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            },
            {
                id: 2,
                title: "Top Gaming Strategies for Beginners",
                category: "Gaming",
                views: 28745,
                points: 3250,
                status: "Active",
                thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
                verificationCode: "EFGH5678",
                youtubeUrl: "https://www.youtube.com/watch?v=6ZfuNTqbHE8"
            },
            {
                id: 3,
                title: "Quick and Healthy Breakfast Ideas",
                category: "Lifestyle",
                views: 9521,
                points: 850,
                status: "Active",
                thumbnail: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
                verificationCode: "IJKL9012",
                youtubeUrl: "https://www.youtube.com/watch?v=PkZNo7MFNFg"
            },
            {
                id: 4,
                title: "Bohemian Rhapsody - Official Trailer",
                category: "Entertainment",
                views: 125842,
                points: 8420,
                status: "Active",
                thumbnail: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1120&q=80",
                verificationCode: "MNOP3456",
                youtubeUrl: "https://www.youtube.com/watch?v=fJ9rUzIMcZQ"
            },
            {
                id: 5,
                title: "Introduction to Quantum Computing",
                category: "Science",
                views: 42369,
                points: 2150,
                status: "Inactive",
                thumbnail: "https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
                verificationCode: "QRST7890",
                youtubeUrl: "https://www.youtube.com/watch?v=R_f1uCWKZQs"
            }
        ];


// After successful verification
watchedVideos.push(video.id);
localStorage.setItem('watchedVideos', JSON.stringify(watchedVideos));

// Filter videos during render
videos.filter(v => !watchedVideos.includes(v.id));
        
        // Save to localStorage if not exists
        if (!localStorage.getItem('youtube_videos')) {
            localStorage.setItem('youtube_videos', JSON.stringify(adminVideos));
        }
        
        const videos = adminVideos.filter(video => video.status === "Active").map(video => ({
            id: video.id,
            title: video.title,
            category: video.category,
            views: video.views,
            points: video.points,
            thumbnail: video.thumbnail,
            verificationCode: video.verificationCode,
            youtubeUrl: video.youtubeUrl
        }));

        // Current user points
        // let userPoints = 1250; // Removed duplicate declaration
        let currentVideoId = null;
        let countdownInterval = null;
        
        // Initialize the page
        function initVideoSystem() {
            const videoGrid = document.getElementById('videoGrid');
            const pointsCount = document.getElementById('pointsCount');
            const returnNotification = document.getElementById('returnNotification');
            
            // Update points display
            pointsCount.textContent = userPoints.toLocaleString();
            
            // Render videos
            videos.forEach(video => {
                const videoCard = document.createElement('div');
                videoCard.className = 'video-card-verification';
                videoCard.dataset.id = video.id;
                videoCard.innerHTML = `
                    <div class="thumbnail-verification">
                        <img src="${video.thumbnail}" alt="${video.title}">
                        <div class="play-overlay-verification">
                            <div class="play-icon-verification">
                                <i class="fas fa-play"></i>
                            </div>
                        </div>
                    </div>
                    <div class="video-info-verification">
                        <div class="video-title-verification">${video.title}</div>
                        <div class="category-verification">${video.category}</div>
                        <div class="video-meta-verification">
                            <span>${video.views.toLocaleString()} views</span>
                            <span class="points-verification">+${video.points} points</span>
                        </div>
                        <button class="watch-btn-verification" data-id="${video.id}">
                            <i class="fas fa-play-circle"></i> Watch Now
                        </button>
                    </div>
                `;
                videoGrid.appendChild(videoCard);
            const pointsCount = document.getElementById('pointsBalance');
            
// Initialize modals and event listeners
initModals();
            pointsCount.textContent = userPoints.toLocaleString();
userPoints = parseInt(localStorage.getItem('userPoints')) || 1250;

// When awarding points
userPoints += video.points;
localStorage.setItem('userPoints', userPoints);

        // Initialize
let watchedVideos = JSON.parse(localStorage.getItem('watchedVideos')) || [];
            // Initialize the video system
        initVideoSystem();
        // Add timeout for video return detection
setTimeout(() => {
  if (localStorage.getItem('pendingVideo')) {
    localStorage.removeItem('pendingVideo');
    alert('Verification timed out');
  }
}, 300000); // 5 minutes
            
            // Check for pending video when window gains focus
            window.addEventListener('focus', checkForPendingVideo);
        }
        
        function checkForPendingVideo() {
            const pendingVideo = localStorage.getItem('pendingVideo');
            const verificationModal = document.getElementById('verificationModal');
            const returnNotification = document.getElementById('returnNotification');
            const countdownElement = document.getElementById('countdown');
            
            if (pendingVideo && verificationModal.style.display !== 'flex') {
                const videoData = JSON.parse(pendingVideo);
                currentVideoId = videoData.id;
                
                // Show the return notification
                returnNotification.style.display = "flex";
                
                // Start countdown for notification
                let seconds = 3;
                countdownElement.textContent = seconds;
                let notificationCountdown = setInterval(() => {
                    seconds--;
                    countdownElement.textContent = seconds;
                    
                    if (seconds <= 0) {
                        clearInterval(notificationCountdown);
                        returnNotification.style.display = "none";
                        
                        // Start the verification countdown
                        startCountdown();
                    }
                }, 1000);
            }
        }
        
        function startCountdown() {
            const countdownCircle = document.getElementById('countdownCircle');
            const verificationForm = document.getElementById('verificationForm');
            const countdownContainer = document.getElementById('countdownContainer');
            
            // Clear any existing interval
            if (countdownInterval) clearInterval(countdownInterval);
            
            // Open the verification modal
            document.getElementById('verificationModal').style.display = "flex";
            document.body.style.overflow = "hidden";
            
            // Reset the UI
            countdownCircle.textContent = 3;
            countdownContainer.style.display = "flex";
            verificationForm.style.display = "none";
            
            // Start the countdown
            let count = 3;
            countdownInterval = setInterval(() => {
                count--;
                countdownCircle.textContent = count;
                
                if (count <= 0) {
                    clearInterval(countdownInterval);
                    
                    // Show the verification form
                    countdownContainer.style.display = "none";
                    verificationForm.style.display = "block";
                    
                    // Focus on the input field
                    document.getElementById('verificationCode').focus();
                    
                    // Show a message that they returned from YouTube
                    document.getElementById('verificationMessage').textContent = 
                        "Please enter the verification code from the video";
                    document.getElementById('verificationMessage').className = 
                        "verification-message-verification";
                    document.getElementById('verificationMessage').style.display = "block";
                    
                    // Clear the pending video
                    localStorage.removeItem('pendingVideo');
                }
            }, 1000);
        }

        function initModals() {
            // DOM Elements
            const vpnModal = document.getElementById('vpnModal');
            const verificationModal = document.getElementById('verificationModal');
            const closeVpnModal = document.getElementById('closeVpnModal');
            const closeVerificationModal = document.getElementById('closeVerificationModal');
            const cancelVpnBtn = document.getElementById('cancelVpnBtn');
            const cancelVerification = document.getElementById('cancelVerification');
            const agreeCheckbox = document.getElementById('agreeCheckbox');
            const watchVideoBtn = document.getElementById('watchVideoBtn');
            const submitVerification = document.getElementById('submitVerification');
            const verificationCodeInput = document.getElementById('verificationCode');
            const verificationMessage = document.getElementById('verificationMessage');
            const pointsCount = document.getElementById('pointsCount');
            const returnNotification = document.getElementById('returnNotification');
            
            // Watch Now buttons
            document.getElementById('videoGrid').addEventListener('click', function(e) {
  if (e.target.closest('.watch-btn-verification')) {
    currentVideoId = parseInt(e.target.closest('.watch-btn-verification').dataset.id);
    openModal(vpnModal);
  }
});
            
            // VPN Modal Controls
            agreeCheckbox.addEventListener('change', () => {
                watchVideoBtn.disabled = !agreeCheckbox.checked;
            });
            
            watchVideoBtn.addEventListener('click', () => {
                const video = videos.find(v => v.id === currentVideoId);
                if (video) {
                    // Save pending video to localStorage
                    localStorage.setItem('pendingVideo', JSON.stringify({
                        id: video.id,
                        title: video.title
                    }));
                    
                    // Open YouTube video in a new tab
                    window.open(video.youtubeUrl, '_blank');
                    
                    // Close the modal
                    closeModal(vpnModal);
                }
            });
            
            // Verification Modal Controls
            submitVerification.addEventListener('click', () => {
                const enteredCode = verificationCodeInput.value.trim().toUpperCase();
                const video = videos.find(v => v.id === currentVideoId);
                
                if (!video) return;
                
                if (enteredCode === video.verificationCode) {
                    // Success
                    verificationMessage.textContent = "✓ Verification successful! Points awarded.";
                    verificationMessage.className = "verification-message-verification verification-success-verification";
                    
                    // Update user points
                    userPoints += video.points;
                    pointsCount.textContent = userPoints.toLocaleString();
                    
                    // Update admin video views
                    const adminVideos = JSON.parse(localStorage.getItem('youtube_videos'));
                    if (adminVideos) {
                        const adminVideo = adminVideos.find(v => v.id === video.id);
                        if (adminVideo) {
                            adminVideo.views += Math.floor(Math.random() * 1000);
                            localStorage.setItem('youtube_videos', JSON.stringify(adminVideos));
                        }
                    }
                    
                    // Update video views
                    video.views += Math.floor(Math.random() * 1000);
                    
                    // Remove the video card
                    const videoCard = document.querySelector(`.video-card-verification[data-id="${video.id}"]`);
                    if (videoCard) {
                        videoCard.remove();
                    }
                    
                    // Reset after success
                    setTimeout(() => {
                        closeModal(verificationModal);
                        verificationMessage.className = "verification-message-verification";
                        verificationMessage.textContent = "";
                        verificationCodeInput.value = "";
                        returnNotification.style.display = "none";
                        
                    }, 2000);
                } else {
                    // Error
                    verificationMessage.textContent = "✗ Incorrect verification code. Please try again.";
                    verificationMessage.className = "verification-message-verification verification-error-verification";
                    verificationCodeInput.value = "";
                    verificationCodeInput.focus();
                }
            });
            
            // Close modal functions
            function openModal(modal) {
                modal.style.display = "flex";
                document.body.style.overflow = "hidden";
            }
            
            function closeModal(modal) {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
                agreeCheckbox.checked = false;
                watchVideoBtn.disabled = true;
                verificationMessage.className = "verification-message-verification";
                verificationMessage.textContent = "";
                
                // Reset verification form if closing modal
                if (modal === verificationModal) {
                    const countdownContainer = document.getElementById('countdownContainer');
                    const verificationForm = document.getElementById('verificationForm');
                    countdownContainer.style.display = "flex";
                    verificationForm.style.display = "none";
                    
                    // Clear any running countdown
                    if (countdownInterval) {
                        clearInterval(countdownInterval);
                        countdownInterval = null;
                    }
                    
                    // Hide return notification
                    returnNotification.style.display = "none";
                    
                    // Clear the pending video
                    localStorage.removeItem('pendingVideo');
                }
            }
              // ---------- 1.  FETCH ACTIVE VIDEOS ----------
async function loadUserVideos(){
  const res = await fetch('../api/user/videos.php');
  const videos = await res.json();
  const grid = document.getElementById('videoGrid');
  grid.innerHTML='';
  videos.forEach(v=>{
    grid.innerHTML += `
    <div class="video-card-verification">
      <img src="https://img.youtube.com/vi/${v.youtubeId}/mqdefault.jpg">
      <div class="video-info-verification">
        <div class="video-title-verification">${v.title}</div>
        <span class="category-verification">${v.category}</span>
        <div class="video-meta-verification">
          <span>${v.views} views</span>
          <span class="points-verification">+${v.points} pts</span>
        </div>
        <button class="watch-btn-verification" onclick="startWatch(${v.id},'${v.verificationCode}',${v.points})">
          <i class="fas fa-play-circle"></i> Watch Now
        </button>
      </div>
    </div>`;
  });
}
loadUserVideos();

// ---------- 2.  WATCH FLOW ----------
let currentVideoId, currentCode, currentPoints;
function startWatch(id,code,pts){
  currentVideoId=id; currentCode=code; currentPoints=pts;
  document.getElementById('vpnModal').style.display='flex';
}

// ---------- 3.  VERIFY & AWARD ----------
function submitVerification(){
  const entered = document.getElementById('verificationCode').value.trim().toUpperCase();
  if(entered !== currentCode){ alert('Wrong code'); return; }
  fetch('../api/user/award.php',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({points:currentPoints})
  }).then(()=>{
    alert('Success! +'+currentPoints+' points');
    document.getElementById('verificationModal').style.display='none';
    loadUserVideos();                 // remove card
    updateTopPoints();                // balance badge
  });
}

// ---------- 4.  BALANCE BADGE ----------
function updateTopPoints(){
  fetch('../api/user/balance.php')
    .then(r=>r.json())
    .then(d=>document.getElementById('pointsCount').textContent=d.balance);
}
updateTopPoints();
            });
            
            // Close buttons
            closeVpnModal.addEventListener('click', () => closeModal(vpnModal));
            closeVerificationModal.addEventListener('click', () => closeModal(verificationModal));
            cancelVpnBtn.addEventListener('click', () => closeModal(vpnModal));
            cancelVerification.addEventListener('click', () => {
                closeModal(verificationModal);
                returnNotification.style.display = "none";
            });
            
            // Close modals when clicking outside
            [vpnModal, verificationModal].forEach(modal => {
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        closeModal(modal);
                    }
                });
            });
        }
        // For demonstration, we'll set this to true to show the watermark
            const hasVideos = false;
            
            if (hasVideos) {
                videoGrid.style.display = "grid";
                noVideosMessage.style.display = "none";
            } else {
                videoGrid.style.display = "none";
                noVideosMessage.style.display = "flex";
            }
        });
          // ========== VIDEO VERIFICATION SYSTEM ==========
  const VIDEO_STORAGE_KEY = 'youtube_videos';
  const WATCHED_VIDEOS_KEY = 'watchedVideos';
  const USER_POINTS_KEY = 'userPoints';
  
  // let userPoints = 0; // Removed duplicate declaration
  let currentVideoId = null;
  let countdownInterval = null;
  
  // Initialize on page load
  document.addEventListener('DOMContentLoaded', () => {
    initUserSystem();
    initModals();
  });

  function initUserSystem() {
    // Load user data
    userPoints = parseInt(localStorage.getItem(USER_POINTS_KEY)) || 1250;
    document.getElementById('pointsCount').textContent = userPoints.toLocaleString();
    
    // Load and render videos
    const watchedVideos = JSON.parse(localStorage.getItem(WATCHED_VIDEOS_KEY)) || [];
    const allVideos = JSON.parse(localStorage.getItem(VIDEO_STORAGE_KEY)) || [];
    
    // Filter active and unwatched videos
    const activeVideos = allVideos.filter(video => 
      video.status === "Active" && !watchedVideos.includes(video.id)
    );
    .then(d=>document.getElementById('pointsBalance').textContent=d.balance);
    renderVideoGrid(activeVideos);
  }

  function renderVideoGrid(videos) {
    const videoGrid = document.getElementById('videoGrid');
    videoGrid.innerHTML = '';
    
    videos.forEach(video => {
      videoGrid.innerHTML += `
        <div class="video-card-verification" data-id="${video.id}">
          <div class="thumbnail-verification">
            <img src="${video.thumbnail}" alt="${video.title}">
            <div class="play-overlay-verification">
              <div class="play-icon-verification">
                <i class="fas fa-play"></i>
              </div>
            </div>
          </div>
          <div class="video-info-verification">
            <div class="video-title-verification">${video.title}</div>
            <div class="category-verification">${video.category}</div>
            <div class="video-meta-verification">
    document.getElementById('pointsBalance').textContent = userPoints.toLocaleString();
              <span class="points-verification">+${video.points} points</span>
            </div>
            <button class="watch-btn-verification" data-id="${video.id}">
              <i class="fas fa-play-circle"></i> Watch Now
            </button>
          </div>
        </div>
      `;
    });
    
    // Add event listeners to new buttons
    document.querySelectorAll('.watch-btn-verification').forEach(btn => {
      btn.addEventListener('click', (e) => {
        currentVideoId = parseInt(e.target.dataset.id);
        document.getElementById('vpnModal').style.display = "flex";
      });
    });
  }

  // Verification handling functions
  // ... [Keep your existing initModals, checkForPendingVideo, startCountdown] ...
  
  // Add this to the verification success handler:
  function handleVerificationSuccess(video) {
    // Add to watched videos
    const watchedVideos = JSON.parse(localStorage.getItem(WATCHED_VIDEOS_KEY)) || [];
    watchedVideos.push(video.id);
    localStorage.setItem(WATCHED_VIDEOS_KEY, JSON.stringify(watchedVideos));
    
    // Update points
    userPoints += video.points;
    localStorage.setItem(USER_POINTS_KEY, userPoints.toString());
    document.getElementById('pointsCount').textContent = userPoints.toLocaleString();
    
    // Remove video card
    document.querySelector(`.video-card-verification[data-id="${video.id}"]`).remove();
  }
        
        
    </script>
        </div>
<script>
        
            // Dark mode toggle
            const darkModeToggle = document.getElementById('darkModeToggle');
            const body = document.body;
            
            // Check for saved user preference
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            darkModeToggle.checked = isDarkMode;
            body.classList.toggle('dark', isDarkMode);
            
            darkModeToggle.addEventListener('change', function() {
                const isDark = this.checked;
                body.classList.toggle('dark', isDark);
                localStorage.setItem('darkMode', isDark);
                
                // Smooth transition for background
                if(isDark) {
                    body.style.backgroundColor = '#111827';
                } else {
                    body.style.backgroundColor = '#ffffff';
                }
            
        });
        </script>
    <script>
      
        // Initialize the video system
        initVideoSystem();
        
        // Update points count on page load
        updateTopPoints();
        
        // Add event listener for focus to check for pending video
        window.addEventListener('focus', checkForPendingVideo);
        
        // Function to update points count
        function updateTopPoints() {
            fetch('../api/user/balance.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('pointsCount').textContent = data.points.toLocaleString();
                });
        }
    </script>
</body>
</html>