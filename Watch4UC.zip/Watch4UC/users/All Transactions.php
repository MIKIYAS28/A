<?php
// Load user data and require authentication
require_once 'includes/user-data.php';
requireLogin(); // Redirect to login if not authenticated
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>All Transactions - GameRewards</title>
     <!-- Single Tailwind CSS import -->
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    
    <!-- Font imports -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon library -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    
    <script>
        // Tailwind configuration
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'none': '0px',
                        'sm': '4px',
                        DEFAULT: '8px',
                        'md': '12px',
                        'lg': '16px',
                        'xl': '20px',
                        '2xl': '24px',
                        '3xl': '32px',
                        'full': '9999px',
                        'button': '8px'
                    }
                }
            }
        };
    </script>
    <!-- 1. Tailwind CDN (already identical) -->
<script src="https://cdn.tailwindcss.com/3.4.16"></script>
<script>
tailwind.config = { darkMode:'class', theme:{extend:{colors:{primary:'#FFD700',secondary:'#357ABD'}}}}
</script>

<!-- 2. Fonts & Icons (already identical) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        /* Custom styles */
        body {
            font-family: 'Inter', sans-serif;
            transition: background-color 0.5s ease, color 0.5s ease;
        }
        
        .sidebar {
            transition: transform 0.3s ease;
        }
        
        .sidebar-item:hover {
            background-color: rgba(255, 215, 0, 0.15);
        }
        
        .sidebar-item.active {
            background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
            border-left: 3px solid #FFD700;
        }
        
        .stat-card {
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
        }
        
        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #E5E7EB;
            transition: 0.4s;
            border-radius: 24px;
        }
        
        .slider:before {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: 0.4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background-color: #0284C7;
        }
        
        input:checked + .slider:before {
            transform: translateX(20px);
        }
        
        .custom-checkbox {
            appearance: none;
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e1;
            border-radius: 4px;
            background-color: white;
            cursor: pointer;
            position: relative;
        }
        
        .custom-checkbox:checked {
            background-color: #FFD700;
            border-color: #FFD700;
        }
        
        .custom-checkbox:checked::after {
            content: '';
            position: absolute;
            top: 3px;
            left: 6px;
            width: 4px;
            height: 8px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700 0%, #357ABD 100%);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .chatbot-button {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 56px;
            height: 56px;
            border-radius: 28px;
            background: linear-gradient(135deg, #FFD700 0%, #357ABD 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease;
            z-index: 50;
        }
        
        .chatbot-button:hover {
            transform: scale(1.05);
        }
        
        .video-thumbnail:hover .play-overlay {
            opacity: 1;
        }
        
        .play-overlay {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        /* Dark mode specific styles */
        .dark .bg-card-dark {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        }
        
        .dark .bg-white {
            background-color: #1f2937 !important;
        }
        
        .dark .text-gray-800 {
            color: #f3f4f6 !important;
        }
        
        .dark .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        .dark .bg-gray-50 {
            background-color: #374151 !important;
        }
        
        .dark .border-gray-200 {
            border-color: #374151 !important;
        }
        
        .dark .table-row {
            background-color: #1f2937;
        }
        
        .dark input,
        .dark select,
        .dark textarea {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #fff !important;
        }
        
        .dark input::placeholder {
            color: #6b7280 !important;
        }
        
        /* Input styles matching deposit.html */
        input, select, textarea {
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 0.5rem 0.75rem;
            width: 100%;
            transition: all 0.2s ease;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.2);
        }
        
        .dark input, .dark select, .dark textarea {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #fff !important;
        }
        
        .dark input:focus, .dark select:focus, .dark textarea:focus {
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.3);
        }
        
        /* Button styles matching deposit.html */
        .btn-primary {
            background: linear-gradient(90deg, #FFD700 0%, #357ABD 100%);
            color: white;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .btn-outline {
            border: 1px solid #FFD700;
            color: #FFD700;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .btn-outline:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
    </style>
  </head>
 <body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.html" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.html" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
        <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?= $profilePic ?>" alt="Profile" class="w-full h-full object-cover">
            </div>
            <div>
                <h1 class="text-2xl font-bold"><?= $username ?> </h1>
            </div>
        </div>
    </div>
</aside>
<!-- Mobile menu button -->
<button id="mobileMenuButton" class="fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
  <i class="ri-menu-line text-xl text-primary"></i>
</button>
      <!-- Main Content -->
      <main class="flex-1 ml-0 md:ml-72 p-4 md:p-8 transition-all duration-300">
        <div class="bg-gray-900 p-6 border-b border-gray-800">
          <h1 class="text-xl font-semibold text-gray-100">All Transactions</h1>
        </div>
        <div class="p-6">
          <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 class="text-lg font-bold mb-4 text-gray-800 dark:text-gray-100">Transaction History</h2>
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead>
                  <tr>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  <tr>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">2024-06-01</td>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">Deposit</td>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">$50.00</td>
                    <td class="px-4 py-2 text-green-600 font-semibold">Completed</td>
                  </tr>
                  <tr>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">2024-06-02</td>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">Withdrawal</td>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">$20.00</td>
                    <td class="px-4 py-2 text-yellow-500 font-semibold">Pending</td>
                  </tr>
                  <tr>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">2024-06-03</td>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">Transfer</td>
                    <td class="px-4 py-2 text-gray-700 dark:text-gray-200">$10.00</td>
                    <td class="px-4 py-2 text-red-500 font-semibold">Failed</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }

            // Dark mode toggle
            const darkModeToggle = document.getElementById('darkModeToggle');
            const body = document.body;
            
            // Check for saved user preference
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            darkModeToggle.checked = isDarkMode;
            body.classList.toggle('dark', isDarkMode);
            
            darkModeToggle.addEventListener('change', function() {
                const isDark = this.checked;
                body.classList.toggle('dark', isDark);
                localStorage.setItem('darkMode', isDark);
                
                // Smooth transition for background
                if(isDark) {
                    body.style.backgroundColor = '#111827';
                } else {
                    body.style.backgroundColor = '#ffffff';
                }
            });
        });
    </script>
    <script>
  const toggle = document.getElementById("darkModeToggle");
  const html = document.documentElement;

  // Load dark mode setting from local storage
  if (localStorage.getItem("theme") === "dark") {
    html.classList.add("dark");
    toggle.checked = true;
  }

  toggle.addEventListener("change", () => {
    if (toggle.checked) {
      html.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      html.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  });
</script>
  </body>
</html>
