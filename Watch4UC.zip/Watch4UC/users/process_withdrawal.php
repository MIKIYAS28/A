// process_withdrawal.php
<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

// Database connection (same as before)
// ...

// Get form data
$userId = $_SESSION['user_id'];
$amount = (float)$_POST['amount'];
$method = $_POST['method'];
$bankName = $_POST['bankName'] ?? '';
$accountNumber = $_POST['accountNumber'] ?? '';
$phoneNumber = $_POST['phoneNumber'] ?? '';
$accountHolder = $_POST['accountHolderName'] ?? '';

// Generate transaction ID
$transactionId = 'WD' . strtoupper(bin2hex(random_bytes(4)));

// Prepare destination details
if ($method === 'bank') {
    $destination = 'Bank Account';
    $details = $bankName . ' ••••' . substr($accountNumber, -4);
} else {
    $destination = 'Telebirr';
    $details = $phoneNumber;
}

// Insert into database
$sql = "INSERT INTO withdrawal_history (
    user_id, 
    date, 
    amount, 
    destination_account, 
    destination_details,
    transaction_id
) VALUES (?, NOW(), ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "idsss", 
    $userId,
    $amount,
    $destination,
    $details,
    $transactionId
);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "transaction_id" => $transactionId]);
} else {
    echo json_encode(["error" => "Withdrawal failed"]);
}

$stmt->close();
$conn->close();
?>