

<!DOCTYPE html>
<html lang="en">
<?php require_once __DIR__ . '/includes/user-data.php'; 
$csrfMeta = htmlspecialchars($csrfToken ?? ($_SESSION['csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8');

 ?>

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?= $csrfMeta ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Watch4UC</title>

    <!-- Single Tailwind CSS import -->
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    
    <!-- Font imports -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon library -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- 1. Tailwind CDN (already identical) -->
<script src="https://cdn.tailwindcss.com/3.4.16"></script>
<script>
tailwind.config = { darkMode:'class', theme:{extend:{colors:{primary:'#FFD700',secondary:'#357ABD'}}}}
</script>

<!-- 2. Fonts & Icons (already identical) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
<script src="assets/js/global.js"></script>
    <script>
        // Tailwind configuration
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'none': '0px',
                        'sm': '4px',
                        DEFAULT: '8px',
                        'md': '12px',
                        'lg': '16px',
                        'xl': '20px',
                        '2xl': '24px',
                        '3xl': '32px',
                        'full': '9999px',
                        'button': '8px'
                    }
                }
            }
        };
    </script>
    <style>
        /* Custom styles */
        body {
            font-family: 'Inter', sans-serif;
            transition: background-color 0.5s ease, color 0.5s ease;
        }
        
        /* Sidebar */
        .sidebar {
            transition: transform 0.3s ease;
        }
        .sidebar-item:hover {
            background-color: rgba(255, 215, 0, 0.15);
        }
        
        .sidebar-item.active {
            background: linear-gradient(90deg, rgba(255,215,0,0.2) 0%, rgba(255,215,0,0.1) 100%);
        }
        
        /* Header card */
        .header-card {
            background: var(--header-bg);
            color: white;
            padding: 1.5rem;
            border-radius: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px var(--shadow);
        }
        
        /* Stat cards */
        .stat-card {
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        input:checked + .slider:before {
            transform: translateX(20px);
        }
        
        .custom-checkbox {
            appearance: none;
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e1;
            border-radius: 4px;
            background-color: white;
            cursor: pointer;
            position: relative;
        }
        
        .custom-checkbox:checked {
            background-color: #FFD700;
            border-color: #FFD700;
        }
        
        .custom-checkbox:checked::after {
            content: '';
            position: absolute;
            top: 3px;
            left: 6px;
            width: 4px;
            height: 8px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700 0%, #357ABD 100%);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .chatbot-button {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 56px;
            height: 56px;
            border-radius: 28px;
            background: linear-gradient(135deg, #FFD700 0%, #357ABD 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease;
            z-index: 50;
        }
        
        .chatbot-button:hover {
            transform: scale(1.05);
        }
        
        .video-thumbnail:hover .play-overlay {
            opacity: 1;
        }
        
        .play-overlay {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        /* Dark mode specific styles */
        .dark .bg-card-dark {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        }
        
        .dark .bg-white {
            background-color: #1f2937 !important;
        }
        
        .dark .text-gray-800 {
            color: #f3f4f6 !important;
        }
        
        .dark .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        .dark .bg-gray-50 {
            background-color: #374151 !important;
        }
        
        .dark .border-gray-200 {
            border-color: #374151 !important;
        }
        
        .dark .table-row {
            background-color: #1f2937;
        }
        
        .dark input,
        .dark select,
        .dark textarea {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #fff !important;
        }
        
        .dark input::placeholder {
            color: #6b7280 !important;
        }
        
        /* Input styles matching deposit.html */
        input, select, textarea {
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 0.5rem 0.75rem;
            width: 100%;
            transition: all 0.2s ease;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.2);
        }
        
        .dark input, .dark select, .dark textarea {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #fff !important;
        }
        
        .dark input:focus, .dark select:focus, .dark textarea:focus {
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.3);
        }
        
        /* Button styles matching deposit.html */
        .btn-primary {
            background: linear-gradient(90deg, #FFD700 0%, #357ABD 100%);
            color: white;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .btn-outline {
            border: 1px solid #FFD700;
            color: #FFD700;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .btn-outline:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
        
        .file-input-label {
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        
        .file-input {
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .password-strength {
            height: 4px;
            background-color: #e2e8f0;
            border-radius: 2px;
            overflow: hidden;
            margin-top: 6px;
        }
        
        .password-strength-fill {
            height: 100%;
            border-radius: 2px;
            transition: width 0.3s ease;
        }
        
        .password-strength-weak {
            background-color: #ef4444;
            width: 25%;
        }
        
        .password-strength-medium {
            background-color: #f59e0b;
            width: 50%;
        }
        
        .password-strength-strong {
            background-color: #10b981;
            width: 100%;
        }
    </style>
    <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
<script>
  const db = firebase.firestore();
</script>

</head>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
       <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
    <!-- Mobile menu button -->
    <button id="mobileMenuButton" class="fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
      <i class="ri-menu-line text-xl text-primary"></i>
    </button>

    <!-- Main Content -->
    <main class="flex-1 ml-0 md:ml-72 p-4 md:p-8 transition-all duration-300">
        <!-- Header with Navigation -->
        <div class="bg-gradient-to-r from-primary to-secondary rounded-lg p-6 mb-8 text-white shadow-lg">
            <div class="flex items-center justify-between">
                <a href="Dashboard.html" class="flex items-center gap-3" data-miki-link="true" class="flex items-center text-white hover:text-white/90 transition-all">
                    <div class="w-8 h-8 flex items-center justify-center bg-white/20 rounded-full mr-2">
                        <i class="ri-arrow-left-line"></i>
                    </div>
                    <span>Back to Dashboard</span>
                </a>
                <h1 class="text-xl font-bold">Edit Profile</h1>
                <button id="saveProfileBtn" class="px-4 py-2 bg-white text-primary font-medium hover:bg-opacity-90 transition-all rounded-button whitespace-nowrap flex items-center">
                    <i class="ri-save-line mr-2"></i> Save Changes
                </button>
            </div>
        </div>

        <!-- Profile Edit Form -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-8">
            <input type="hidden" id="csrfToken" value="<?= htmlspecialchars($csrfToken ?? ($_SESSION['csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
            <!-- Profile Picture Section -->
            <div class="flex flex-col items-center mb-8">
                <div class="relative w-32 h-32 mb-4">
                    <div class="w-full h-full rounded-full bg-gray-200 overflow-hidden border-4 border-white shadow-md">
                        <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="w-full h-full object-cover">
                    </div>
                    <label class="file-input-label absolute bottom-0 right-0 w-10 h-10 bg-primary rounded-full flex items-center justify-center shadow-md border-2 border-white cursor-pointer">
                        <input type="file" class="file-input" id="profileImageInput" name="profile_pic" accept="image/*">
                        <i class="ri-camera-line text-white"></i>
                    </label>
                </div>
                <button class="text-primary font-medium text-sm flex items-center">
                    <i class="ri-image-edit-line mr-1"></i> Change Photo
                </button>
                <p class="text-gray-500 text-xs mt-2">Recommended: Square JPG or PNG, at least 300x300px</p>
            </div>

            <!-- Form Sections -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Personal Information -->
                <div class="lg:col-span-1">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Personal Information</h2>
                    <p class="text-gray-500 text-sm mb-6">Update your basic profile information</p>
                </div>
                
                <div class="lg:col-span-2 space-y-5">
                    <div>
                        <label for="fullName" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                        <input type="text" id="fullName" value="Michael Anderson" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                    </div>
                    
                    <div>
                        <label for="username" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Username</label>
                        <div class="relative">
                            <span class="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500">@</span>
                            <input type="text" id="username" name="username" value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>" class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                        </div>
                    </div>
                    
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email Address</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($userEmail ?? '', ENT_QUOTES, 'UTF-8') ?>" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                    </div>
                    
                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Phone Number <span class="text-gray-400 text-xs">(Optional)</span></label>
                        <input type="tel" id="phone" value="+1 (555) 123-4567" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                    </div>
                </div>

                <!-- Security Section -->
                <div class="lg:col-span-1 border-t lg:border-t-0 pt-6 lg:pt-0">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Security</h2>
                    <p class="text-gray-500 text-sm mb-6">Update your password and security settings</p>
                </div>
                
                <div class="lg:col-span-2 space-y-5 border-t lg:border-t-0 pt-6 lg:pt-0">
                    <div>
                        <label for="currentPassword" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Current Password</label>
                        <div class="relative">
                            <input type="password" id="currentPassword" placeholder="Enter current password" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                            <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 password-toggle">
                                <i class="ri-eye-off-line"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div>
                        <label for="newPassword" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">New Password</label>
                        <div class="relative">
                            <input type="password" id="newPassword" placeholder="Enter new password" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                            <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 password-toggle">
                                <i class="ri-eye-off-line"></i>
                            </button>
                        </div>
                        <div class="password-strength mt-2">
                            <div class="password-strength-fill password-strength-medium"></div>
                        </div>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Password strength: Medium</p>
                    </div>
                    
                    <div>
                        <label for="confirmPassword" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Confirm New Password</label>
                        <div class="relative">
                            <input type="password" id="confirmPassword" placeholder="Confirm new password" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700">
                            <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 password-toggle">
                                <i class="ri-eye-off-line"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-md">
                        <h4 class="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2 flex items-center">
                            <i class="ri-information-line mr-2"></i> Password Requirements
                        </h4>
                        <ul class="text-xs text-blue-700 dark:text-blue-300 space-y-1 ml-6 list-disc">
                            <li>At least 8 characters long</li>
                            <li>Include at least one uppercase letter</li>
                            <li>Include at least one number</li>
                            <li>Include at least one special character</li>
                        </ul>
                    </div>
                </div>

                <!-- Preferences Section -->
                <div class="lg:col-span-1 border-t pt-6">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Preferences</h2>
                    <p class="text-gray-500 text-sm mb-6">Manage your notification settings</p>
                </div>
                
                <div class="lg:col-span-2 space-y-5 border-t pt-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <h4 class="text-sm font-medium text-gray-800 dark:text-white">Email Notifications</h4>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Receive emails about your account activity</p>
                        </div>
                        <label class="custom-switch">
                            <input type="checkbox" checked>

                        </label>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <div>
                            <h4 class="text-sm font-medium text-gray-800 dark:text-white">SMS Notifications</h4>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Receive text messages for important updates</p>
                        </div>
                        <label class="custom-switch">
                            <input type="checkbox">
                            <span class="slider"></span>
                        </label>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <div>
                            <h4 class="text-sm font-medium text-gray-800 dark:text-white">Marketing Communications</h4>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Receive news, offers, and updates from us</p>
                        </div>
                        <label class="custom-switch">
                            <input type="checkbox" checked>
                            <span class="slider"></span>
                        </label>
                    </div>
                    
                    <div class="mt-4">
                        <label for="language" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Language</label>
                        <div class="relative">
                            <select id="language" class="w-full px-4 py-2 pr-8 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700 appearance-none">
                                <option value="en">English</option>
                                <option value="fr">French</option>
                                <option value="es">Spanish</option>
                                <option value="de">German</option>
                                <option value="zh">Chinese</option>
                            </select>
                            <div class="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                                <i class="ri-arrow-down-s-line text-gray-500"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex flex-col sm:flex-row gap-4 justify-end">
            <a href="https://readdy.ai/home/73bbcfd8-30b9-4021-947b-6e3a3d511887/76f21308-e32d-4ff1-ab03-5a39e6bb8956" data-readdy="true" class="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-white font-medium rounded-button hover:bg-gray-50 dark:hover:bg-gray-800 transition-all whitespace-nowrap text-center">
                Cancel
            </a>
            <button id="saveProfileBtnBottom" class="px-6 py-3 bg-gradient-to-r from-primary to-secondary text-white font-medium rounded-button hover:opacity-90 transition-all whitespace-nowrap">
                Save Changes
            </button>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar mobile menu toggle
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                btn.setAttribute('aria-expanded', isOpen);
            });
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', (e) => {
                if (window.innerWidth < 768 && !sidebar.contains(e.target) && e.target !== btn) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', 'false');
                }
            });

            // Dark mode toggle
            const darkToggle = document.getElementById('darkModeToggle');
            const htmlEl = document.documentElement;
            const saved = localStorage.getItem('theme');
            
            if (saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                htmlEl.classList.add('dark');
                darkToggle.checked = true;
            }
            
            darkToggle.addEventListener('change', () => {
                if (darkToggle.checked) {
                    htmlEl.classList.add('dark');
                    localStorage.setItem('theme', 'dark');
                } else {
                    htmlEl.classList.remove('dark');
                    localStorage.setItem('theme', 'light');
                }
            });

            // Profile image preview
            const profileImageInput = document.getElementById('profileImageInput');
            const profilePreview = document.getElementById('profilePreview');
            
            profileImageInput.addEventListener('change', function(e) {
                if (e.target.files.length > 0) {
                    const file = e.target.files[0];
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        profilePreview.src = e.target.result;
                    }
                    
                    reader.readAsDataURL(file);
                }
            });

            // Password toggle visibility
            document.querySelectorAll('.password-toggle').forEach(button => {
                button.addEventListener('click', function() {
                    const input = button.parentElement.querySelector('input[type="password"], input[type="text"]');
                    if (!input) return;
                    
                    const type = input.getAttribute('type');
                    if (type === 'password') {
                        input.setAttribute('type', 'text');
                        button.innerHTML = '<i class="ri-eye-line"></i>';
                    } else {
                        input.setAttribute('type', 'password');
                        button.innerHTML = '<i class="ri-eye-off-line"></i>';
                    }
                });
            });

            // Password strength indicator
            const newPasswordInput = document.getElementById('newPassword');
            const strengthIndicator = document.querySelector('.password-strength-fill');
            const strengthText = document.querySelector('.password-strength + p');
            
            newPasswordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                
                if (password.length >= 8) strength += 1;
                if (/[A-Z]/.test(password)) strength += 1;
                if (/[0-9]/.test(password)) strength += 1;
                if (/[^A-Za-z0-9]/.test(password)) strength += 1;
                
                if (strength === 0) {
                    strengthIndicator.className = 'password-strength-fill';
                    strengthIndicator.style.width = '0%';
                    strengthText.textContent = 'Password strength: Empty';
                } else if (strength <= 2) {
                    strengthIndicator.className = 'password-strength-fill password-strength-weak';
                    strengthIndicator.style.width = '25%';
                    strengthText.textContent = 'Password strength: Weak';
                } else if (strength === 3) {
                    strengthIndicator.className = 'password-strength-fill password-strength-medium';
                    strengthIndicator.style.width = '50%';
                    strengthText.textContent = 'Password strength: Medium';
                } else {
                    strengthIndicator.className = 'password-strength-fill password-strength-strong';
                    strengthIndicator.style.width = '100%';
                    strengthText.textContent = 'Password strength: Strong';
                }
            });

            // Profile update AJAX
            const saveButtons = [
                document.getElementById('saveProfileBtn'),
                document.getElementById('saveProfileBtnBottom')
            ];

            saveButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    // Collect form data
                    const username = document.getElementById('username').value.trim();
                    const email = document.getElementById('email').value.trim();
                    if (!username || !email) {
                        showToast('Please fill in all required fields.', 'error');
                        return;
                    }
                    button.disabled = true;
                    const originalText = button.textContent;
                    button.textContent = 'Saving...';
                    const fd = new FormData();
                    fd.append('username', username);
                    fd.append('email', email);
                    const csrf = document.getElementById('csrfToken')?.value || '';
                    if (csrf) fd.append('csrf', csrf);
                    const fileInput = document.getElementById('profileImageInput');
                    if (fileInput && fileInput.files && fileInput.files.length > 0) {
                        fd.append('profile_pic', fileInput.files[0]);
                    }

                    fetch('/Watch4UC/api/user/profile-update.php', {
                        method: 'POST',
                        body: fd,
                        credentials: 'include'
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            showToast('Your profile has been updated successfully.', 'success');
                            // Update UI
                            if (data.username) {
                                const nameInput = document.getElementById('username');
                                if (nameInput) nameInput.value = data.username;
                                const sidebarUsername = document.getElementById('sidebarUsername');
                                if (sidebarUsername) sidebarUsername.textContent = data.username;
                            }
                            if (data.profile_pic) {
                                const base = '/' + window.location.pathname.split('/')[1]; // e.g., /Watch4UC
                                const fullUrl = base + '/' + String(data.profile_pic).replace(/^\/+/, '');
                                const profilePreview = document.getElementById('profilePreview');
                                if (profilePreview) profilePreview.src = fullUrl;
                                const sidebarPic = document.getElementById('sidebarProfilePic');
                                if (sidebarPic) sidebarPic.src = fullUrl;
                            }
                            // Refresh shared cache if available
                            if (window.UserData?.refresh) {
                                window.UserData.refresh();
                            }
                        } else {
                            showToast(data.error || 'Profile update failed.', 'error');
                        }
                    })
                    .catch(() => {
                        showToast('Server error. Please try again later.', 'error');
                    })
                    .finally(() => {
                        button.disabled = false;
                        button.textContent = originalText;
                    });
                });
            });

            // Toast feedback function
            function showToast(message, type) {
                let toast = document.createElement('div');
                toast.className = `fixed top-4 right-4 px-4 py-3 rounded-md shadow-lg z-50 ${type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`;
                toast.textContent = message;
                document.body.appendChild(toast);
                setTimeout(() => { toast.remove(); }, 3000);
            }
        });
    </script>
</body>
</html>