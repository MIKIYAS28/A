<?php
require 'config.php';
require 'auth.php';

header("Content-Type: application/json");

switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST': // Create withdrawal (user)
        handlePostRequest();
        break;
    case 'GET': // Get withdrawals (admin)
        handleGetRequest();
        break;
    case 'PUT': // Update status (admin)
        handlePutRequest();
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

function handlePostRequest() {
    global $pdo;
    
    // User authentication
    $user = authenticateUser();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        return;
    }
    
    $data = json_decode(file_get_contents("php://input"), true);
    
    // Validate and process withdrawal request
    $required = ['amount', 'currency', 'payment_method', 'payment_details'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing $field"]);
            return;
        }
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO withdrawal_requests 
            (user_id, amount, currency, payment_method, payment_details) 
            VALUES (?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $user['id'],
            $data['amount'],
            $data['currency'],
            $data['payment_method'],
            json_encode($data['payment_details'])
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Withdrawal request submitted'
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
}

function handleGetRequest() {
    global $pdo;
    
    // Admin authentication
    $admin = authenticateAdmin();
    if (!$admin) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        return;
    }
    
    try {
        // Get parameters for filtering
        $status = $_GET['status'] ?? null;
        $search = $_GET['search'] ?? null;
        
        $query = "SELECT wr.*, u.username, u.email 
                FROM withdrawal_requests wr
                JOIN users u ON wr.user_id = u.id";
        
        $params = [];
        $conditions = [];
        
        if ($status && $status !== 'all') {
            $conditions[] = "wr.status = ?";
            $params[] = $status;
        }
        
        if ($search) {
            $conditions[] = "(u.username LIKE ? OR u.email LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        if (!empty($conditions)) {
            $query .= " WHERE " . implode(" AND ", $conditions);
        }
        
        $query .= " ORDER BY wr.created_at DESC";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Decode payment details
        foreach ($requests as &$request) {
            $request['payment_details'] = json_decode($request['payment_details'], true);
        }
        
        echo json_encode(['success' => true, 'data' => $requests]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
}

function handlePutRequest() {
    global $pdo;
    
    // Admin authentication
    $admin = authenticateAdmin();
    if (!$admin) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        return;
    }
    
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (empty($data['id']) || empty($data['status'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing request ID or status']);
        return;
    }
    
    try {
        // Update withdrawal status
        $stmt = $pdo->prepare("UPDATE withdrawal_requests SET status = ? WHERE id = ?");
        $stmt->execute([$data['status'], $data['id']]);
        
        // Update user balance if completed
        if ($data['status'] === 'completed') {
            $stmt = $pdo->prepare("SELECT user_id, amount FROM withdrawal_requests WHERE id = ?");
            $stmt->execute([$data['id']]);
            $request = $stmt->fetch();
            
            if ($request) {
                $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $stmt->execute([$request['amount'], $request['user_id']]);
            }
        }
        
        echo json_encode(['success' => true, 'message' => 'Status updated']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
}
?>