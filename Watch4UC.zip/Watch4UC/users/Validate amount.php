// Validate amount
if ($amount <= 0 || $amount > 10000) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid amount"]);
    exit;
}

// Validate bank details
if ($method === 'bank' && (empty($bankName) || empty($accountNumber) || !preg_match('/^\d{6,20}$/', $accountNumber))) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid bank details"]);
    exit;
}
// Check if user has exceeded withdrawal limit
$sql = "SELECT COUNT(*) as count FROM withdrawal_history 
        WHERE user_id = ? AND date > NOW() - INTERVAL 1 DAY";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if ($result['count'] >= 3) {
    http_response_code(429);
    echo json_encode(["error" => "Daily withdrawal limit exceeded"]);
    exit;
}