<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// If user is not logged in, redirect to login page
if (!isset($_SESSION['uid']) || !$_SESSION['uid']) {
    header('Location: ../login.html');
    exit;
}

// Get user data
require_once __DIR__ . '/../../config.php'; // adjust path if needed

try {
    $stmt = $pdo->prepare("SELECT id, username, email, role, balance, joined_at, profile_pic 
                           FROM users 
                           WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        session_destroy();
        header('Location: ../login.html');
        exit;
    }

    // Assign variables for navbar
    $username   = $user['username'];
    // Build an absolute web path for local uploads so it works from any subdirectory
    $appBase = '/' . explode('/', trim($_SERVER['SCRIPT_NAME'], '/'))[0]; // e.g., /Watch4UC
    if (!empty($user['profile_pic'])) {
        // If DB stores a relative path like 'uploads/filename', prefix with app base
        if (preg_match('/^https?:\/\//i', $user['profile_pic'])) {
            $profilePic = $user['profile_pic'];
        } else {
            $profilePic = $appBase . '/' . ltrim($user['profile_pic'], '/');
        }
    } else {
        $profilePic = 'https://ui-avatars.com/api/?name=' . urlencode($username) . '&background=FFD700&color=000';
    }
    $userEmail  = $user['email'];
    $userId     = $user['id'];
    $userBalance = $user['balance'] ?: 0;
    $memberSince = date('M j, Y', strtotime($user['joined_at']));
    
    // Get last watched video timestamp
    try {
        $lastWatchedStmt = $pdo->prepare("SELECT MAX(watched_at) as last_watched 
                                          FROM user_video_progress 
                                          WHERE user_id = ?");
        $lastWatchedStmt->execute([$userId]);
        $lastWatchedResult = $lastWatchedStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($lastWatchedResult && $lastWatchedResult['last_watched']) {
            $lastWatched = date('M j, Y g:i A', strtotime($lastWatchedResult['last_watched']));
        } else {
            $lastWatched = 'Never';
        }
    } catch (Exception $e) {
        error_log('Last watched query error: ' . $e->getMessage());
        $lastWatched = 'Unknown';
    }

} catch (Exception $e) {
    error_log('User data error: ' . $e->getMessage());
    $username = 'Guest';
    $profilePic = 'https://ui-avatars.com/api/?name=Guest&background=FFD700&color=000';
    $userBalance = 0;
    $memberSince = date('M j, Y');
    $lastWatched = 'Unknown';
}

// Helper function to prevent "Call to undefined function requireLogin" errors
function requireLogin($redirectUrl = '../login.html') {
    // Since this file already handles authentication above, 
    // this function is mainly for compatibility
    return true; // User is already authenticated if they reach this point
}
?>
