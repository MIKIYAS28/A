<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw History - <it>Watch4UC</it></title>
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- Global JavaScript -->
    <script src="assets/js/global.js"></script>


    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'button': '8px'
                    }
                }
            }
        }
    </script>
    
    <style>
        body {
              font-family: 'Inter', sans-serif;
            transition: background-color 0.5s ease, color 0.5s ease;
        }
        
        .sidebar {
            transition: transform 0.3s ease;
        }
        
        .sidebar-item:hover {
            background-color: rgba(255, 215, 0, 0.15);
        }
        
        .sidebar-item.active {
            background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
            border-left: 3px solid #FFD700;
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-completed {
            background-color: rgba(16, 185, 129, 0.1);
            color: #10B981;
        }
        
        .status-pending {
            background-color: rgba(245, 158, 11, 0.1);
            color: #F59E0B;
        }
        
        .status-failed {
            background-color: rgba(239, 68, 68, 0.1);
            color: #EF4444;
        }
        
.dark .table-row {
    background-color: #1f2937;
}

.dark input,
.dark select,
.dark textarea {
    background-color: #1f2937 !important;
    border-color: #374151 !important;
    color: #fff !important;
}

.dark input::placeholder {
    color: #6b7280 !important;
}

        .custom-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236B7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 1rem;
        }
        
        .date-picker {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236B7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 1rem;
        }
        
        .modal {
            transition: opacity 0.25s ease;
        }
        
        .modal-container {
            transform: scale(0.9);
            transition: transform 0.25s ease;
        }
        
        .modal.active .modal-container {
            transform: scale(1);
        }
        
        .sort-icon {
            display: inline-block;
            width: 0.75rem;
            height: 0.75rem;
            margin-left: 0.25rem;
            position: relative;
        }
        
        .sort-icon::before, .sort-icon::after {
            content: '';
            position: absolute;
            left: 0;
            width: 0;
            height: 0;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
        }
        
        .sort-icon::before {
            top: 0;
            border-bottom: 4px solid #CBD5E0;
        }
        
        .sort-icon::after {
            bottom: 0;
            border-top: 4px solid #CBD5E0;
        }
        
        .sort-asc .sort-icon::before {
            border-bottom-color: #4A90E2;
        }
        
        .sort-desc .sort-icon::after {
            border-top-color: #4A90E2;
        }
        
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
        }
        
        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #E5E7EB;
            transition: 0.4s;
            border-radius: 24px;
        }
        
        .slider:before {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: 0.4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background-color: #0284C7;
        }
        
        input:checked + .slider:before {
            transform: translateX(20px);
        }
        
        .custom-checkbox {
            appearance: none;
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e1;
            border-radius: 4px;
            background-color: white;
            cursor: pointer;
            position: relative;
        }
        
        .custom-checkbox:checked {
            background-color: #FFD700;
            border-color: #FFD700;
        }
        
        .custom-checkbox:checked::after {
            content: '';
            position: absolute;
            top: 3px;
            left: 6px;
            width: 4px;
            height: 8px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700 0%, #357ABD 100%);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .chatbot-button {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 56px;
            height: 56px;
            border-radius: 28px;
            background: linear-gradient(135deg, #FFD700 0%, #357ABD 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease;
            z-index: 50;
        }
        
        .chatbot-button:hover {
            transform: scale(1.05);
        }
        
        /* Dark mode specific styles */
        .dark .bg-card-dark {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        }
        
        .dark .bg-white {
            background-color: #1f2937 !important;
        }
        
        .dark .text-gray-800 {
            color: #f3f4f6 !important;
        }
        
        .dark .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        .dark .bg-gray-50 {
            background-color: #374151 !important;
        }
        
        .dark .border-gray-200 {
            border-color: #374151 !important;
        }
        
        .dark .table-row {
            background-color: #1f2937;
        }
        
        .dark input,
        .dark select,
        .dark textarea {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #fff !important;
        }
        
        .dark input::placeholder {
            color: #6b7280 !important;
        }
        .dark .bg-card-dark {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    }
    
    .dark .bg-white,
    .dark .bg-gray-900 {
        background-color: #1f2937 !important;
    }
    
    .dark .text-gray-800 {
        background-color: #1f2937 !important;
    }
    
    .dark .text-gray-800 {
        color: #e5e7eb !important;
    }
    
    .dark .text-gray-700 {
        color: #d1d5db !important;
    }
    
    .dark .bg-gray-50 {
        background-color: #374151 !important;
    }
    
    .dark .border-gray-200 {
        border-color: #374151 !important;
    }
    
    .dark .table-row {
        background-color: #1f2937;
    }
    
    .dark input,
    .dark select,
    .dark textarea {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
        color: #fff !important;
    }
    
    .dark input::placeholder {
        color: #6b7280 !important;
    }
    
    /* Fixes for layout */
    .transaction-summary {
        background-color: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 20px;
    }
    
    .dark .transaction-summary {
        background-color: #1f2937;
        border-color: #374151;
    }
    
    .withdrawal-container {
        display: grid;
        grid-template-columns: 1fr;
        gap: 30px;
    }
    
    @media (min-width: 1024px) {
        .withdrawal-container {
            grid-template-columns: 1fr 2fr;
        }
    }
    
    /* Color fixes to match All Videos page */
    .bg-gray-900 {
        background-color: #1f2937;
    }
    
    .dark .bg-gray-900 {
        background-color: #0f172a;
    }
    
    .border-gray-800 {
        border-color: #374151;
    }
    
    .text-gray-800 {
        color: #1f2937;
    }
    
    .dark .text-gray-800 {
        color: #e5e7eb;
    }
    
    .text-gray-700 {
        color: #374151;
    }
    
    .dark .text-gray-700 {
        color: #d1d5db;
    }
    
    .text-gray-500 {
        color: #6b7280;
    }
    
    .dark .text-gray-500 {
        color: #9ca3af;
    }
    
    .text-gray-600 {
        color: #4b5563;
    }
    
    .dark .text-gray-600 {
        color: #9ca3af;
    }
    
    .bg-primary {
        background-color: #FFD700;
    }
    
    .text-primary {
        color: #FFD700;
    }
    
    .bg-secondary {
        background-color: #357ABD;
    }
    
    .text-secondary {
        color: #357ABD;
    }
        
        /* Responsive adjustments */
        @media (max-width: 1024px) {
    .sidebar {
        transform: translateX(-100%);
        transition: transform 0.3s ease;
        width: 80vw;
        min-width: 220px;
        max-width: 320px;
    }
    .sidebar.open {
        transform: translateX(0);
    }
    .main-content {
        margin-left: 0;
    }
    .filters-card .flex-wrap {
        flex-direction: column;
        gap: 12px;
    }
    .filters-card .flex-wrap > * {
        width: 100%;
    }
    .export-btn {
        margin-left: 0;
        margin-top: 12px;
    }
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    table {
        min-width: 800px;
    }
    .header-container {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }
}
@media (max-width: 640px) {
    .header-container {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }
    .date-range-filters {
        flex-direction: column;
        gap: 8px;
    }
    .date-range-filters > div {
        width: 100%;
    }
    .pagination-container {
        flex-direction: column;
        gap: 12px;
    }
    .pagination-buttons {
        width: 100%;
        justify-content: space-between;
    }
    .modal-container {
        width: 95%;
        margin: 0 auto;
    }
    .modal-content {
        flex-direction: column;
    }
    .modal-section {
        width: 100%;
    }
}
    </style>
    <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
<script>
  const db = firebase.firestore();
</script>

</head>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white transition-colors duration-300">
    <!-- Sidebar -->
        <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Watch4UC Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
    
    <!-- Mobile overlay -->
    
<!-- ✅  Global right-top toggle -->
<button
            id="mobileMenuButton"
            class="fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700"
            aria-controls="sidebar"
            aria-expanded="false"
            aria-label="Open menu"
        >
            <i class="ri-menu-line text-xl text-primary"></i>
        </button>

    <!-- Main Content -->
<main id="mainContent" class="flex-1 ml-0 md:ml-64 transition-all duration-300 overflow-x-hidden p-4 md:p-8">
        <div class="max-w-7xl mx-auto">
            <!-- Header with Back Button -->
            <div class="flex items-center mb-6 header-container">
                <a href="#" class="w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-gray-800 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors mr-4">
                    <i class="ri-arrow-left-line text-gray-700 dark:text-gray-300"></i>
                </a>
                <h1 class="text-2xl font-bold text-gray-800 dark:text-white">Withdraw History</h1>
            </div>
            
            <!-- Filters Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-6 filters-card">
                <div class="flex flex-wrap items-center gap-4">
                    <!-- Date Range Filters -->
                    <div class="flex items-center space-x-2 date-range-filters">
                        <div class="relative flex-1">
                            <input type="date" id="dateFrom" class="date-picker w-full pl-3 pr-10 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" placeholder="From">
                        </div>
                        <span class="text-gray-500 dark:text-gray-400">to</span>
                        <div class="relative flex-1">
                            <input type="date" id="dateTo" class="date-picker w-full pl-3 pr-10 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" placeholder="To">
                        </div>
                    </div>
                    
                    <!-- Status Filter -->
                    <div class="relative flex-1">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <i class="ri-filter-3-line text-gray-500 dark:text-gray-400"></i>
                        </div>
                        <select id="statusFilter" class="custom-select w-full pl-10 pr-10 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                            <option value="all">All Status</option>
                            <option value="completed">Completed</option>
                            <option value="pending">Pending</option>
                            <option value="failed">Failed</option>
                        </select>
                    </div>
                    
                    <!-- Search Box -->
                    <div class="relative flex-1">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <i class="ri-search-line text-gray-500 dark:text-gray-400"></i>
                        </div>
                        <input type="text" id="searchInput" placeholder="Search by transaction ID or account" class="w-full pl-10 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                    </div>
                    
                    <!-- Export Button -->
                    <button id="exportBtn" class="ml-auto bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors flex items-center whitespace-nowrap export-btn">
                        <div class="w-5 h-5 flex items-center justify-center mr-2">
                            <i class="ri-download-2-line"></i>
                        </div>
                        <span>Export</span>
                    </button>
                </div>
            </div>
            
            <!-- Transactions Table -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
                <div class="overflow-x-auto table-responsive">
                    <table class="min-w-full">
                        <thead>
                            <tr class="border-b border-gray-200 dark:border-gray-700">
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer" data-sort="date">
                                    <div class="flex items-center">
                                        Date
                                        <span class="sort-icon"></span>
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer" data-sort="amount">
                                    <div class="flex items-center">
                                        Amount
                                        <span class="sort-icon"></span>
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                    Destination Account
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                    Status
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                    Transaction ID
                                </th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700" id="transactionsTable">
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">May 3, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">750 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-bank-line"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Primary Bank Account</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">****6789</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-pending">
                                        <i class="ri-time-line mr-1"></i> Pending
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD78945612</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD78945612">Details</button>
                                </td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">Apr 28, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">1,200 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-paypal-fill"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">PayPal</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">michael.anderson@example.com</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-completed">
                                        <i class="ri-checkbox-circle-line mr-1"></i> Completed
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD65432198</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD65432198">Details</button>
                                </td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">Apr 21, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">500 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-bank-line"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Secondary Bank Account</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">****3456</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-completed">
                                        <i class="ri-checkbox-circle-line mr-1"></i> Completed
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD32165498</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD32165498">Details</button>
                                </td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">Apr 15, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">350 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-bank-line"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Primary Bank Account</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">****6789</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-failed">
                                        <i class="ri-close-circle-line mr-1"></i> Failed
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD98765432</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD98765432">Details</button>
                                </td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">Apr 8, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">800 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-bank-line"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Primary Bank Account</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">****6789</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-completed">
                                        <i class="ri-checkbox-circle-line mr-1"></i> Completed
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD45678912</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD45678912">Details</button>
                                </td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">Apr 2, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">650 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-paypal-fill"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">PayPal</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">michael.anderson@example.com</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-completed">
                                        <i class="ri-checkbox-circle-line mr-1"></i> Completed
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD12378945</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD12378945">Details</button>
                                </td>
                            </tr>
                            
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">Mar 25, 2025</td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">450 Br</td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                            <i class="ri-bank-line"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Secondary Bank Account</div>
                                            <div class="text-xs text-gray-500 dark:text-gray-400">****3456</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <span class="status-badge status-completed">
                                        <i class="ri-checkbox-circle-line mr-1"></i> Completed
                                    </span>
                                </td>
                                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">WD87654321</td>
                                <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                                    <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="WD87654321">Details</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <!-- Empty State (Hidden by default) -->
                <div id="emptyState" class="hidden py-12 flex flex-col items-center justify-center">
                    <div class="w-16 h-16 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-full mb-4">
                        <i class="ri-file-search-line text-gray-400 dark:text-gray-500 ri-2x"></i>
                    </div>
                    <h3 class="text-lg font-medium text-gray-700 dark:text-gray-300 mb-1">No transactions found</h3>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Try adjusting your search or filter to find what you're looking for.</p>
                </div>
                
                <!-- Pagination -->
                <div class="flex flex-col md:flex-row items-center justify-between mt-6 pagination-container">
                    <div class="text-sm text-gray-500 dark:text-gray-400 mb-4 md:mb-0">
                        Showing <span id="startRecord">1</span> to <span id="endRecord">7</span> of <span id="totalRecords">7</span> entries
                    </div>
                    <div class="flex items-center space-x-2 pagination-buttons">
                        <button id="prevPage" class="px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap">
                            <i class="ri-arrow-left-s-line mr-1"></i> Previous
                        </button>
                        <div class="flex items-center space-x-1" id="paginationNumbers">
                            <button class="w-8 h-8 flex items-center justify-center rounded-lg bg-gradient-to-r from-primary to-secondary text-white">1</button>
                        </div>
                        <button id="nextPage" class="px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap">
                            Next <i class="ri-arrow-right-s-line ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Transaction Details Modal -->
    <div id="detailsModal" class="modal fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
        <div class="modal-container bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full mx-4">
            <div class="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <h3 class="text-xl font-bold text-gray-800 dark:text-white">Transaction Details</h3>
                <button id="closeModal" class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                    <i class="ri-close-line text-gray-500 dark:text-gray-400"></i>
                </button>
            </div>
            <div class="p-6">
                <div class="flex flex-col md:flex-row md:space-x-6">
                    <div class="md:w-1/2 mb-6 md:mb-0 modal-section">
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-1">Transaction ID</span>
                            <span id="modalTransactionId" class="block text-base font-medium text-gray-800 dark:text-white">WD78945612</span>
                        </div>
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-1">Date & Time</span>
                            <span id="modalDateTime" class="block text-base font-medium text-gray-800 dark:text-white">May 3, 2025 • 14:32:45 UTC</span>
                        </div>
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-1">Amount</span>
                            <span id="modalAmount" class="block text-lg font-bold text-gray-800 dark:text-white">750 Br</span>
                        </div>
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-1">Destination Account</span>
                            <div id="modalDestination" class="flex items-center mt-1">
                                <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                                    <i class="ri-bank-line"></i>
                                </div>
                                <div>
                                    <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Primary Bank Account</div>
                                    <div class="text-xs text-gray-500 dark:text-gray-400">****6789</div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-1">Note</span>
                            <p id="modalNote" class="text-sm text-gray-700 dark:text-gray-300">Monthly withdrawal to primary bank account.</p>
                        </div>
                    </div>
                    <div class="md:w-1/2 modal-section">
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-1">Status</span>
                            <span id="modalStatus" class="status-badge status-pending inline-flex items-center">
                                <i class="ri-time-line mr-1"></i> Pending
                            </span>
                        </div>
                        <div class="mb-6">
                            <span class="block text-sm text-gray-500 dark:text-gray-400 mb-2">Transaction Timeline</span>
                            <div class="space-y-4">
                                <div class="flex items-start">
                                    <div class="flex flex-col items-center mr-4">
                                        <div class="w-6 h-6 flex items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30 text-green-500 dark:text-green-300">
                                            <i class="ri-check-line"></i>
                                        </div>
                                        <div class="w-0.5 h-12 bg-gray-200 dark:bg-gray-600 mt-1"></div>
                                    </div>
                                    <div>
                                        <span class="block text-sm font-medium text-gray-700 dark:text-gray-300">Withdrawal Initiated</span>
                                        <span class="block text-xs text-gray-500 dark:text-gray-400">May 3, 2025 • 14:32:45</span>
                                    </div>
                                </div>
                                <div class="flex items-start">
                                    <div class="flex flex-col items-center mr-4">
                                        <div class="w-6 h-6 flex items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30 text-green-500 dark:text-green-300">
                                            <i class="ri-check-line"></i>
                                        </div>
                                        <div class="w-0.5 h-12 bg-gray-200 dark:bg-gray-600 mt-1"></div>
                                    </div>
                                    <div>
                                        <span class="block text-sm font-medium text-gray-700 dark:text-gray-300">Processing</span>
                                        <span class="block text-xs text-gray-500 dark:text-gray-400">May 3, 2025 • 14:35:12</span>
                                    </div>
                                </div>
                                <div class="flex items-start">
                                    <div class="flex flex-col items-center mr-4">
                                        <div class="w-6 h-6 flex items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-500 dark:text-blue-300">
                                            <i class="ri-time-line"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <span class="block text-sm font-medium text-gray-700 dark:text-gray-300">Funds Transfer</span>
                                        <span class="block text-xs text-gray-500 dark:text-gray-400">Estimated: May 4-6, 2025</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-6">
                    <div class="flex items-start">
                        <div class="w-6 h-6 flex items-center justify-center mt-0.5 mr-3 text-primary">
                            <i class="ri-information-line"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300">Note</h4>
                            <p id="modalNote" class="text-xs text-gray-500 dark:text-gray-400 mt-1">Monthly withdrawal to primary bank account.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="p-6 border-t border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row justify-between gap-4">
                <button id="downloadReceipt" class="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors flex items-center justify-center whitespace-nowrap">
                    <div class="w-5 h-5 flex items-center justify-center mr-2">
                        <i class="ri-download-2-line"></i>
                    </div>
                    <span>Download Receipt</span>
                </button>
                <button id="closeModalBtn" class="bg-gradient-to-r from-primary to-secondary text-white py-2 px-6 rounded-lg font-medium hover:opacity-90 transition-opacity whitespace-nowrap">
                    Close
                </button>
            </div>
        </div>
    </div>

    <!-- Chatbot Button -->
    <div class="chatbot-button">
        <i class="ri-customer-service-2-line text-white text-xl"></i>
    </div>

    <script>
 // Responsive sidebar toggle for mobile
    document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }
            
            window.addEventListener('resize', handleResize);
            handleResize();
        });
        
         // Dark mode toggle
            if (darkModeToggle && !darkModeToggle.hasAttribute('data-initialized')) {
                const isDarkMode = localStorage.getItem('darkMode') === 'true';
                darkModeToggle.checked = isDarkMode;
                body.classList.toggle('dark', isDarkMode);
                darkModeToggle.setAttribute('data-initialized', 'true');
                
                darkModeToggle.addEventListener('change', function() {
                    const isDark = this.checked;
                    body.classList.toggle('dark', isDark);
                    localStorage.setItem('darkMode', isDark);
                    
                    if(isDark) {
                        body.style.backgroundColor = '#111827';
                    } else {
                        body.style.backgroundColor = '#ffffff';
                    }
                });
            }
            
    
            
            
            // Modal functionality
            const detailsModal = document.getElementById('detailsModal');
            const detailsBtns = document.querySelectorAll('.details-btn');
            const closeModal = document.getElementById('closeModal');
            const closeModalBtn = document.getElementById('closeModalBtn');
            
            function openModal(transactionId) {
                detailsModal.classList.remove('hidden');
                setTimeout(() => {
                    detailsModal.classList.add('active');
                }, 10);
                
                // Update modal content based on transaction ID
                document.getElementById('modalTransactionId').textContent = transactionId;
            }
            
            function closeModalFunc() {
                detailsModal.classList.remove('active');
                setTimeout(() => {
                    detailsModal.classList.add('hidden');
                }, 250);
            }
            
            detailsBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const transactionId = this.getAttribute('data-id');
                    openModal(transactionId);
                });
            });
            
            closeModal.addEventListener('click', closeModalFunc);
            closeModalBtn.addEventListener('click', closeModalFunc);
            detailsModal.addEventListener('click', function(e) {
                if (e.target === detailsModal) {
                    closeModalFunc();
                }
            });
            
            // Table sorting
            const sortableHeaders = document.querySelectorAll('th[data-sort]');
            let currentSort = { column: 'date', direction: 'desc' };
            
            function updateSortIndicators() {
                sortableHeaders.forEach(header => {
                    const column = header.getAttribute('data-sort');
                    header.classList.remove('sort-asc', 'sort-desc');
                    
                    if (column === currentSort.column) {
                        header.classList.add(currentSort.direction === 'asc' ? 'sort-asc' : 'sort-desc');
                    }
                });
            }
            
            sortableHeaders.forEach(header => {
                header.addEventListener('click', function() {
                    const column = this.getAttribute('data-sort');
                    
                    if (column === currentSort.column) {
                        currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
                    } else {
                        currentSort.column = column;
                        currentSort.direction = 'asc';
                    }
                    
                    updateSortIndicators();
                });
            });
            
            updateSortIndicators();
            
            // Filtering and search functionality
            const statusFilter = document.getElementById('statusFilter');
            const searchInput = document.getElementById('searchInput');
            const dateFrom = document.getElementById('dateFrom');
            const dateTo = document.getElementById('dateTo');
            const emptyState = document.getElementById('emptyState');
            const transactionsTable = document.getElementById('transactionsTable');
            
            function applyFilters() {
                const status = statusFilter.value;
                const search = searchInput.value.toLowerCase();
                const fromDate = dateFrom.value;
                const toDate = dateTo.value;
                
                // This would normally filter the data from an API
                // For demo purposes, we're just showing/hiding the empty state
                
                // Simulate empty results if all filters are applied
                if (status !== 'all' && search.length > 0 && fromDate && toDate) {
                    transactionsTable.classList.add('hidden');
                    emptyState.classList.remove('hidden');
                } else {
                    transactionsTable.classList.remove('hidden');
                    emptyState.classList.add('hidden');
                }
            }
            
            statusFilter.addEventListener('change', applyFilters);
            searchInput.addEventListener('input', applyFilters);
            dateFrom.addEventListener('change', applyFilters);
            dateTo.addEventListener('change', applyFilters);
            
            // Export functionality
            const exportBtn = document.getElementById('exportBtn');
            exportBtn.addEventListener('click', function() {
                alert('Export functionality would generate a CSV or PDF file with the current filtered transactions.');
            });
            
            // Download receipt
            const downloadReceipt = document.getElementById('downloadReceipt');
            downloadReceipt.addEventListener('click', function() {
                alert('Receipt download functionality would generate a PDF of the transaction details.');
            });
            
            // Pagination functionality
            const prevPage = document.getElementById('prevPage');
            const nextPage = document.getElementById('nextPage');
            
            prevPage.addEventListener('click', function() {
                alert('Previous page functionality would load the previous page of transactions.');
            });
            
            nextPage.addEventListener('click', function() {
                alert('Next page functionality would load the next page of transactions.');
            });
    </script>
    <script>
    // Replace existing fetch call with:
fetch('get_withdrawal_history.php')
  .then(res => res.json())
  .then(data => {
    if (data.error) {
        alert(data.error);
        return;
    }
    
    const tableBody = document.getElementById('transactionsTable');
    tableBody.innerHTML = '';
    
    data.transactions.forEach(tx => {
        // Determine status classes and icon
        let statusClass, statusIcon;
        switch(tx.status) {
            case 'completed':
                statusClass = 'status-completed';
                statusIcon = 'ri-checkbox-circle-line';
                break;
            case 'failed':
                statusClass = 'status-failed';
                statusIcon = 'ri-close-circle-line';
                break;
            default:
                statusClass = 'status-pending';
                statusIcon = 'ri-time-line';
        }
        
        // Determine icon based on destination
        const isBank = tx.destination_account.toLowerCase().includes('bank');
        const destinationIcon = isBank ? 'ri-bank-line' : 'ri-phone-line';
        
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50 dark:hover:bg-gray-700';
        row.innerHTML = `
            <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${tx.date}</td>
            <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-700 dark:text-gray-300">${tx.amount}</td>
            <td class="px-4 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <div class="w-8 h-8 flex items-center justify-center bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-500 dark:text-blue-300 mr-3">
                        <i class="${destinationIcon}"></i>
                    </div>
                    <div>
                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">${tx.destination_account}</div>
                        <div class="text-xs text-gray-500 dark:text-gray-400">${tx.destination_details}</div>
                    </div>
                </div>
            </td>
            <td class="px-4 py-4 whitespace-nowrap">
                <span class="status-badge ${statusClass}">
                    <i class="${statusIcon} mr-1"></i> ${tx.status}
                </span>
            </td>
            <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">${tx.transaction_id}</td>
            <td class="px-4 py-4 whitespace-nowrap text-right text-sm">
                <button class="text-primary hover:text-blue-700 dark:hover:text-blue-400 font-medium details-btn" data-id="${tx.transaction_id}">Details</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    // Update record counters
    document.getElementById('totalRecords').textContent = data.total;
    document.getElementById('endRecord').textContent = Math.min(7, data.total);
    
    // Reattach event listeners
    document.querySelectorAll('.details-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const transactionId = this.getAttribute('data-id');
            const transaction = data.transactions.find(t => t.transaction_id === transactionId);
            openModal(transaction);
        });
    });
});
    </script>
   
</body>
</html>