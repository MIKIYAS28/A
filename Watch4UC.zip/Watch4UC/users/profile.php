<?php
require_once 'includes/functions.php';
require_login();
$user = getUserById($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? '')) die('Invalid CSRF');

    $username = sanitize_input($_POST['username']);
    $email    = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);

    if ($username && $email && updateUserProfile($_SESSION['user_id'], $username, $email)) {
        $_SESSION['msg'] = 'Profile updated';
        header('Location: profile.php'); exit;
    }
    $error = 'Update failed';
}
?>
<!doctype html>
<html>
<head><title>Profile Settings</title></head>
<body>
<?php if (isset($error)) echo "<p>$error</p>"; ?>
<form method="post">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    Username: <input name="username" value="<?= htmlspecialchars($user['username']) ?>" required><br>
    Email:    <input name="email" type="email" value="<?= htmlspecialchars($user['email']) ?>" required><br>
    <button>Save</button>
</form>

<h2>Change Password</h2>
<form action="change_password.php" method="post">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    Current: <input type="password" name="current" required><br>
    New:     <input type="password" name="new" required><br>
    Confirm: <input type="password" name="confirm" required><br>
    <button>Change</button>
</form>
</body>
</html>