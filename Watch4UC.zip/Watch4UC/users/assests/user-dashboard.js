// user-dashboard.js
function fetchNotifications() {
  fetch('/api/get-notifications.php')
    .then(res => res.json())
    .then(data => {
      document.querySelector('#notif-count').textContent = data.unreadCount || '';
      const ul = document.querySelector('#notif-list');
      ul.innerHTML = '';
      data.notifications.forEach(n => {
        const li = document.createElement('li');
        if (!n.is_read) li.classList.add('unread');
        li.textContent = n.message;
        li.onclick = () => window.location = n.url || '#';
        ul.append(li);
      });
    });
}
fetchNotifications();
setInterval(fetchNotifications, 15000);
