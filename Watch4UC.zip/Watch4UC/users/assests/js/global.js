// 1. Global fetch wrapper
const api = (endpoint, payload = {}) =>
  fetch('../api/' + endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid: localStorage.getItem('uid'), ...payload })
  }).then(r => r.json());

// 2. Auto refresh balance badge everywhere
window.refreshBalance = () =>
  api('user/balance.php').then(d => {
    document.querySelectorAll('#pointsBalance').forEach(el => el.textContent = d.points || 0);
    document.querySelectorAll('#currentPoints').forEach(el => el.textContent = d.points || 0);
  });

// 3. Dark-mode toggle (single listener)
document.getElementById('darkModeToggle')?.addEventListener('change', e => {
  const dark = e.target.checked;
  document.documentElement.classList.toggle('dark', dark);
  localStorage.setItem('darkMode', dark);
});
document.addEventListener('DOMContentLoaded', () => {
  const btn   = document.getElementById('mobileMenuButton');
  const panel = document.getElementById('sidebar');

  btn?.addEventListener('click', () => {
    panel.classList.toggle('-translate-x-full');
    btn.classList.toggle('sidebar-open');
    btn.setAttribute('aria-expanded', panel.classList.contains('-translate-x-full') ? 'false' : 'true');
  });

  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#sidebar') && !e.target.closest('#mobileMenuButton')) {
      panel.classList.add('-translate-x-full');
      btn.setAttribute('aria-expanded', 'false');
    }
  });
});