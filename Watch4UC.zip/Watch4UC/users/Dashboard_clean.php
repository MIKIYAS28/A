<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
// Check if user is logged in
if (!isset($_SESSION['uid']) || !$_SESSION['uid']) {
    header('Location: ../login.html');
    exit;
}

// Get user data
require __DIR__ . '/../config.php';

try {
    $stmt = $pdo->prepare("SELECT id, username, email, role, balance, joined_at, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        session_destroy();
        header('Location: ../login.html');
        exit;
    }
    
    // Set user variables
    $username = $user['username'];
    $profilePic = $user['profile_pic'] ?: 'https://ui-avatars.com/api/?name=' . urlencode($username) . '&background=FFD700&color=000';
    $memberSince = date('M j, Y', strtotime($user['joined_at']));
    $userPoints = $user['balance'] ?: 0;
    $userId = $user['id'];
    $userEmail = $user['email'];
    
    // Get user's statistics (only from existing tables)
    $activeDays = 0; // Will be calculated when user_task_completions table exists
    $totalTasksCompleted = 0;
    $totalCoinsEarned = $userPoints;
    $tasksToday = 0;
    $coinsToday = 0;
    
    // Try to get stats if user_task_completions table exists
    try {
        $stmt = $pdo->prepare("SELECT 
            COUNT(DISTINCT DATE(completed_at)) as active_days,
            COUNT(*) as total_tasks_completed,
            COALESCE(SUM(points_earned), 0) as total_coins_earned
            FROM user_task_completions 
            WHERE user_id = ?");
        $stmt->execute([$userId]);
        $userStats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get today's stats
        $stmt = $pdo->prepare("SELECT 
            COUNT(*) as tasks_today,
            COALESCE(SUM(points_earned), 0) as coins_today
            FROM user_task_completions 
            WHERE user_id = ? AND DATE(completed_at) = CURDATE()");
        $stmt->execute([$userId]);
        $todayStats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $activeDays = $userStats['active_days'] ?: 0;
        $totalTasksCompleted = $userStats['total_tasks_completed'] ?: 0;
        $totalCoinsEarned = $userStats['total_coins_earned'] ?: 0;
        $tasksToday = $todayStats['tasks_today'] ?: 0;
        $coinsToday = $todayStats['coins_today'] ?: 0;
        
    } catch (Exception $e) {
        // Table doesn't exist yet, use default values
        $activeDays = 0;
        $totalTasksCompleted = 0;
        $totalCoinsEarned = $userPoints;
        $tasksToday = 0;
        $coinsToday = 0;
    }
    
} catch (Exception $e) {
    error_log('Dashboard error: ' . $e->getMessage());
    $username = 'Guest';
    $profilePic = 'https://ui-avatars.com/api/?name=Guest&background=FFD700&color=000';
    $memberSince = date('M j, Y');
    $userPoints = 0;
    $userId = 0;
    $activeDays = 0;
    $totalTasksCompleted = 0;
    $totalCoinsEarned = 0;
    $tasksToday = 0;
    $coinsToday = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= $_SESSION['csrf'] ?? '' ?>">
    <title>UC FORGE</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    
    <!-- Font imports -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon library -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    
    <!-- External CSS -->
    <link href="assets/css/dashboard.css" rel="stylesheet">
    
    <script>
        // Tailwind configuration
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'none': '0px',
                        'sm': '4px',
                        DEFAULT: '8px',
                        'md': '12px',
                        'lg': '16px',
                        'xl': '20px',
                        '2xl': '24px',
                        '3xl': '32px',
                        'full': '9999px',
                        'button': '8px'
                    }
                }
            }
        };
    </script>
    
</head>
<script>
  if (performance && performance.navigation && performance.navigation.type === 2) { location.reload(true); }
  window.onpageshow = function(e){ if (e.persisted) location.reload(true); };
</script>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white transition-colors duration-300">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
        <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img id="sidebarProfilePic" src="<?= $profilePic ?>" alt="Profile" class="w-full h-full object-cover">
            </div>
            <div>
                <h1 class="text-2xl font-bold" id="sidebarUsername"><?= $username ?></h1>
            </div>
        </div>
    </div>
</aside>

    <!-- Mobile menu button -->
    <button type="button" id="mobileMenuButton" class="md:hidden fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
  <i class="ri-menu-line text-xl text-primary"></i>
</button>
    
    <!-- Main Content -->
    <main class="flex-1 ml-0 md:ml-72 p-4 md:p-8 transition-all duration-300">
       
        <!-- Header with Profile -->
<div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
    <div class="flex items-center mb-4 md:mb-0">
        <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white">
            <img id="headerProfilePic" src="<?= $profilePic ?>" alt="Profile" class="w-full h-full object-cover">
        </div>
        <div>
            <h1 class="text-2xl font-bold" id="welcomeMessage">Welcome, <?= $username ?> 👋</h1>
            <p class="text-sm opacity-80">Member since <span id="memberSince"><?= $memberSince ?></span></p>
        </div>
    </div>
    
    <!-- Logout button -->
    <div class="flex items-center">
        <a href="../auth/logout.php" class="flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors duration-200 text-sm font-medium">
            <i class="ri-logout-circle-line mr-2"></i>
            Logout
        </a>
    </div>
</div>

<!-- Quick Stats Cards -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Total Balance -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow">
        <div class="flex items-center justify-between mb-4">
            <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                <i class="ri-coins-line text-2xl text-primary"></i>
            </div>
            <span class="text-sm font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Balance</span>
        </div>
        <h3 class="text-2xl font-bold text-gray-800 dark:text-white mb-1"><?= number_format($userPoints) ?></h3>
        <p class="text-sm text-gray-600 dark:text-gray-400">Total UC Points</p>
    </div>
    
    <!-- Today's Earnings -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow">
        <div class="flex items-center justify-between mb-4">
            <div class="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <i class="ri-medal-line text-2xl text-blue-600"></i>
            </div>
            <span class="text-sm font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">Today</span>
        </div>
        <h3 class="text-2xl font-bold text-gray-800 dark:text-white mb-1"><?= $coinsToday ?></h3>
        <p class="text-sm text-gray-600 dark:text-gray-400">Coins Earned</p>
    </div>
    
    <!-- Tasks Completed -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow">
        <div class="flex items-center justify-between mb-4">
            <div class="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                <i class="ri-task-line text-2xl text-green-600"></i>
            </div>
            <span class="text-sm font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Total</span>
        </div>
        <h3 class="text-2xl font-bold text-gray-800 dark:text-white mb-1"><?= $totalTasksCompleted ?></h3>
        <p class="text-sm text-gray-600 dark:text-gray-400">Tasks Completed</p>
    </div>
    
    <!-- Active Days -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow">
        <div class="flex items-center justify-between mb-4">
            <div class="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
                <i class="ri-calendar-check-line text-2xl text-orange-600"></i>
            </div>
            <span class="text-sm font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded-full">Streak</span>
        </div>
        <h3 class="text-2xl font-bold text-gray-800 dark:text-white mb-1"><?= $activeDays ?></h3>
        <p class="text-sm text-gray-600 dark:text-gray-400">Active Days</p>
    </div>
</div>

<!-- Main Dashboard Grid -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
    
    <!-- Quick Actions -->
    <div class="lg:col-span-2">
        
        <!-- Quick Tasks -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4">Quick Actions</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <a href="Daily Task.php" class="flex items-center p-4 bg-primary/10 rounded-lg hover:bg-primary/20 transition-colors group">
                    <i class="ri-task-line text-primary text-2xl mr-4 group-hover:scale-110 transition-transform"></i>
                    <div>
                        <span class="font-medium text-gray-800 dark:text-white block">Complete Daily Tasks</span>
                        <span class="text-sm text-gray-600 dark:text-gray-400">Earn UC points daily</span>
                    </div>
                </a>
                <a href="All video List.php" class="flex items-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors group">
                    <i class="ri-video-line text-blue-600 text-2xl mr-4 group-hover:scale-110 transition-transform"></i>
                    <div>
                        <span class="font-medium text-gray-800 dark:text-white block">Watch Videos</span>
                        <span class="text-sm text-gray-600 dark:text-gray-400">Watch and earn rewards</span>
                    </div>
                </a>
                <a href="Redeem PUBG UC.php" class="flex items-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors group">
                    <i class="ri-gift-line text-green-600 text-2xl mr-4 group-hover:scale-110 transition-transform"></i>
                    <div>
                        <span class="font-medium text-gray-800 dark:text-white block">Redeem UC</span>
                        <span class="text-sm text-gray-600 dark:text-gray-400">Convert points to UC</span>
                    </div>
                </a>
                <a href="Withdrawal.php" class="flex items-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/30 transition-colors group">
                    <i class="ri-bank-card-line text-purple-600 text-2xl mr-4 group-hover:scale-110 transition-transform"></i>
                    <div>
                        <span class="font-medium text-gray-800 dark:text-white block">Withdraw Funds</span>
                        <span class="text-sm text-gray-600 dark:text-gray-400">Cash out your earnings</span>
                    </div>
                </a>
            </div>
        </div>
        
    </div>
    
    <div class="space-y-6">
        
        <!-- Progress Card -->
        <div class="bg-gradient-to-br from-primary to-secondary rounded-xl p-6 text-white">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-bold">Today's Progress</h3>
                <i class="ri-trophy-line text-2xl opacity-80"></i>
            </div>
            <div class="mb-4">
                <div class="flex justify-between mb-2">
                    <span class="text-sm opacity-90">Tasks Completed</span>
                    <span class="text-sm font-medium"><?= $tasksToday ?>/10</span>
                </div>
                <div class="w-full bg-white/20 rounded-full h-2">
                    <div class="bg-white rounded-full h-2" style="width: <?= min(100, ($tasksToday / 10) * 100) ?>%"></div>
                </div>
            </div>
            <p class="text-sm opacity-90">Keep going! Complete more tasks to earn bonus rewards.</p>
        </div>
        
        <!-- Quick Stats -->
        <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4">Quick Stats</h3>
            <div class="space-y-4">
                <div class="flex justify-between items-center">
                    <span class="text-sm text-gray-600 dark:text-gray-400">Current Balance</span>
                    <span class="font-bold text-primary"><?= number_format($userPoints) ?> UC</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-sm text-gray-600 dark:text-gray-400">Today's Earnings</span>
                    <span class="font-bold text-green-600"><?= $coinsToday ?> UC</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-sm text-gray-600 dark:text-gray-400">Total Tasks</span>
                    <span class="font-bold text-blue-600"><?= $totalTasksCompleted ?></span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-sm text-gray-600 dark:text-gray-400">Member Since</span>
                    <span class="font-bold text-gray-800 dark:text-gray-200"><?= $memberSince ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

    </main>

<!-- JavaScript -->
<script>
// User data for JavaScript
window.userData = {
    username: '<?= $username ?>',
    points: <?= $userPoints ?>,
    userId: <?= $userId ?>,
    email: '<?= $userEmail ?>'
};

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu functionality
    const mobileMenuButton = document.getElementById('mobileMenuButton');
    const sidebar = document.getElementById('sidebar');
    
    if (mobileMenuButton && sidebar) {
        mobileMenuButton.addEventListener('click', function() {
            sidebar.classList.toggle('-translate-x-full');
        });
        
        // Close sidebar when clicking outside
        document.addEventListener('click', function(event) {
            if (!sidebar.contains(event.target) && !mobileMenuButton.contains(event.target)) {
                sidebar.classList.add('-translate-x-full');
            }
        });
    }
    
    // Dark mode toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    
    if (darkModeToggle) {
        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            body.classList.add('dark');
            darkModeToggle.checked = true;
        }
        
        darkModeToggle.addEventListener('change', function() {
            if (this.checked) {
                body.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            } else {
                body.classList.remove('dark');
                localStorage.setItem('theme', 'light');
            }
        });
    }
});
</script>

</body>
</html>
