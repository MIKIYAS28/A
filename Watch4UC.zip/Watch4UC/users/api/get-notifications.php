// /api/get-notifications.php
<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
header('Content-Type: application/json');
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['error'=>'Not authenticated']); exit; }
require_once __DIR__ . '/../../config.php';
$uid = $_SESSION['user_id'];
$stmt = $pdo->prepare("
  SELECT id,message,url,is_read 
  FROM notifications 
  WHERE user_id = :uid 
  ORDER BY created_at DESC 
  LIMIT 20
");
$stmt->execute([':uid'=>$uid]);
$notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt2 = $pdo->prepare("
  SELECT COUNT(*) 
  FROM notifications 
  WHERE user_id = :uid AND is_read = 0
");
$stmt2->execute([':uid'=>$uid]);
$unread = $stmt2->fetchColumn();

echo json_encode(['notifications'=>$notes,'unreadCount'=>$unread]);
