<?php
$redemptionsFile = __DIR__.'/../../data/redemptions.json';
if (!is_dir(__DIR__.'/../../data')) mkdir(__DIR__.'/../../data',0777,true);

function read($f){return json_decode(file_get_contents($f),true)?:[];}
function write($f,$d){file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT));}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action){
    case 'getRedemptions':
        echo json_encode(['ok'=>true,'list'=>read($redemptionsFile)]);
        break;
    case 'updateStatus':
        $id=$_POST['id']; $status=$_POST['status']; $notes=$_POST['notes']??'';
        $list = read($redemptionsFile);
        foreach($list as &$r) if($r['id']===$id){$r['status']=$status;$r['notes']=$notes;}
        write($redemptionsFile,$list);
        echo json_encode(['ok'=>true]);
        break;
    default:
        echo json_encode(['error'=>'unknown action']);
}