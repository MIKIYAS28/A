<?php
require_once '../../config.php';   // if you have a shared config
$uid = $_SESSION['uid'] ?? ($_POST['uid'] ?? 1);

$balancesFile   = __DIR__.'/../../data/balances.json';
$redemptionsFile= __DIR__.'/../../data/redemptions.json';
if (!is_dir(__DIR__.'/../../data')) mkdir(__DIR__.'/../../data',0777,true);

function read($f){return json_decode(file_get_contents($f),true)?:[];}
function write($f,$d){file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT));}

$action = $_POST['action'] ?? '';
switch ($action){
    case 'getBalance':
        echo json_encode(['ok'=>true,'balance'=>read($balancesFile)[$uid]??0]);
        break;
    case 'setBalance':
        $bal = read($balancesFile); $bal[$uid]=(int)$_POST['amount']; write($balancesFile,$bal);
        echo json_encode(['ok'=>true]);
        break;
    case 'addRedemption':
        $list = read($redemptionsFile);
        $list[]=[
            'id'=>'req_'.time(),
            'uid'=>$uid,
            'user'=>$_POST['user'],
            'pubgUsername'=>$_POST['pubgUsername'],
            'pubgId'=>$_POST['pubgId'],
            'pointsUsed'=>10000,
            'date'=>date('c'),
            'status'=>'Pending',
            'notes'=>''
        ];
        write($redemptionsFile,$list);
        echo json_encode(['ok'=>true]);
        break;
    default:
        echo json_encode(['error'=>'unknown action']);
}