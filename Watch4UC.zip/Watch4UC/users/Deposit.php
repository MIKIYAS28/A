<!DOCTYPE html>
<html lang="en">
    <?php require_once __DIR__ . '/includes/user-data.php'; ?>


<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?= $csrfMeta ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit - Watch4UC</title>
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <!-- 1. Tailwind CDN (already identical) -->
<script src="https://cdn.tailwindcss.com/3.4.16"></script>
<script>
tailwind.config = { darkMode:'class', theme:{extend:{colors:{primary:'#FFD700',secondary:'#357ABD'}}}}
</script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css">
<!-- 2. Fonts & Icons (already identical) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
<script src="assets/js/global.js"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'none': '0px',
                        'sm': '4px',
                        DEFAULT: '8px',
                        'md': '12px',
                        'lg': '16px',
                        'xl': '20px',
                        '2xl': '24px',
                        '3xl': '32px',
                        'full': '9999px',
                        'button': '8px'
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        .video-glow {
            text-shadow: 0 0 8px #FFD700;
        }
        :where([class^="ri-"])::before {
            content: "\f3c2";
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: white;
        }
        .dark body {
            background-color: #111827;
        }
        
        /* Sidebar styles */
        .sidebar-item:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
        .sidebar-item.active {
            background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
            border-left: 3px solid #FFD700;
        }
        .dark .sidebar-item:hover {
            background-color: rgba(255, 215, 0, 0.15);
        }
        .dark .sidebar-item.active {
            background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
            border-left: 3px solid #FFD700;
        }
        
        /* Payment method selection */
        .payment-method-radio:checked + label {
            border-color: #FFD700;
            background-color: rgba(255, 215, 0, 0.05);
        }
        .payment-method-radio:checked + label .check-circle {
            display: flex !important;
        }
        .check-circle {
            display: none;
        }
        .dark .payment-method-radio:checked + label {
            border-color: #FFD700;
            background-color: rgba(255, 215, 0, 0.1);
        }
        
        /* Input styles */
        input, select, .custom-checkbox {
            background-color: white;
            border-color: #e5e7eb;
            color: #111827;
        }
        .dark input, .dark select, .dark .custom-checkbox {
            background-color: #1f2937;
            border-color: #374151;
            color: #f3f4f6;
        }
        input:focus, select:focus {
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.2);
        }
        .dark input:focus, .dark select:focus {
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.2);
        }
        
        /* Logo styles */
        .logo-rounded {
            border-radius: 12px;
            overflow: hidden;
        }
        .logo-square {
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .logo-square:hover {
            transform: scale(1.05);
        }
        
        /* Custom switch */
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
        }
        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #e2e8f0;
            transition: .4s;
            border-radius: 24px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        input:checked + .slider {
            background-color: #FFD700;
        }
        input:checked + .slider:before {
            transform: translateX(20px);
        }
        
        /* Custom radio */
        .custom-radio {
            position: relative;
            display: inline-block;
            width: 20px;
            height: 20px;
        }
        .custom-radio input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .radio-circle {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border: 2px solid #e2e8f0;
            border-radius: 50%;
            transition: .2s;
        }
        input:checked + .radio-circle {
            border-color: #FFD700;
        }
        input:checked + .radio-circle:after {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #FFD700;
        }
        
        /* Hide number input arrows */
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        /* Accessibility styles */
        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0,0,0,0);
            white-space: nowrap;
            border: 0;
        }
        @media (max-width: 1024px) {
            body.flex {
                flex-direction: column;
            }
            aside {
                position: fixed;
                left: 0;
                top: 0;
                width: 80vw;
                max-width: 320px;
                height: 100vh;
                z-index: 30;
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            aside.open {
                transform: translateX(0);
            }
            main {
                margin-left: 0 !important;
                padding: 1rem !important;
            }
        }
        @media (max-width: 768px) {
            .p-8 { padding: 1rem !important; }
            .mb-8 { margin-bottom: 1.5rem !important; }
            .rounded-lg { border-radius: 0.75rem !important; }
            .text-xl { font-size: 1.125rem !important; }
        }
        /* Responsive styles for mobile */
        @media (max-width: 640px) {
            .p-8, .sm\:p-6, .md\:p-8 { padding: 0.5rem !important; }
            .mb-8 { margin-bottom: 1rem !important; }
            .rounded-lg { border-radius: 0.5rem !important; }
            .text-xl { font-size: 1rem !important; }
            .main-content, .stats-container, .tasks-container, .bg-white, .shadow-md { padding: 0.5rem !important; }
            .flex { flex-direction: column !important; }
            .w-72 { width: 100vw !important; }
        }
        @media (max-width: 480px) {
            .deposit-btn, #depositButton { width: 100%; font-size: 1rem; padding: 0.75rem 0; }
        }
        
        /* Currency selector styling */
        #currency {
            min-width: 60px;
            padding-right: 2rem;
            background: transparent;
            border: none;
            color: inherit;
            font-size: 1rem;
        }
        #currency:focus {
            outline: 2px solid #FFD700;
            outline-offset: 2px;
        }
        
        /* Deposit button styling */
        #depositButton {
            outline: none;
            transition: box-shadow 0.2s;
        }
        #depositButton:focus {
            box-shadow: 0 0 0 3px #FFD70055;
        }
    </style>
</head>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white">
    <!-- Sidebar -->
   <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>

        <!-- Navigation Menu -->
        
       <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
<!-- Mobile menu button -->
 <button type="button" id="mobileMenuButton" class="md:hidden fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
  <i class="ri-menu-line text-xl text-primary"></i>
</button>
<!-- Main Content -->
    <main class="flex-1 ml-0 md:ml-72 p-4 md:p-8 transition-all duration-300">
       
        <!-- Header with Navigation -->
        <div class="bg-gradient-to-r from-primary to-secondary rounded-lg p-6 mb-8 text-white shadow-lg">
            <div class="flex items-center justify-between">
                <a href="Modern-Rewards-Dashboard.html" class="back-button flex items-center">
                    <div class="w-8 h-8 flex items-center justify-center bg-white/20 rounded-full mr-2">
                        <i class="ri-arrow-left-line"></i>
                    </div>
                    <span>Back to Dashboard</span>
                </a>
                <h1 class="text-xl font-bold">Deposit</h1>
                <div class="flex flex-col items-end">
                    <span class="text-sm text-white/80">Available Balance</span>
                    <span class="text-xl font-bold">0</span>
                </div>
            </div>
        </div>

        <!-- Deposit Form -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-8">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-6">Add Funds to Your Account</h2>

            <!-- Payment Method Selection -->
            <div class="mb-8">
                <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Select Payment Method</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <!-- Credit/Debit Card -->
                    <div>
                        <input type="radio" id="card" name="paymentMethod" value="card" class="payment-method-radio hidden" checked>
                        <label for="card" class="block p-4 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer hover:border-primary/50 transition-all relative">
                            <div class="check-circle hidden absolute top-3 right-3 w-5 h-5 bg-primary rounded-full items-center justify-center text-white">
                                <i class="ri-check-line text-xs"></i>
                            </div>
                            <div class="flex items-center mb-3">
                                <div class="w-10 h-10 flex items-center justify-center bg-blue-50 dark:bg-gray-700 rounded-full mr-3 text-primary">
                                    <i class="ri-bank-card-fill"></i>
                                </div>
                                <span class="font-medium text-gray-800 dark:text-white">Credit/Debit Card</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-visa-fill text-blue-800 dark:text-blue-400"></i>
                                </div>
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-mastercard-fill text-orange-500 dark:text-orange-400"></i>
                                </div>
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-bank-card-fill text-gray-500 dark:text-gray-400"></i>
                                </div>
                            </div>
                        </label>
                    </div>

                    <!-- Bank Transfer -->
                    <div>
                        <input type="radio" id="bank" name="paymentMethod" value="bank" class="payment-method-radio hidden">
                        <label for="bank" class="block p-4 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer hover:border-primary/50 transition-all relative">
                            <div class="check-circle hidden absolute top-3 right-3 w-5 h-5 bg-primary rounded-full items-center justify-center text-white">
                                <i class="ri-check-line text-xs"></i>
                            </div>
                            <div class="flex items-center mb-3">
                                <div class="w-10 h-10 flex items-center justify-center bg-green-50 dark:bg-gray-700 rounded-full mr-3 text-green-600 dark:text-green-400">
                                    <i class="ri-bank-fill"></i>
                                </div>
                                <span class="font-medium text-gray-800 dark:text-white">Bank Transfer</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-bank-fill text-blue-700 dark:text-blue-400"></i>
                                </div>
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-secure-payment-fill text-green-600 dark:text-green-400"></i>
                                </div>
                            </div>
                        </label>
                    </div>

                    <!-- Cryptocurrency -->
                    <div>
                        <input type="radio" id="crypto" name="paymentMethod" value="crypto" class="payment-method-radio hidden">
                        <label for="crypto" class="block p-4 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer hover:border-primary/50 transition-all relative">
                            <div class="check-circle hidden absolute top-3 right-3 w-5 h-5 bg-primary rounded-full items-center justify-center text-white">
                                <i class="ri-check-line text-xs"></i>
                            </div>
                            <div class="flex items-center mb-3">
                                <div class="w-10 h-10 flex items-center justify-center bg-yellow-50 dark:bg-gray-700 rounded-full mr-3 text-yellow-600 dark:text-yellow-400">
                                    <i class="ri-bitcoin-fill"></i>
                                </div>
                                <span class="font-medium text-gray-800 dark:text-white">Cryptocurrency</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-bitcoin-fill text-orange-500 dark:text-orange-400"></i>
                                </div>
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-ethereum-fill text-purple-600 dark:text-purple-400"></i>
                                </div>
                                <div class="w-8 h-8 flex items-center justify-center">
                                    <i class="ri-coin-fill text-yellow-500 dark:text-yellow-400"></i>
                                </div>
                            </div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Amount Input -->
            <div class="mb-8">
                <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Enter Amount</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="md:col-span-2">
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                                <span class="text-gray-500 dark:text-gray-400 text-lg font-medium">$</span>
                            </div>
                            <input type="number" id="amount" class="w-full pl-10 pr-4 py-4 text-2xl font-medium border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700" placeholder="0.00" min="10" max="10000">
                            <div class="absolute inset-y-0 right-0 flex items-center pr-4">
                                <div class="relative">
                                    <select id="currency" title="Select currency" class="appearance-none bg-transparent pr-8 py-2 text-gray-500 dark:text-gray-400 focus:outline-none cursor-pointer border-none">
                                        <option value="USD">USD</option>
                                        <option value="EUR">EUR</option>
                                        <option value="GBP">GBP</option>
                                        <option value="JPY">JPY</option>
                                    </select>
                                    <div class="absolute inset-y-0 right-0 flex items-center pointer-events-none">
                                        <i class="ri-arrow-down-s-line text-gray-500 dark:text-gray-400"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-between mt-2 text-sm text-gray-500 dark:text-gray-400">
                            <span>Min: $10.00</span>
                            <span>Max: $10,000.00</span>
                        </div>
                    </div>
                    <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Transaction Summary</h4>
                        <div class="space-y-2">
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600 dark:text-gray-400">Amount:</span>
                                <span class="font-medium text-gray-800 dark:text-white">$<span id="summaryAmount">0.00</span></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600 dark:text-gray-400">Fee (2.5%):</span>
                                <span class="font-medium text-gray-800 dark:text-white">$<span id="summaryFee">0.00</span></span>
                            </div>
                            <div class="border-t border-gray-200 dark:border-gray-600 my-2 pt-2"></div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700 dark:text-gray-300">Total:</span>
                                <span class="font-bold text-gray-900 dark:text-white">$<span id="summaryTotal">0.00</span></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Details -->
            <div id="paymentDetailsContainer" class="mb-8">
                <!-- Credit Card Form (default) -->
                <div id="cardDetails" class="payment-details-section">
                    <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Card Details</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="md:col-span-2">
                            <label for="cardNumber" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Card Number</label>
                            <div class="relative">
                                <input type="text" id="cardNumber" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700" placeholder="1234 5678 9012 3456">
                                <div class="absolute right-3 top-1/2 transform -translate-y-1/2">
                                    <i class="ri-bank-card-line text-gray-400"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <label for="cardName" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Cardholder Name</label>
                            <input type="text" id="cardName" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700" placeholder="John Smith">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label for="expiryDate" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Expiry Date</label>
                                <input type="text" id="expiryDate" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700" placeholder="MM/YY">
                            </div>
                            <div>
                                <label for="cvv" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">CVV</label>
                                <div class="relative">
                                    <input type="text" id="cvv" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700" placeholder="123">
                                    <div class="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer" title="3-digit security code on the back of your card">
                                        <i class="ri-question-line text-gray-400"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bank Transfer Form (hidden by default) -->
                <div id="bankDetails" class="payment-details-section hidden">
                    <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Bank Transfer Details</h3>
                    <div class="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg mb-4">
                        <div class="flex items-start">
                            <div class="w-6 h-6 flex items-center justify-center bg-blue-100 dark:bg-blue-800 rounded-full mr-3 text-blue-600 dark:text-blue-400 mt-0.5">
                                <i class="ri-information-line text-sm"></i>
                            </div>
                            <div>
                                <p class="text-sm text-blue-800 dark:text-blue-200">Please use the following details to make your bank transfer. Your account will be credited once we receive the payment.</p>
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Bank Name</p>
                            <p class="text-sm font-medium text-gray-800 dark:text-white">Global Financial Bank</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Account Name</p>
                            <p class="text-sm font-medium text-gray-800 dark:text-white">Blueskill Finance Ltd</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Account Number</p>
                            <p class="text-sm font-medium text-gray-800 dark:text-white">8734 5612 3890</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Sort Code / Routing Number</p>
                            <p class="text-sm font-medium text-gray-800 dark:text-white">40-35-21</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">SWIFT/BIC Code</p>
                            <p class="text-sm font-medium text-gray-800 dark:text-white">GLFIBANK123</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Reference</p>
                            <p class="text-sm font-medium text-gray-800 dark:text-white">DEP-MA4582</p>
                        </div>
                    </div>
                    <div class="mt-4">
                        <label for="transferReference" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Your Transfer Reference (Optional)</label>
                        <input type="text" id="transferReference" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700" placeholder="Enter your bank reference if available">
                    </div>
                </div>

                <!-- Cryptocurrency Form (hidden by default) -->
                <div id="cryptoDetails" class="payment-details-section hidden">
                    <h3 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Cryptocurrency Details</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="cryptoType" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Select Cryptocurrency</label>
                            <div class="relative">
                                <select id="cryptoType" class="w-full px-4 py-2 pr-8 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700 appearance-none">
                                    <option value="btc">Bitcoin (BTC)</option>
                                    <option value="eth">Ethereum (ETH)</option>
                                    <option value="usdt">Tether (USDT)</option>
                                    <option value="usdc">USD Coin (USDC)</option>
                                </select>
                                <div class="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                                    <i class="ri-arrow-down-s-line text-gray-500 dark:text-gray-400"></i>
                                </div>
                            </div>
                            <div class="mt-4">
                                <label for="walletAddress" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Wallet Address</label>
                                <div class="relative">
                                    <input type="text" id="walletAddress" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all text-gray-800 dark:text-white dark:bg-gray-700 font-mono text-sm" value="bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh" readonly>
                                    <button class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400 hover:text-primary" title="Copy address">
                                        <i class="ri-file-copy-line"></i>
                                    </button>
                                </div>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Send only BTC to this address. Sending any other coin may result in permanent loss.</p>
                            </div>
                        </div>
                        <div class="flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                            <div class="w-48 h-48 bg-white dark:bg-gray-600 p-3 rounded-lg shadow-sm mb-4">
                                <img src="https://public.readdy.ai/ai/img_res/498c131d513e1e367f65ca40399b37f3.jpg" alt="Crypto QR Code" class="w-full h-full object-cover">
                            </div>
                            <p class="text-sm text-gray-600 dark:text-gray-400 text-center">Scan this QR code with your wallet app to make payment</p>
                        </div>
                    </div>
                    <div class="bg-yellow-50 dark:bg-yellow-900/30 p-4 rounded-lg mt-4">
                        <div class="flex items-start">
                            <div class="w-6 h-6 flex items-center justify-center bg-yellow-100 dark:bg-yellow-800 rounded-full mr-3 text-yellow-600 dark:text-yellow-400 mt-0.5">
                                <i class="ri-alert-line text-sm"></i>
                            </div>
                            <div>
                                <p class="text-sm text-yellow-800 dark:text-yellow-200">Please note that cryptocurrency transactions are irreversible. Ensure you're sending the correct amount to the correct address.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Save Payment Method -->
            <div class="mb-8">
                <div class="flex items-center">
                    <label class="custom-switch mr-3">
                        <input type="checkbox" id="savePaymentMethod">
                        <span class="slider"></span>
                    </label>
                    <label for="savePaymentMethod" class="text-sm text-gray-700 dark:text-gray-300 cursor-pointer">Save this payment method for future transactions</label>
                </div>
            </div>

            <!-- Action Button -->
            <div class="flex justify-end">
                <button id="depositButton" class="px-6 py-3 bg-gradient-to-r from-primary to-secondary text-white font-medium rounded-button hover:opacity-90 transition-all whitespace-nowrap">
                    Deposit Now
                </button>
            </div>
        </div>

        <!-- Recent Deposits -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Recent Deposits</h2>
                <a href="#" class="text-primary font-medium text-sm hover:underline">View All</a>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead>
                        <tr class="border-b border-gray-200 dark:border-gray-700">
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Transaction ID</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Payment Method</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Amount</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">Apr 8, 2025</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">DEP-78952</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">
                                <div class="flex items-center">
                                    <div class="w-6 h-6 flex items-center justify-center mr-2 text-blue-600 dark:text-blue-400">
                                        <i class="ri-bank-card-fill"></i>
                                    </div>
                                    <span>Credit Card</span>
                                </div>
                            </td>
                            <td class="py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">$500.00</td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-full">Completed</span>
                            </td>
                        </tr>
                        <tr class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">Apr 2, 2025</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">DEP-78845</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">
                                <div class="flex items-center">
                                    <div class="w-6 h-6 flex items-center justify-center mr-2 text-green-600 dark:text-green-400">
                                        <i class="ri-bank-fill"></i>
                                    </div>
                                    <span>Bank Transfer</span>
                                </div>
                            </td>
                            <td class="py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">$1,200.00</td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-full">Completed</span>
                            </td>
                        </tr>
                        <tr class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">Mar 28, 2025</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">DEP-78701</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">
                                <div class="flex items-center">
                                    <div class="w-6 h-6 flex items-center justify-center mr-2 text-yellow-600 dark:text-yellow-400">
                                        <i class="ri-bitcoin-fill"></i>
                                    </div>
                                    <span>Bitcoin</span>
                                </div>
                            </td>
                            <td class="py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">$750.00</td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 text-xs font-medium bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 rounded-full">Pending</span>
                            </td>
                        </tr>
                        <tr class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">Mar 21, 2025</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">DEP-78632</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">
                                <div class="flex items-center">
                                    <div class="w-6 h-6 flex items-center justify-center mr-2 text-blue-600 dark:text-blue-400">
                                        <i class="ri-bank-card-fill"></i>
                                    </div>
                                    <span>Credit Card</span>
                                </div>
                            </td>
                            <td class="py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">$300.00</td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-full">Completed</span>
                            </td>
                        </tr>
                        <tr class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">Mar 15, 2025</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">DEP-78521</td>
                            <td class="py-3 px-4 text-sm text-gray-700 dark:text-gray-300">
                                <div class="flex items-center">
                                    <div class="w-6 h-6 flex items-center justify-center mr-2 text-blue-600 dark:text-blue-400">
                                        <i class="ri-bank-card-fill"></i>
                                    </div>
                                    <span>Credit Card</span>
                                </div>
                            </td>
                            <td class="py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">$150.00</td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200 rounded-full">Failed</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
   
  document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }
        // Dark mode toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        const html = document.documentElement;
        // Load dark mode setting from local storage
        const theme = localStorage.getItem('theme');
        if (theme === 'dark') {
          html.classList.add('dark');
          darkModeToggle.checked = true;
        } else {
          html.classList.remove('dark');
          darkModeToggle.checked = false;
        }
        darkModeToggle.addEventListener('change', () => {
          if (darkModeToggle.checked) {
            html.classList.add('dark');
            localStorage.setItem('theme', 'dark');
          } else {
            html.classList.remove('dark');
            localStorage.setItem('theme', 'light');
          }
        });
      });
    </script>
    <script>

        // Payment method selection UI logic & accessibility
        const paymentMethods = document.querySelectorAll('input[name="paymentMethod"]');
        const paymentDetailsSections = document.querySelectorAll('.payment-details-section');
        paymentMethods.forEach(method => {
            const label = document.querySelector(`label[for="${method.id}"]`);
            if (label) {
                label.setAttribute('tabindex', '0');
                label.setAttribute('role', 'button');
                label.setAttribute('aria-pressed', method.checked ? 'true' : 'false');
                label.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        method.checked = true;
                        method.dispatchEvent(new Event('change'));
                    }
                });
            }
            method.addEventListener('change', function() {
                paymentDetailsSections.forEach(section => section.classList.add('hidden'));
                document.getElementById(`${this.value}Details`).classList.remove('hidden');
                paymentMethods.forEach(m => {
                    const l = document.querySelector(`label[for="${m.id}"]`);
                    if (l) l.setAttribute('aria-pressed', m.checked ? 'true' : 'false');
                });
            });
        });

        // Amount calculation and validation
        const amountInput = document.getElementById('amount');
        const summaryAmount = document.getElementById('summaryAmount');
        const summaryFee = document.getElementById('summaryFee');
        const summaryTotal = document.getElementById('summaryTotal');
        amountInput.addEventListener('input', function() {
            let amount = Math.abs(parseFloat(this.value) || 0);
            if (this.value < 0) this.value = amount;
            const fee = amount * 0.025;
            const total = amount + fee;
            summaryAmount.textContent = amount.toFixed(2);
            summaryFee.textContent = fee.toFixed(2);
            summaryTotal.textContent = total.toFixed(2);
        });

        // Clipboard copy (modern API)
        const copyButton = document.querySelector('button[title="Copy address"]');
        if (copyButton) {
            copyButton.addEventListener('click', async function(e) {
                e.preventDefault();
                const walletAddress = document.getElementById('walletAddress');
                try {
                    await navigator.clipboard.writeText(walletAddress.value);
                    const originalIcon = this.innerHTML;
                    this.innerHTML = '<i class="ri-check-line"></i>';
                    this.classList.add('text-green-500');
                    setTimeout(() => {
                        this.innerHTML = originalIcon;
                        this.classList.remove('text-green-500');
                    }, 2000);
                } catch (err) {
                    showNotification('error', 'Failed to copy address.');
                }
            });
        }

        // Helper function to show notifications
        function showNotification(type, message) {
            const notification = document.createElement('div');
            notification.className = 'fixed top-4 right-4 px-4 py-3 rounded-md shadow-lg flex items-center z-50';
            notification.setAttribute('role', 'alert');
            notification.setAttribute('aria-live', 'assertive');
            notification.tabIndex = 0;
            if (type === 'success') {
                notification.classList.add('bg-green-50', 'text-green-800', 'dark:bg-green-900/30', 'dark:text-green-200');
                notification.innerHTML = `
                    <div class="w-8 h-8 flex items-center justify-center bg-green-100 dark:bg-green-800 rounded-full mr-3">
                        <i class="ri-check-line text-green-600 dark:text-green-400"></i>
                    </div>
                    <div>
                        <h4 class="font-medium">Success!</h4>
                        <p class="text-sm">${message}</p>
                    </div>
                    <button class="ml-4 text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-200" aria-label="Close notification">
                        <i class="ri-close-line"></i>
                    </button>
                `;
            } else {
                notification.classList.add('bg-red-50', 'text-red-800', 'dark:bg-red-900/30', 'dark:text-red-200');
                notification.innerHTML = `
                    <div class="w-8 h-8 flex items-center justify-center bg-red-100 dark:bg-red-800 rounded-full mr-3">
                        <i class="ri-error-warning-line text-red-600 dark:text-red-400"></i>
                    </div>
                    <div>
                        <h4 class="font-medium">Error</h4>
                        <p class="text-sm">${message}</p>
                    </div>
                    <button class="ml-4 text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-200" aria-label="Close notification">
                        <i class="ri-close-line"></i>
                    </button>
                `;
            }
            document.body.appendChild(notification);
            notification.focus();
            setTimeout(() => notification.remove(), 3000);
            const closeBtn = notification.querySelector('button');
            closeBtn.addEventListener('click', () => notification.remove());
        }

        // Error summary for screen readers
        function showErrorSummary(message) {
            let summary = document.getElementById('errorSummary');
            if (!summary) {
                summary = document.createElement('div');
                summary.id = 'errorSummary';
                summary.className = 'sr-only';
                summary.setAttribute('role', 'alert');
                document.body.prepend(summary);
            }
            summary.textContent = message;
        }

        // Form validation and submission
        const depositButton = document.getElementById('depositButton');
        depositButton.addEventListener('click', function(e) {
            e.preventDefault();
            let valid = true;
            const amount = Math.abs(parseFloat(amountInput.value) || 0);
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
            // Validate amount
            if (amount < 10) {
                showNotification('error', 'Please enter an amount of at least $10.00');
                showErrorSummary('Please enter an amount of at least $10.00');
                amountInput.focus();
                valid = false;
            } else if (amount > 10000) {
                showNotification('error', 'Maximum deposit amount is $10,000.00');
                showErrorSummary('Maximum deposit amount is $10,000.00');
                amountInput.focus();
                valid = false;
            }
            // Improved validation regex
            if (paymentMethod === 'card') {
                const cardNumber = document.getElementById('cardNumber');
                const cardName = document.getElementById('cardName');
                const expiryDate = document.getElementById('expiryDate');
                const cvv = document.getElementById('cvv');
                if (!/^\d{4} \d{4} \d{4} \d{4}$/.test(cardNumber.value)) {
                    showNotification('error', 'Enter a valid 16-digit card number (xxxx xxxx xxxx xxxx).');
                    cardNumber.focus();
                    valid = false;
                } else if (!cardName.value.trim()) {
                    showNotification('error', 'Cardholder name is required.');
                    cardName.focus();
                    valid = false;
                } else if (!/^(0[1-9]|1[0-2])\/(\d{2})$/.test(expiryDate.value)) {
                    showNotification('error', 'Expiry date must be in MM/YY format.');
                    expiryDate.focus();
                    valid = false;
                } else if (!/^\d{3}$/.test(cvv.value)) {
                    showNotification('error', 'CVV must be 3 digits.');
                    cvv.focus();
                    valid = false;
                }
            }
            if (!valid) return;
            // Show loading state
            const originalText = this.innerHTML;
            this.innerHTML = '<span class="flex items-center"><svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Processing...';
            this.disabled = true;
            // Prepare form data
            const formData = new URLSearchParams();
            formData.append('amount', amount);
            formData.append('paymentMethod', paymentMethod);
            if (paymentMethod === 'card') {
                formData.append('cardNumber', document.getElementById('cardNumber').value);
                formData.append('cardName', document.getElementById('cardName').value);
                formData.append('expiryDate', document.getElementById('expiryDate').value);
                formData.append('cvv', document.getElementById('cvv').value);
            } else if (paymentMethod === 'bank') {
                formData.append('transferReference', document.getElementById('transferReference').value);
            } else if (paymentMethod === 'crypto') {
                formData.append('cryptoType', document.getElementById('cryptoType').value);
                formData.append('walletAddress', document.getElementById('walletAddress').value);
            }
            // Save payment method
            formData.append('savePaymentMethod', document.getElementById('savePaymentMethod').checked ? '1' : '0');
            // AJAX request to backend
            fetch('deposit.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData.toString()
            })
            .then(res => res.json())
            .then(data => {
                this.innerHTML = originalText;
                this.disabled = false;
                if (data.success) {
                    showNotification('success', 'Your deposit has been successfully processed!');
                    showErrorSummary('');
                    amountInput.value = '';
                    summaryAmount.textContent = '0.00';
                    summaryFee.textContent = '0.00';
                    summaryTotal.textContent = '0.00';
                    // Optionally reload balance and transactions
                } else {
                    showNotification('error', data.error || 'Deposit failed.');
                    showErrorSummary(data.error || 'Deposit failed.');
                }
            })
            .catch(() => {
                this.innerHTML = originalText;
                this.disabled = false;
                showNotification('error', 'Network error. Please try again.');
                showErrorSummary('Network error. Please try again.');
            });
        });

        // Format card number with spaces
        const cardNumberInput = document.getElementById('cardNumber');
        if (cardNumberInput) {
            cardNumberInput.addEventListener('input', function(e) {
                let value = this.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                let formattedValue = '';
                for (let i = 0; i < value.length; i++) {
                    if (i > 0 && i % 4 === 0) formattedValue += ' ';
                    formattedValue += value[i];
                }
                this.value = formattedValue;
            });
        }
        // Format expiry date
        const expiryDateInput = document.getElementById('expiryDate');
        if (expiryDateInput) {
            expiryDateInput.addEventListener('input', function(e) {
                let value = this.value.replace(/\D/g, '');
                if (value.length > 2) value = value.substring(0, 2) + '/' + value.substring(2, 4);
                this.value = value;
            });
        }
    </script>
</body>
</html>