<!DOCTYPE html>
<html lang="en" class="light">
    <?php require_once __DIR__ . '/includes/user-data.php'; 
$csrfMeta = htmlspecialchars($csrfToken ?? ($_SESSION['csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8');

 ?>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Withdraw Funds</title>
<script src="https://cdn.tailwindcss.com/3.4.16"></script>
<!-- Mobile optimization -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
    <!-- Global JavaScript -->
    <script src="assests/js/global.js"></script>
    
    <!-- Tailwind Configuration -->
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'button': '8px'
                    }
                }
            }
        }
    </script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    /* Custom styles */
    :root {
        --primary: #FFD700;
        --secondary: #357ABD;
        --accent: #ff6b6b;
        --dark: #1a202c;
        --light: #f7fafc;
        --success: #48bb78;
        --warning: #ecc94b;
        --danger: #e53e3e;
        --gray: #718096;
        --gray-light: #e2e8f0;
        --card-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    body {
        font-family: 'Inter', sans-serif;
        transition: background-color 0.5s ease, color 0.5s ease;
        background-color: #f9fafb;
    }
    
    .dark body {
        background-color: #0f172a;
    }
    
    .icon-shadow { 
        text-shadow: 0 0 8px #FFD700; 
    }
    
    .sidebar {
        transition: transform 0.3s ease;
    }
    
    .sidebar-item:hover {
        background-color: rgba(255, 215, 0, 0.15);
    }
    
    .sidebar-item.active {
        background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
        border-left: 3px solid #FFD700;
    }
    
    .sidebar-item:hover:not(.active) {
        background-color: rgba(74, 144, 226, 0.1);
    }
    
    .stat-card {
        transition: all 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }
    
    .custom-switch {
        position: relative;
        display: inline-block;
        width: 44px;
        height: 24px;
    }
    
    .custom-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        inset: 0;
        background-color: #E5E7EB;
        transition: 0.4s;
        border-radius: 24px;
    }
    
    .slider:before {
        content: '';
        position: absolute;
        width: 18px;
        height: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: 0.4s;
        border-radius: 50%;
    }
    
    input:checked + .slider {
        background-color: #0284C7;
    }
    
    input:checked + .slider:before {
        transform: translateX(20px);
    }

    .dark select {
        background-color: #1f2937;
        color: #e5e7eb;
        border-color: #374151;
    }
    
    .dark select option {
        background-color: #1f2937;
        color: #e5e7eb;
    }
    
    .dark input[type="number"] {
        background-color: #1f2937;
        color: #e5e7eb;
        border-color: #374151;
    }
    
    .payment-method-option {
        transition: all 0.3s ease;
        cursor: pointer;
        border-radius: 12px;
    }
    
    .payment-method-option.selected {
        background-color: rgba(74, 144, 226, 0.2);
        border-color: #4A90E2;
    }
    
    .payment-method-option:hover:not(.selected) {
        background-color: #f3f4f6;
    }
    
    .dark .payment-method-option {
        background-color: #1f2937;
        border-color: #374151;
    }
    
    .dark .payment-method-option.selected {
        background-color: rgba(74, 144, 226, 0.2);
        border-color: #4A90E2;
    }
    
    .dark .payment-method-option:hover:not(.selected) {
        background-color: #374151;
    }
    .dark .bg-white {
            background-color: #1f2937 !important;
        }
        
        .dark .text-gray-800 {
            color: #f3f4f6 !important;
        }
        
        .dark .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        .dark .bg-gray-50 {
            background-color: #374151 !important;
        }
        
        .dark .border-gray-200 {
            border-color: #374151 !important;
        }
        
        .dark .table-row {
            background-color: #1f2937;
        }
    }
    .dark input,
    .dark textarea,
    .dark select {
        background-color: #1f2937;
        color: #e5e7eb;
    }

    .stat-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }
    
    .switch {
        position: relative;
        display: inline-block;
        width: 48px;
        height: 24px;
    }
    
    .switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .slider {
        background-color: #4A90E2;
    }
    
    input:checked + .slider:before {
        transform: translateX(24px);
    }
    
    input[type="checkbox"] {
        appearance: none;
        -webkit-appearance: none;
        width: 20px;
        height: 20px;
        border: 2px solid #d1d5db;
        border-radius: 4px;
        outline: none;
        cursor: pointer;
        position: relative;
    }
    
    input[type="checkbox"]:checked {
        background-color: #4A90E2;
        border-color: #4A90E2;
    }
    
    input[type="checkbox"]:checked::after {
        content: "";
        position: absolute;
        top: 2px;
        left: 6px;
        width: 6px;
        height: 10px;
        border: solid white;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
    }
    
    .progress-bar {
        height: 8px;
        background-color: #e5e7eb;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .dark .progress-bar {
        background-color: #374151;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #4A90E2 0%, #357ABD 100%);
        border-radius: 4px;
        transition: width 0.3s ease;
    }
    
    .chatbot-button {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 56px;
        height: 56px;
        border-radius: 28px;
        background: linear-gradient(135deg, #4A90E2 0%, #357ABD 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        box-shadow: 0 4px 12px rgba(74, 144, 226, 0.3);
        cursor: pointer;
        transition: transform 0.3s ease;
        z-index: 50;
    }
    
    .chatbot-button:hover {
        transform: scale(1.05);
    }
    
    input[type="number"]::-webkit-inner-spin-button,
    input[type="number"]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    
    input[type="number"] {
        -moz-appearance: textfield;
        appearance: textfield;
    }
    
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
            position: fixed;
            z-index: 40;
            transition: transform 0.3s ease;
        }
        
        .sidebar.open {
            transform: translateX(0);
        }
        
        .main-content {
            margin-left: 0;
        }
    }
    
    /* Dark mode specific styles */
    .dark .bg-card-dark {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    }
    
    .dark .bg-white,
    .dark .bg-gray-900 {
        background-color: #1f2937 !important;
    }
    
    .dark .text-gray-800 {
        background-color: #1f2937 !important;
    }
    
    .dark .text-gray-800 {
        color: #e5e7eb !important;
    }
    
    .dark .text-gray-700 {
        color: #d1d5db !important;
    }
    
    .dark .bg-gray-50 {
        background-color: #374151 !important;
    }
    
    .dark .border-gray-200 {
        border-color: #374151 !important;
    }
    
    .dark .table-row {
        background-color: #1f2937;
    }
    
    .dark input,
    .dark select,
    .dark textarea {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
        color: #fff !important;
    }
    
    .dark input::placeholder {
        color: #6b7280 !important;
    }
    
    /* Fixes for layout */
    .transaction-summary {
        background-color: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 20px;
    }
    
    .dark .transaction-summary {
        background-color: #1f2937;
        border-color: #374151;
    }
    
    .withdrawal-container {
        display: grid;
        grid-template-columns: 1fr;
        gap: 30px;
    }
    
    @media (min-width: 1024px) {
        .withdrawal-container {
            grid-template-columns: 1fr 2fr;
        }
    }
    
    /* Color fixes to match All Videos page */
    .bg-gray-900 {
        background-color: #1f2937;
    }
    
    .dark .bg-gray-900 {
        background-color: #0f172a;
    }
    
    .border-gray-800 {
        border-color: #374151;
    }
    
    .text-gray-800 {
        color: #1f2937;
    }
    
    .dark .text-gray-800 {
        color: #e5e7eb;
    }
    
    .text-gray-700 {
        color: #374151;
    }
    
    .dark .text-gray-700 {
        color: #d1d5db;
    }
    
    .text-gray-500 {
        color: #6b7280;
    }
    
    .dark .text-gray-500 {
        color: #9ca3af;
    }
    
    .text-gray-600 {
        color: #4b5563;
    }
    
    .dark .text-gray-600 {
        color: #9ca3af;
    }
    
    .bg-primary {
        background-color: #FFD700;
    }
    
    .text-primary {
        color: #FFD700;
    }
    
    .bg-secondary {
        background-color: #357ABD;
    }
    
    .text-secondary {
        color: #357ABD;
    }
    
    /* Success notification */
    .success-notification {
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: white;
        padding: 15px 25px;
        border-radius: 50px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 100;
        animation: slideDown 0.5s ease-out;
        display: none;
    }
    
    @keyframes slideDown {
        from { top: -100px; opacity: 0; }
        to { top: 20px; opacity: 1; }
    }
    
    /* Points indicator */
    .points-indicator {
        display: flex;
        align-items: center;
        gap: 8px;
        background: rgba(255, 215, 0, 0.1);
        border-radius: 8px;
        padding: 8px 16px;
        margin-bottom: 16px;
    }
    
    .points-indicator i {
        color: #FFD700;
        font-size: 20px;
    }
    
    .points-value {
        font-weight: 600;
        color: #FFD700;
    }
    
    /* Telebirr note */
    .telebirr-note {
        background: rgba(53, 122, 189, 0.1);
        border-left: 3px solid #357ABD;
        padding: 12px;
        border-radius: 0 8px 8px 0;
        margin-top: 10px;
        font-size: 14px;
    }
</style>
</head>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white transition-colors duration-300">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        
        <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
    

    <!-- Main Content -->
    
        <!-- Mobile Menu Toggle -->
        <button
            id="mobileMenuButton"
            class="fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700"
            aria-controls="sidebar"
            aria-expanded="false"
            aria-label="Open menu"
        >
            <i class="ri-menu-line text-xl text-primary"></i>
        </button>
        
        <main class="main-content flex-1 ml-0 md:ml-72 min-h-screen">
        <!-- Profile Header -->
        <div class="bg-gray-100 dark:bg-gray-900 p-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-6 h-6 flex items-center justify-center mr-2 md:hidden">
                        <i class="ri-menu-line ri-lg"></i>
                    </div>
                    <a href="Dashboard.html" class="flex items-center text-gray-500 hover:text-primary mr-4">
                        <div class="w-5 h-5 flex items-center justify-center mr-1">
                            <i class="ri-arrow-left-line"></i>
                        </div>
                        <span class="text-sm">Back to Dashboard</span>
                    </a>
                    <h1 class="text-xl font-semibold text-gray-800 dark:text-white">Withdraw Funds</h1>
                </div>
                <div class="flex items-center">
                    <?php include '../includes/user-info.php'; ?>
                    <div class="relative">
                        <button type="button" id="profileButton" class="flex items-center">
                           <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white">
                            <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile" class="w-full h-full object-cover">
                            </div>
                        </button>
                        <div id="profileDropdown" class="hidden absolute right-0 mt-2 w-56 bg-gray-800 rounded-md shadow-lg z-50">
                            <div class="p-3 border-b border-gray-700">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white">
                            <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile" class="w-full h-full object-cover">
                            </div>
                                    <div>
                                        <h4 class="font-medium text-white"><?= $username ?></h4>
                                        <p class="text-xs text-gray-400"><?= $_SESSION['email'] ?? 'user@example.com' ?></p>
                                    </div>
                                </div>
                            </div>
                            <a href="/users/profile-update.php" class="px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 block">
                                <i class="ri-user-line mr-2"></i> My Profile
                            </a>
                            <a href="/users/settings.php" class="px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 block">
                                <i class="ri-settings-3-line mr-2"></i> Settings
                            </a>
                            <a href="/users/wallet.php" class="px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 block">
                                <i class="ri-wallet-3-line mr-2"></i> Wallet
                            </a>
                            <div class="border-t border-gray-700"></div>
                            <a href="/logout.php" class="px-4 py-2 text-sm text-red-500 hover:bg-gray-700 block">
                                <i class="ri-logout-box-r-line mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Withdrawal Page Content -->
        <div class="px-6 py-8">
            <div class="withdrawal-container">
                <!-- Balance Summary Card -->
                <div>
                    <div class="bg-white dark:bg-gray-800 rounded-md shadow-sm p-6 border border-gray-200 dark:border-gray-700">
                        <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-6">Balance Summary</h2>
                        
                        <!-- Points Indicator -->
                        <div class="points-indicator">
                            <i class="ri-coin-line"></i>
                            <span>Available Points:</span>
                            <span class="points-value" id="pointsValue">9,500</span>
                        </div>
                        
                        <!-- Withdrawal Information -->
                        <div class="mb-6">
                            <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">Withdrawal Threshold</p>
                            <div class="flex items-end">
                                <h3 class="text-3xl font-bold text-gray-800 dark:text-white">10,000 Points</h3>
                            </div>
                        </div>
                        
                        <!-- Points Progress -->
                        <div>
                            <div class="flex justify-between mb-1">
                                <p class="text-sm text-gray-500 dark:text-gray-400">Points Progress</p>
                                <p class="text-sm font-medium dark:text-gray-300"><span id="currentPoints">9,500</span> / 10,000</p>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" id="pointsProgress" style="width: 95%"></div>
                            </div>
                        </div>
                        
                        <!-- Verification Level -->
                        <div class="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                            <div class="flex items-center justify-between mb-3">
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">Verification Level</p>
                                <span class="text-xs bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-1 rounded-full">Level 2</span>
                            </div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Verify your identity to withdraw funds. <a href="#" class="text-primary hover:underline">Upgrade now</a></p>
                        </div>
                    </div>
                </div>
                
                <!-- Withdrawal Form -->
                <div>
                    <div class="bg-white dark:bg-gray-800 rounded-md shadow-sm p-6 border border-gray-200 dark:border-gray-700">
                        <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-6">Withdraw Funds</h2>
                        <form id="withdrawalForm">
                            <!-- Amount Input -->
                            <div class="mb-6">
                                <label for="amount" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Withdrawal Amount</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <span class="text-gray-500">ETB</span>
                                    </div>
                                    <input type="number" id="amount" name="amount" class="pl-12 py-3 w-full border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-gray-800 dark:text-white dark:bg-gray-700" placeholder="0.00" min="1000" max="1000" value="1000" readonly>
                                </div>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">10,000 points = 1,000 ETB</p>
                            </div>
                            
                            <!-- Payment Method Selection -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Payment Method</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <div class="payment-method-option border border-gray-300 dark:border-gray-700 rounded-md p-4 flex flex-col items-center" data-method="bank">
                                        <div class="w-10 h-10 flex items-center justify-center bg-blue-100 dark:bg-blue-900 rounded-full text-primary dark:text-blue-300 mb-2">
                                            <i class="ri-bank-line ri-lg"></i>
                                        </div>
                                        <span class="text-sm font-medium dark:text-gray-300">Bank Account</span>
                                    </div>
                                    <div class="payment-method-option border border-gray-300 dark:border-gray-700 rounded-md p-4 flex flex-col items-center" data-method="telebirr">
                                        <div class="w-10 h-10 flex items-center justify-center bg-green-100 dark:bg-green-900 rounded-full text-green-600 dark:text-green-300 mb-2">
                                            <i class="ri-phone-line ri-lg"></i>
                                        </div>
                                        <span class="text-sm font-medium dark:text-gray-300">Telebirr</span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Payment Method Details -->
                            <div id="paymentDetails">
                                <!-- Bank Transfer Details (Default) -->
                                <div id="bankDetails" class="payment-details">
                                    <div class="mb-4">
                                        <label for="bankName" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Bank Name</label>
                                        <select id="bankName" name="bankName" class="py-3 px-4 w-full border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-gray-800 dark:text-white dark:bg-gray-700">
                                            <option value="">Select Bank</option>
                                            <option value="cbe">Commercial Bank of Ethiopia</option>
                                            <option value="awash">Awash International Bank</option>
                                            <option value="dashen">Dashen Bank</option>
                                            <option value="nib">Nib International Bank</option>
                                            <option value="abyssinia">Bank of Abyssinia</option>
                                            <option value="abay">Abay Bank</option>
                                        </select>
                                    </div>
                                    <div class="mb-4">
                                        <label for="accountNumber" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Account Number</label>
                                        <input type="text" id="accountNumber" name="accountNumber" class="py-3 px-4 w-full border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-gray-800 dark:text-white dark:bg-gray-700" placeholder="Enter account number">
                                    </div>
                                    <div class="mb-4">
                                        <label for="accountHolderName" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Account Holder Name</label>
                                        <input type="text" id="accountHolderName" name="accountHolderName" class="py-3 px-4 w-full border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-gray-800 dark:text-white dark:bg-gray-700" placeholder="Enter account holder name">
                                    </div>
                                </div>
                                
                                <!-- Telebirr Details (Hidden by default) -->
                                <div id="telebirrDetails" class="payment-details hidden">
                                    <div class="mb-4">
                                        <label for="phoneNumber" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Phone Number</label>
                                        <input type="tel" id="phoneNumber" name="phoneNumber" class="py-3 px-4 w-full border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-gray-800 dark:text-white dark:bg-gray-700" placeholder="Enter phone number">
                                    </div>
                                    <div class="telebirr-note">
                                        <i class="ri-information-line mr-2"></i>
                                        Your Telebirr account is linked to your phone number: Your Telebirr account is directly tied to the mobile number you use for the service.
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Terms and Conditions -->
                            <div class="flex items-start mb-6">
                                <input type="checkbox" id="termsAgreement" name="termsAgreement" class="mt-1 mr-2">
                                <label for="termsAgreement" class="text-sm text-gray-700 dark:text-gray-300">
                                    I confirm that the information provided is correct and I agree to the <a href="#" class="text-primary hover:underline">Terms of Service</a> and <a href="#" class="text-primary hover:underline">Withdrawal Policy</a>.
                                </label>
                            </div>
                            
                            <!-- Action Buttons -->
                            <div class="flex flex-col sm:flex-row sm:justify-end gap-3">
                                <a href="#" class="px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-button text-gray-700 dark:text-gray-300 font-medium hover:bg-gray-50 dark:hover:bg-gray-700 text-center whitespace-nowrap">Cancel</a>
                                <button type="submit" id="confirmWithdrawal" class="px-6 py-3 bg-primary text-white font-medium rounded-button hover:bg-secondary whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed" disabled>Withdraw Funds</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <footer class="px-6 py-8 bg-gray-100 dark:bg-gray-900 mt-6 border-t border-gray-200 dark:border-gray-800">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-4 md:mb-0">
                    <p class="text-sm text-gray-600 dark:text-gray-400">© MIKIYAS OLANA Rewards Platform. All rights reserved.</p>
                </div>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary">
                        <div class="w-5 h-5 flex items-center justify-center">
                            <i class="ri-twitter-x-line"></i>
                        </div>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary">
                        <div class="w-5 h-5 flex items-center justify-center">
                            <i class="ri-facebook-circle-line"></i>
                        </div>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary">
                        <div class="w-5 h-5 flex items-center justify-center">
                            <i class="ri-instagram-line"></i>
                        </div>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary">
                        <div class="w-5 h-5 flex items-center justify-center">
                            <i class="ri-linkedin-box-line"></i>
                        </div>
                    </a>
                </div>
            </div>
        </footer>
    </main>
    
    <!-- Chatbot Button -->
    <div class="chatbot-button">
        <div class="w-6 h-6 flex items-center justify-center">
            <i class="ri-message-3-line ri-lg"></i>
        </div>
    </div>
    
    <!-- Success Notification -->
    <div class="success-notification" id="successNotification">
        <i class="fas fa-check-circle"></i>
        Withdrawal request submitted successfully!
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Simulate user points (in a real app, this would come from the server)
            const userPoints = 9500;
            const pointsThreshold = 10000;
            const withdrawalAmount = 1000; // ETB
            
            // Update points display
            document.getElementById('pointsValue').textContent = userPoints.toLocaleString();
            document.getElementById('currentPoints').textContent = userPoints.toLocaleString();
            
            // Calculate progress percentage
            const progressPercentage = Math.min(100, (userPoints / pointsThreshold) * 100);
            document.getElementById('pointsProgress').style.width = `${progressPercentage}%`;
            
            // Enable/disable withdrawal button based on points
            const confirmBtn = document.getElementById('confirmWithdrawal');
            if (userPoints >= pointsThreshold) {
                confirmBtn.disabled = false;
            } else {
                confirmBtn.disabled = true;
            }
            
            // Payment method toggle
            const paymentOptions = document.querySelectorAll('.payment-method-option');
            const bankDetails = document.getElementById('bankDetails');
            const telebirrDetails = document.getElementById('telebirrDetails');
            
            paymentOptions.forEach(option => {
                option.addEventListener('click', function() {
                    // Remove selected class from all options
                    paymentOptions.forEach(opt => opt.classList.remove('selected'));
                    // Add selected class to clicked option
                    this.classList.add('selected');
                    
                    // Show selected payment details
                    const method = this.getAttribute('data-method');
                    if (method === 'bank') {
                        bankDetails.classList.remove('hidden');
                        telebirrDetails.classList.add('hidden');
                    } else if (method === 'telebirr') {
                        bankDetails.classList.add('hidden');
                        telebirrDetails.classList.remove('hidden');
                    }
                });
            });
            
            // Select the first payment method by default
            paymentOptions[0].click();
            
            // Form submission
            const withdrawalForm = document.getElementById('withdrawalForm');
            const termsCheckbox = document.getElementById('termsAgreement');
            const successNotification = document.getElementById('successNotification');
            
            withdrawalForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validation
                if (!termsCheckbox.checked) {
                    alert('Please agree to the Terms of Service and Withdrawal Policy.');
                    return;
                }
                
                // Get selected payment method
                const selectedMethod = document.querySelector('.payment-method-option.selected');
                if (!selectedMethod) {
                    alert('Please select a payment method.');
                    return;
                }
                
                const method = selectedMethod.getAttribute('data-method');
                let isValid = true;
                
                if (method === 'bank') {
                    if (!document.getElementById('bankName').value) {
                        alert('Please select a bank.');
                        isValid = false;
                    }
                    if (!document.getElementById('accountNumber').value) {
                        alert('Please enter your account number.');
                        isValid = false;
                    }
                    if (!document.getElementById('accountHolderName').value) {
                        alert('Please enter the account holder name.');
                        isValid = false;
                    }
                } else if (method === 'telebirr') {
                    if (!document.getElementById('phoneNumber').value) {
                        alert('Please enter your phone number.');
                        isValid = false;
                    }
                }
                
                if (!isValid) return;
                
                // Show success notification
                successNotification.style.display = "flex";
                setTimeout(() => {
                    successNotification.style.display = "none";
                }, 3000);
                
                // Reset form
                withdrawalForm.reset();
                
                // Reset payment method to default
                paymentOptions[0].click();
                
                // In a real app, you would submit the data to the server here
                // This is where you would deduct the points and create the withdrawal request
                console.log('Withdrawal submitted:', {
                    amount: withdrawalAmount,
                    method: method,
                    bank: method === 'bank' ? document.getElementById('bankName').value : null,
                    account: method === 'bank' ? document.getElementById('accountNumber').value : null,
                    phone: method === 'telebirr' ? document.getElementById('phoneNumber').value : null,
                    name: method === 'bank' ? document.getElementById('accountHolderName').value : null
                });
            });
            
            // Profile dropdown toggle
            const profileButton = document.getElementById('profileButton');
            const profileDropdown = document.getElementById('profileDropdown');
            
            profileButton.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            
            document.addEventListener('click', (e) => {
                if (!profileButton.contains(e.target) && !profileDropdown.contains(e.target)) {
                    profileDropdown.classList.add('hidden');
                }
            });
            
            // Dark mode toggle
            const darkModeToggle = document.getElementById('darkModeToggle');
            const html = document.documentElement;
            
            // Check for saved theme preference
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                html.classList.add('dark');
                if (darkModeToggle) darkModeToggle.checked = true;
            }
            
            // Add event listener
            if (darkModeToggle) {
                darkModeToggle.addEventListener('change', function() {
                    if (this.checked) {
                        html.classList.add('dark');
                        localStorage.setItem('theme', 'dark');
                    } else {
                        html.classList.remove('dark');
                        localStorage.setItem('theme', 'light');
                    }
                });
            }
            
        });
        // Inside form submission
fetch('process_withdrawal.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        amount: withdrawalAmount,
        method: method,
        bankName: document.getElementById('bankName').value,
        accountNumber: document.getElementById('accountNumber').value,
        phoneNumber: document.getElementById('phoneNumber').value,
        accountHolderName: document.getElementById('accountHolderName').value
    })
})
.then(response => response.json())
.then(result => {
    if (result.success) {
        // Show success notification
    } else {
        alert(result.error || 'Withdrawal failed');
    }
});

    </script>
        <script>
        // Responsive sidebar toggle for mobile
    document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth <script 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }
            
            window.addEventListener('resize', handleResize);
            handleResize();
        });
        </script>
</body>
</html>