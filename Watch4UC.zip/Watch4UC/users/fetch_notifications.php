<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
require __DIR__ . '/../db/db_connect.php'; // Adjust path as needed

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

$user_id = $_SESSION['user_id'];

// Get unread notifications
$stmt = $conn->prepare("SELECT * FROM notifications 
                      WHERE user_id = ? AND status = 'unread'
                      ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$notifications = $result->fetch_all(MYSQLI_ASSOC);

// Mark as read
$ids = array_column($notifications, 'id');
if (!empty($ids)) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    
    $stmt = $conn->prepare("UPDATE notifications SET status = 'read' 
                          WHERE id IN ($placeholders)");
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
}

header('Content-Type: application/json');
echo json_encode($notifications);