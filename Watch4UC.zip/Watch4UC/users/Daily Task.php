<!DOCTYPE html>
<html lang="en">
<?php
require_once __DIR__ . '/includes/user-data.php';

// Set additional variables if needed
$userPoints = $userBalance; // Use the balance from user-data.php

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Tasks - UC FORGE</title>
    
    <!-- External CSS -->
    
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css">
    <!-- Mobile optimization -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
    <!-- Global JavaScript -->
    <script src="assets/js/user-data.js"></script>
    <script src="assests/js/global.js"></script>
    
    <!-- Tailwind Configuration -->
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'button': '8px'
                    }
                }
            }
        }
    </script>
    
    <!-- Essential Inline Styles -->
    <style>
        body {
            font-family: 'Inter', sans-serif;
            transition: background-color 0.5s ease, color 0.5s ease;
        }
        
        .sidebar {
            transition: transform 0.3s ease;
        }
        
        .sidebar-item:hover {
            background-color: rgba(255, 215, 0, 0.15);
        }
        
        .sidebar-item.active {
            background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
            border-left: 3px solid #FFD700;
        }
        
        .stat-card, .task-card {
            transition: all 0.3s ease;
        }
        
        .stat-card:hover, .task-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
        }
        
        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        h1.text-2xl.font-bold{
    color: #FFD700;
}
p.text-sm.opacity-80{
    color:#FFD700;
}
div.streak-day.streak-day.inactive{
    color: #FFD700; /* Gold color */
  text-shadow: 0 0 10px #FFD700, /* Inner glow */
               0 0 20px #FFD700, /* Medium glow */
               0 0 30px #FFDF01; /* Brighter, wider glow */
}
    h3.text-gray-500.dark:text-gray-400.font-medium {
            color: (135deg, #FFD700 0%, #357ABD 100%);
    }  

        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #E5E7EB;
            transition: 0.4s;
            border-radius: 24px;
        }
        
        .slider:before {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: 0.4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background-color: #0284C7;
        }
        
        input:checked + .slider:before {
            transform: translateX(20px);
        }
        
        .chatbot-button {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 56px;
            height: 56px;
            border-radius: 28px;
            background: linear-gradient(135deg, #FFD700 0%, #357ABD 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease;
            z-index: 50;
        }
        
        .chatbot-button:hover {
            transform: scale(1.05);
        }
        
        .streak-day {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: #FFD700;
            color: #111827;
            font-weight: bold;
        }
        
        .streak-day.inactive {
            background-color: #374151;
            color: #9ca3af;
        }
        
        .completed-task {
            background-color: rgba(74, 222, 128, 0.1);
            border-color: rgba(74, 222, 128, 0.5);
        }
        
        /* Dark mode specific styles */
        .dark .bg-white {
            background-color: #1f2937 !important;
        }
        
        .dark .text-gray-800 {
            color: #f3f4f6 !important;
        }
        
        .dark .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        .dark .bg-gray-50 {
            background-color: #374151 !important;
        }
        
        .dark .border-gray-200 {
            border-color: #374151 !important;
        }
        i.ri-inbox-line.task-empty-icon::before {
           color: #FFD700; /* Gold color */
  text-shadow: 0 0 10px #FFD700, /* Inner glow */
               0 0 20px #FFD700, /* Medium glow */
               0 0 30px #FFDF01; /* Brighter, wider glow */
        }


        /* Mobile sidebar styles */
        @media (max-width: 1023px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
                z-index: 50;
                transition: transform 0.3s ease;
                width: 280px;
                height: 100vh;
            }
            
            .sidebar.open {
                transform: translateX(0) !important;
            }
        }
        
        @media (min-width: 1024px) {
            .sidebar {
                transform: translateX(0) !important;
                position: relative;
            }
        }
        
        .hidden {
            display: none !important;
        }
    </style>
</head>
<body class="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
  <div class="flex h-screen">
    <!-- Sidebar -->
    <aside id="sidebar" class="sidebar w-72 bg-white dark:bg-gray-900 lg:sticky top-0 h-screen shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800" role="navigation" aria-label="Main navigation">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="UC FORGE Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        
       <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
    

   <!-- Mobile menu button -->
    <button type="button" id="mobileMenuButton" class="md:hidden fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
  <i class="ri-menu-line text-xl text-primary"></i>
</button>

    <!-- Main Content -->
    <main id="main-content" class="flex-1 overflow-y-auto p-4 md:p-8">

        <!-- Page Header -->
         
        <div class="flex items-center mb-8">
            <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white" id="headerProfilePic">
            <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile" class="w-full h-full object-cover">
            </div>
            <div>
             <h1 class="text-2xl font-bold" id="welcomeMessage">Welcome, <?= $username ?> 👋</h1>
            <p class="text-sm opacity-80">Member since <span id="memberSince"><?= $memberSince ?></span></p>
            <p class="text-sm opacity-80">
                <span style="color: #FFD700;">Points:</span> <span id="pointsBalance" class="font-semibold text-primary">0</span>
            </p>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <!-- Tasks Completed -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="text-secondary dark:text-primary font-medium">Tasks Completed</h3>
                    <div aria-hidden="true" class="w-10 h-10 flex items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                        <i class="ri-checkbox-circle-line"></i>
                    </div>
                </div>
                <div class="flex items-end">
                    <span class="text-2xl font-bold text-gray-800 dark:text-gray-100" id="tasksCompleted">5/10</span>
                </div>
                <div class="mt-2 text-sm text-green-500 flex items-center">
                    <i class="ri-arrow-up-line mr-1"></i>
                    <span>+50% completed</span>
                </div>
            </div>
            
            <!-- Coins Earned -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="text-secondary dark:text-primary font-medium">Coins Earned Today</h3>
                    <div aria-hidden="true" class="w-10 h-10 flex items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                        <i class="ri-coin-line"></i>
                    </div>
                </div>
                <div class="flex items-end">
                    <span class="text-2xl font-bold text-gray-800 dark:text-gray-100" id="coinsEarned">25</span>
                    <span class="ml-1 text-lg font-medium text-gray-600">Coins</span>
                </div>
                <div class="mt-2 text-sm text-gray-500 flex items-center">
                    <span>Potential remaining: <span id="potentialCoins">35</span> coins</span>
                </div>
            </div>
            
            <!-- Streak Counter -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="text-secondary dark:text-primary font-medium">Current Streak</h3>
                    <div aria-hidden="true" class="w-10 h-10 flex items-center justify-center rounded-full bg-red-100 text-red-600 dark:bg-red-900 dark:text-red-400">
                        <i class="ri-fire-line"></i>
                    </div>
                </div>
                <div class="flex items-end">
                    <span class="text-2xl font-bold text-gray-800 dark:text-gray-100" id="streakDays">7</span>
                    <span class="ml-1 text-lg font-medium text-gray-600">Days</span>
                </div>
                <div class="mt-2 flex justify-between">
                    <div class="streak-day inactive">M</div>
                    <div class="streak-day inactive">T</div>
                    <div class="streak-day inactive">W</div>
                    <div class="streak-day inactive">T</div>
                    <div class="streak-day">F</div>
                    <div class="streak-day">S</div>
                    <div class="streak-day">S</div>
                </div>
            </div>
        </div>
        
        <!-- Bonus Chest (Visible when all tasks completed) -->
        <div id="bonusChest" class="hidden bg-gradient-to-r from-primary to-secondary rounded-lg shadow-md p-6 mb-8 text-center text-white">
            <h2 class="text-xl font-bold mb-2">🎉 All Tasks Completed!</h2>
            <p class="mb-4 opacity-90">Congratulations! You've completed all daily tasks. Claim your bonus reward!</p>
            <button class="px-6 py-2 bg-white text-primary font-bold rounded-button hover:bg-opacity-90 transition" onclick="claimBonus()">
                Claim Bonus
            </button>
        </div>
        
        <!-- Watching Tasks Section -->
        <div class="mb-8">
            <div class="flex items-center mb-4">
                <h2 class="text-lg md:text-xl font-bold text-blue-800 dark:text-white mr-3">Watching Tasks</h2>
                <span class="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 text-xs font-medium rounded-full">
                    Earn up to 20 coins
                </span>
            </div>
            <div id="watchingTasks" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <!-- Tasks will be populated by JavaScript -->
            </div>
        </div>

        <!-- Social Media Tasks Section -->
        <div class="mb-8">
            <div class="flex items-center mb-4">
                <h2 class="text-lg md:text-xl font-bold text-purple-800 dark:text-purple-400 mr-3">Social Media Tasks</h2>
                <span class="px-2 py-1 bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400 text-xs font-medium rounded-full">
                    Earn up to 15 coins
                </span>
            </div>
            <div id="socialTasks" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <!-- Tasks will be populated by JavaScript -->
            </div>
        </div>

        <!-- Referral Tasks Section -->
        <div class="mb-8">
            <div class="flex items-center mb-4">
                <h2 class="text-lg md:text-xl font-bold text-gray-800 dark:text-white mr-3" style="color: #8eda14;">Referral Tasks</h2>
                <span class="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400 text-xs font-medium rounded-full">
                    Earn up to 50 coins
                </span>
            </div>
            <div id="referralTasks" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <!-- Tasks will be populated by JavaScript -->
            </div>
        </div>
        
        <!-- Reset Timer -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 border border-gray-200 dark:border-gray-700 text-center">
            <p class="text-sm text-gray-600 dark:text-gray-400">
                <i class="ri-time-line mr-1"></i> Tasks reset in <span class="font-medium text-primary" id="resetTimer">4 hours 22 minutes</span>
            </p>
        </div>
    </main>
    
    <!-- Footer -->
    
    <!-- Chatbot Button -->
    <div class="chatbot-button">
        <i class="ri-customer-service-2-line text-white text-xl"></i>
    </div>
    
    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }
            
            
            // Dark mode toggle
            const darkModeToggle = document.getElementById('darkModeToggle');
            const body = document.body;
            
            if (darkModeToggle && !darkModeToggle.hasAttribute('data-initialized')) {
                const isDarkMode = localStorage.getItem('darkMode') === 'true';
                darkModeToggle.checked = isDarkMode;
                body.classList.toggle('dark', isDarkMode);
                darkModeToggle.setAttribute('data-initialized', 'true');
                
                darkModeToggle.addEventListener('change', function() {
                    const isDark = this.checked;
                    body.classList.toggle('dark', isDark);
                    localStorage.setItem('darkMode', isDark);
                    
                    if(isDark) {
                        body.style.backgroundColor = '#111827';
                    } else {
                        body.style.backgroundColor = '#ffffff';
                    }
                });
            }
            
            // Load tasks
            loadTasks();
        });
        
        // Load tasks
        async function loadTasks() {
            try {
                const res = await fetch('../api/user/daily_tasks.php');
                const data = await res.json();
                if (!data.success) {
                    console.error('Failed to load tasks:', data.error);
                    showEmptyState();
                    return;
                }
                
                // Update user points
                updateUserPoints();
                
                // Group tasks by type
                const groupedTasks = {
                    video: data.tasks.filter(task => task.type === 'video'),
                    social: data.tasks.filter(task => task.type === 'social'),
                    referral: data.tasks.filter(task => task.type === 'referral')
                };
                
                // Render tasks
                renderTasks(groupedTasks);
                
            } catch (error) {
                console.error('Error loading tasks:', error);
                showEmptyState();
            }
        }
        
        // Show empty state for all task sections
        function showEmptyState() {
            ['watchingTasks', 'socialTasks', 'referralTasks'].forEach(id => {
                const container = document.getElementById(id);
                if (container) {
                    container.innerHTML = `
                        <div class="col-span-full text-center py-10 text-gray-500 dark:text-gray-400">
                            <i class="ri-inbox-line text-3xl mb-2"></i>
                            <p>No tasks available right now.</p>
                        </div>`;
                }
            });
        }
        
        // Render tasks
        function renderTasks(data) {
            const tasks = data.tasks || data;
            
            // Render video tasks
            if (tasks.video) {
                const container = document.getElementById('watchingTasks');
                container.innerHTML = '';
                tasks.video.forEach(task => {
                    const taskElement = createTaskCard(task, 'video');
                    container.appendChild(taskElement);
                });
            }
            
            // Render social tasks
            if (tasks.social) {
                const container = document.getElementById('socialTasks');
                container.innerHTML = '';
                tasks.social.forEach(task => {
                    const taskElement = createTaskCard(task, 'social');
                    container.appendChild(taskElement);
                });
            }
            
            // Render referral tasks
            if (tasks.referral) {
                const container = document.getElementById('referralTasks');
                container.innerHTML = '';
                tasks.referral.forEach(task => {
                    const taskElement = createTaskCard(task, 'referral');
                    container.appendChild(taskElement);
                });
            }
        }
        
        // Create task card
        function createTaskCard(task, type) {
            const div = document.createElement('div');
            div.className = `task-card bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-5 ${task.completed ? 'completed-task' : ''}`;
            
            const iconMap = {
                video: 'ri-video-line',
                social: 'ri-share-line',
                referral: 'ri-user-add-line'
            };
            
            const colorMap = {
                video: 'blue',
                social: 'purple',
                referral: 'green'
            };
            
            const icon = iconMap[type];
            const color = colorMap[type];
            
            let actionButton = '';
            if (task.completed) {
                actionButton = '<span class="text-sm font-medium text-green-600">✓ Completed</span>';
            } else if (type === 'referral' && task.type === 'share') {
                actionButton = `<button class="px-4 py-2 bg-primary text-white text-sm rounded-button" onclick="copyReferralLink()">Copy Link</button>`;
            } else {
                actionButton = `<button class="px-4 py-2 bg-primary text-white text-sm rounded-button" onclick="completeTask('${type}', ${task.reward}, ${task.id})">Complete</button>`;
            }
            
            div.innerHTML = `
                <div class="flex items-start mb-3">
                    <div class="w-10 h-10 bg-${color}-100 text-${color}-600 dark:bg-${color}-900 dark:text-${color}-400 rounded-full flex items-center justify-center mr-3">
                        <i class="${icon}"></i>
                    </div>
                    <div>
                        <h3 class="font-medium text-gray-800 dark:text-white">${escapeHtml(task.title || task.name)}</h3>
                        <p class="text-sm text-gray-600 dark:text-gray-400">${escapeHtml(task.type || task.platform || task.description)}</p>
                    </div>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-sm font-medium text-primary">+${task.reward} coins</span>
                    ${actionButton}
                </div>
            `;
            
            return div;
        }
        
        // Update user points from server
        async function updateUserPoints() {
            try {
                const res = await fetch('../api/user/balance.php');
                const data = await res.json();
                if (data.success) {
                    document.getElementById('pointsBalance').textContent = data.balance || '<?= $userPoints ?>';
                }
            } catch (error) {
                console.error('Error updating points:', error);
                document.getElementById('pointsBalance').textContent = '<?= $userPoints ?>';
            }
        }
        
        // Complete task function
        async function completeTask(type, coins, taskId) {
            try {
                const formData = new FormData();
                formData.append('task_id', taskId);
                formData.append('csrf', '<?= $csrfToken ?>');
                
                const res = await fetch('../api/user/complete_task.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await res.json();
                if (result.success) {
                    alert(`Task completed! +${result.points_earned} coins added to your account.`);
                    // Update the points display
                    document.getElementById('pointsBalance').textContent = result.new_points;
                    // Reload tasks to refresh completion status
                    loadTasks();
                } else {
                    alert(result.message || 'Failed to complete task. Please try again.');
                }
            } catch (error) {
                console.error('Error completing task:', error);
                alert('An error occurred. Please try again.');
            }
        }
        
        // Copy referral link
        function copyReferralLink() {
            const link = `${location.origin}/user/login.html?ref=default`;
            navigator.clipboard.writeText(link).then(() => {
                alert('Referral link copied!');
            }).catch(() => {
                alert('Failed to copy link.');
            });
        }
        
        // Claim bonus
        function claimBonus() {
            alert('+10 bonus coins added to your account!');
            document.getElementById('bonusChest').classList.add('hidden');
        }
        
        // Escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text || '';
            return div.innerHTML;
        }
    </script>
    
    <!-- Load external modules if available -->
    <script src="assets/css/daily-tasks.css" onerror="console.log('External CSS not loaded')"></script>
    <script src="assets/js/daily-tasks.js" onerror="console.log('External JS not loaded')"></script>
    <script src="assets/js/task-manager.js" onerror="console.log('Task manager not loaded')"></script>
    <script src="assets/js/ui-components.js" onerror="console.log('UI components not loaded')"></script>

  </div>
</body>
</html>
