// Shared User Data Manager
window.UserDataManager = {
    userData: null,
    // Whether this page requires auth (set data-auth-required="true" on body to enforce)
    requireAuth: document.body?.getAttribute('data-auth-required') === 'true',

    // Load user data from API
    async loadUserData() {
        try {
            const response = await fetch('/Watch4UC/api/auth/me.php', { credentials: 'include' });
            if (!response.ok) {
                console.error('Failed to fetch user data');
                return null;
            }
            const data = await response.json();
            if (data.loggedIn && data.username) {
                const memberSince = data.member_since || (data.joined_at ? new Date(data.joined_at).toISOString().slice(0,10) : '');
                const profilePic = data.avatar || this.generateProfilePic(data.username);
                this.userData = {
                    id: data.id,
                    username: data.username,
                    email: data.email,
                    role: data.role,
                    balance: data.balance || data.points || 0,
                    points: data.points || data.balance || 0,
                    memberSince: memberSince,
                    joined_at: data.joined_at,
                    loggedIn: true,
                    profilePic: profilePic
                };
                localStorage.setItem('userData', JSON.stringify(this.userData));
                return this.userData;
            } else {
                return null;
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            return null;
        }
    },

    // Generate profile picture with initials
    generateProfilePic(username) {
        const initials = (username || 'GU').substring(0, 2).toUpperCase();
        return `data:image/svg+xml;base64,${btoa(`
            \u003csvg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"\u003e
            \u003ccircle cx="20" cy="20" r="20" fill="#FFD700"/\u003e
            \u003ctext x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#111827" font-size="14" font-weight="bold" font-family="sans-serif"\u003e${initials}\u003c/text\u003e
            \u003c/svg\u003e
        `)}`;
    },

    // Get user data (try cache first, then API)
    async getUserData() {
        const cached = localStorage.getItem('userData');
        if (cached) {
            try {
                this.userData = JSON.parse(cached);
                return this.userData;
            } catch (e) {
                localStorage.removeItem('userData');
            }
        }
        return await this.loadUserData();
    },

    // Update user data in cache
    updateUserData(updates) {
        if (this.userData) {
            Object.assign(this.userData, updates);
            localStorage.setItem('userData', JSON.stringify(this.userData));
        }
    },

    // Update UI elements with user data
    updateUI(userData) {
        if (!userData) return;
        const welcomeMsg = document.getElementById('welcomeMessage');
        if (welcomeMsg) {
            welcomeMsg.textContent = `Welcome, ${userData.username} 👋`;
        }
        const memberSince = document.getElementById('memberSince');
        if (memberSince) {
            memberSince.textContent = userData.memberSince || '';
        }
        const headerPic = document.getElementById('headerProfilePic');
        if (headerPic) headerPic.src = userData.profilePic;
        const sidebarPic = document.getElementById('sidebarProfilePic');
        if (sidebarPic) sidebarPic.src = userData.profilePic;
        const sidebarUsername = document.getElementById('sidebarUsername');
        if (sidebarUsername) sidebarUsername.textContent = userData.username;
        document.querySelectorAll('.user-points').forEach(el => el.textContent = userData.points);
        document.querySelectorAll('.user-balance').forEach(el => el.textContent = userData.balance);
        window.userData = userData;
    },

    // Initialize user data and update UI
    async init() {
        const userData = await this.getUserData();
        if (userData) {
            this.updateUI(userData);
            return userData;
        }
        // If this page requires auth, redirect guests to login
        if (this.requireAuth) {
            window.location.href = '../login.html';
        } else {
            // Show guest defaults if needed
            const welcomeMsg = document.getElementById('welcomeMessage');
            if (welcomeMsg) welcomeMsg.textContent = 'Welcome, Guest 👋';
        }
        return null;
    },

    // Refresh user data from server
    async refresh() {
        const userData = await this.loadUserData();
        if (userData) {
            this.updateUI(userData);
        }
        return userData;
    }
};

// Auto-initialize when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        UserDataManager.init();
    });
} else {
    UserDataManager.init();
}

// Make available globally
window.UserData = window.UserDataManager;
