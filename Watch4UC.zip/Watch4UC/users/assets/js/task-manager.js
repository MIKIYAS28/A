/**
 * Task Manager Module
 * Handles task completion, validation, and related operations
 */

class TaskManager {
    constructor() {
        this.config = {
            apiEndpoints: {
                completeTask: '../api/user/complete-daily-task.php',
                updatePoints: '../api/points/update.php'
            },
            validation: {
                maxRetries: 3,
                retryDelay: 1000,
                timeoutDuration: 10000
            },
            referralCode: null
        };

        this.state = {
            completingTasks: new Set(),
            completedTasks: new Set(),
            retryAttempts: new Map()
        };

        this.init();
    }

    /**
     * Initialize Task Manager
     */
    init() {
        this.loadReferralCode();
        this.setupGlobalMethods();
    }

    /**
     * Load referral code for sharing
     */
    async loadReferralCode() {
        try {
            // This would typically come from the user data or a separate API call
            this.config.referralCode = 'default'; // Fallback value
        } catch (error) {
            console.error('Failed to load referral code:', error);
        }
    }

    /**
     * Setup global methods for backward compatibility
     */
    setupGlobalMethods() {
        // Make methods available globally for onclick handlers
        window.TaskManager = {
            completeTask: this.completeTask.bind(this),
            copyReferralLink: this.copyReferralLink.bind(this),
            claimBonus: this.claimBonus.bind(this)
        };
    }

    /**
     * Complete a task
     * @param {string} type - Task type (video, social, referral)
     * @param {number} coins - Coins to award
     * @param {number} taskId - Task ID
     */
    async completeTask(type, coins, taskId) {
        // Validate input parameters
        if (!this.validateTaskParams(type, coins, taskId)) {
            return;
        }

        // Prevent duplicate submissions
        const taskKey = `${type}-${taskId}`;
        if (this.state.completingTasks.has(taskKey)) {
            UIComponents.showToast('Task completion already in progress...', 'info');
            return;
        }

        // Check if task is already completed
        if (this.state.completedTasks.has(taskKey)) {
            UIComponents.showToast('Task already completed!', 'info');
            return;
        }

        try {
            this.state.completingTasks.add(taskKey);
            
            // Show loading state
            this.updateTaskButtonState(taskId, 'loading');
            
            // Perform task-specific validation
            const isValid = await this.validateTaskCompletion(type, taskId);
            if (!isValid) {
                throw new Error('Task validation failed');
            }

            // Submit task completion
            const result = await this.submitTaskCompletion(type, coins, taskId);
            
            if (result.success) {
                await this.handleTaskSuccess(type, coins, taskId, result);
            } else {
                throw new Error(result.message || 'Task completion failed');
            }

        } catch (error) {
            console.error('Error completing task:', error);
            await this.handleTaskError(type, coins, taskId, error);
        } finally {
            this.state.completingTasks.delete(taskKey);
        }
    }

    /**
     * Validate task parameters
     */
    validateTaskParams(type, coins, taskId) {
        const validTypes = ['video', 'social', 'referral'];
        
        if (!validTypes.includes(type)) {
            UIComponents.showToast('Invalid task type', 'error');
            return false;
        }

        if (!Number.isInteger(coins) || coins <= 0) {
            UIComponents.showToast('Invalid coin amount', 'error');
            return false;
        }

        if (!Number.isInteger(taskId) || taskId <= 0) {
            UIComponents.showToast('Invalid task ID', 'error');
            return false;
        }

        return true;
    }

    /**
     * Validate task completion based on type
     */
    async validateTaskCompletion(type, taskId) {
        switch (type) {
            case 'video':
                return await this.validateVideoTask(taskId);
            case 'social':
                return await this.validateSocialTask(taskId);
            case 'referral':
                return await this.validateReferralTask(taskId);
            default:
                return false;
        }
    }

    /**
     * Validate video task completion
     */
    async validateVideoTask(taskId) {
        // Add video-specific validation logic here
        // For example, check if video was actually watched
        return true; // Placeholder
    }

    /**
     * Validate social task completion
     */
    async validateSocialTask(taskId) {
        // Add social media task validation logic here
        // For example, verify social media interaction
        return true; // Placeholder
    }

    /**
     * Validate referral task completion
     */
    async validateReferralTask(taskId) {
        // Add referral task validation logic here
        return true; // Placeholder
    }

    /**
     * Submit task completion to API
     */
    async submitTaskCompletion(type, coins, taskId) {
        const formData = new FormData();
        formData.append('type', type);
        formData.append('coins', coins);
        formData.append('taskId', taskId);
        formData.append('timestamp', Date.now());

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.config.validation.timeoutDuration);

        try {
            const response = await fetch(this.config.apiEndpoints.completeTask, {
                method: 'POST',
                body: formData,
                signal: controller.signal,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return {
                success: result.ok || result.success,
                message: result.message,
                data: result.data || result
            };

        } catch (error) {
            clearTimeout(timeoutId);
            
            if (error.name === 'AbortError') {
                throw new Error('Request timeout. Please try again.');
            }
            
            throw error;
        }
    }

    /**
     * Handle successful task completion
     */
    async handleTaskSuccess(type, coins, taskId, result) {
        const taskKey = `${type}-${taskId}`;
        this.state.completedTasks.add(taskKey);
        
        // Update UI
        this.updateTaskButtonState(taskId, 'completed');
        this.updateUserPoints(coins);
        
        // Show success message
        UIComponents.showToast(`Task completed! +${coins} coins added to your account.`, 'success');
        
        // Update statistics
        this.updateTaskStatistics(type);
        
        // Check if all tasks are completed for bonus
        this.checkBonusEligibility();
        
        // Clear retry attempts
        this.state.retryAttempts.delete(taskKey);
    }

    /**
     * Handle task completion error
     */
    async handleTaskError(type, coins, taskId, error) {
        const taskKey = `${type}-${taskId}`;
        const retryCount = this.state.retryAttempts.get(taskKey) || 0;
        
        // Update button state
        this.updateTaskButtonState(taskId, 'error');
        
        // Check if we should retry
        if (retryCount < this.config.validation.maxRetries && this.isRetryableError(error)) {
            this.state.retryAttempts.set(taskKey, retryCount + 1);
            
            UIComponents.showToast(`Task failed. Retrying... (${retryCount + 1}/${this.config.validation.maxRetries})`, 'warning');
            
            // Retry after delay
            setTimeout(() => {
                this.completeTask(type, coins, taskId);
            }, this.config.validation.retryDelay * (retryCount + 1));
            
        } else {
            // Max retries reached or non-retryable error
            this.state.retryAttempts.delete(taskKey);
            this.updateTaskButtonState(taskId, 'failed');
            
            const errorMessage = this.getErrorMessage(error);
            UIComponents.showToast(errorMessage, 'error');
        }
    }

    /**
     * Check if error is retryable
     */
    isRetryableError(error) {
        const retryableErrors = [
            'network error',
            'timeout',
            'server error',
            'connection failed'
        ];
        
        const errorMessage = error.message.toLowerCase();
        return retryableErrors.some(retryableError => errorMessage.includes(retryableError));
    }

    /**
     * Get user-friendly error message
     */
    getErrorMessage(error) {
        const errorMap = {
            'network error': 'Network connection failed. Please check your internet connection.',
            'timeout': 'Request timed out. Please try again.',
            'server error': 'Server error occurred. Please try again later.',
            'validation failed': 'Task validation failed. Please complete the required action first.',
            'already completed': 'This task has already been completed.',
            'insufficient permissions': 'You do not have permission to complete this task.'
        };

        const errorMessage = error.message.toLowerCase();
        
        for (const [key, message] of Object.entries(errorMap)) {
            if (errorMessage.includes(key)) {
                return message;
            }
        }

        return 'An error occurred while completing the task. Please try again.';
    }

    /**
     * Update task button state
     */
    updateTaskButtonState(taskId, state) {
        const button = document.querySelector(`[onclick*="${taskId}"]`);
        if (!button) return;

        const states = {
            loading: {
                text: '<i class="ri-loader-4-line animate-spin" aria-hidden="true"></i> Processing...',
                disabled: true,
                className: 'task-button task-button--loading'
            },
            completed: {
                text: '<i class="ri-check-line" aria-hidden="true"></i> Completed',
                disabled: true,
                className: 'task-status task-status--completed'
            },
            error: {
                text: '<i class="ri-error-warning-line" aria-hidden="true"></i> Error',
                disabled: false,
                className: 'task-button task-button--error'
            },
            failed: {
                text: '<i class="ri-refresh-line" aria-hidden="true"></i> Retry',
                disabled: false,
                className: 'task-button task-button--retry'
            }
        };

        const stateConfig = states[state];
        if (stateConfig) {
            button.innerHTML = stateConfig.text;
            button.disabled = stateConfig.disabled;
            button.className = stateConfig.className;
        }
    }

    /**
     * Update user points in UI
     */
    updateUserPoints(coinsEarned) {
        const pointsElement = document.querySelector('#pointsBalance');
        if (pointsElement) {
            const currentPoints = parseInt(pointsElement.textContent) || 0;
            const newPoints = currentPoints + coinsEarned;
            pointsElement.textContent = newPoints;
            
            // Animate the change
            pointsElement.classList.add('animate-pulse');
            setTimeout(() => {
                pointsElement.classList.remove('animate-pulse');
            }, 1000);
        }
    }

    /**
     * Update task statistics
     */
    updateTaskStatistics(taskType) {
        // Update completed tasks counter
        const tasksCompletedElement = document.querySelector('#tasksCompleted');
        if (tasksCompletedElement) {
            // This would need to be implemented based on actual task tracking
            console.log(`Task statistics updated for ${taskType}`);
        }
    }

    /**
     * Check if user is eligible for bonus
     */
    checkBonusEligibility() {
        // This would check if all daily tasks are completed
        // For now, this is a placeholder
        const allTasksCompleted = false; // This would be calculated based on actual task data
        
        if (allTasksCompleted) {
            this.showBonusChest();
        }
    }

    /**
     * Show bonus chest
     */
    showBonusChest() {
        const bonusChest = document.querySelector('#bonusChest');
        if (bonusChest) {
            bonusChest.classList.remove('hidden');
            bonusChest.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    /**
     * Copy referral link to clipboard
     */
    async copyReferralLink() {
        try {
            const referralCode = this.config.referralCode || 'default';
            const referralLink = `${window.location.origin}/user/login.html?ref=${referralCode}`;
            
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(referralLink);
            } else {
                // Fallback for older browsers or non-HTTPS
                this.fallbackCopyToClipboard(referralLink);
            }
            
            UIComponents.showToast('Referral link copied to clipboard!', 'success');
            
            // Track referral link copy event
            this.trackReferralEvent('link_copied');
            
        } catch (error) {
            console.error('Failed to copy referral link:', error);
            UIComponents.showToast('Failed to copy link. Please try again.', 'error');
        }
    }

    /**
     * Fallback method to copy text to clipboard
     */
    fallbackCopyToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
        } catch (error) {
            throw new Error('Clipboard copy failed');
        } finally {
            document.body.removeChild(textArea);
        }
    }

    /**
     * Track referral events
     */
    trackReferralEvent(eventType) {
        // This would send analytics data to track referral performance
        console.log(`Referral event tracked: ${eventType}`);
    }

    /**
     * Claim bonus reward
     */
    async claimBonus() {
        try {
            const bonusAmount = 10; // This would come from the API or configuration
            
            // Show loading state
            const bonusButton = document.querySelector('#bonusChest button');
            if (bonusButton) {
                bonusButton.disabled = true;
                bonusButton.innerHTML = '<i class="ri-loader-4-line animate-spin" aria-hidden="true"></i> Claiming...';
            }
            
            // Submit bonus claim (this would be an actual API call)
            await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
            
            // Update points
            this.updateUserPoints(bonusAmount);
            
            // Hide bonus chest
            const bonusChest = document.querySelector('#bonusChest');
            if (bonusChest) {
                bonusChest.classList.add('hidden');
            }
            
            UIComponents.showToast(`Bonus claimed! +${bonusAmount} coins added to your account!`, 'success');
            
        } catch (error) {
            console.error('Error claiming bonus:', error);
            UIComponents.showToast('Failed to claim bonus. Please try again.', 'error');
            
            // Reset button state
            const bonusButton = document.querySelector('#bonusChest button');
            if (bonusButton) {
                bonusButton.disabled = false;
                bonusButton.innerHTML = 'Claim Bonus';
            }
        }
    }

    /**
     * Reset daily tasks (for testing or admin purposes)
     */
    resetDailyTasks() {
        this.state.completedTasks.clear();
        this.state.retryAttempts.clear();
        
        // Reset UI elements
        document.querySelectorAll('.task-button').forEach(button => {
            button.disabled = false;
            button.className = 'task-button';
        });
        
        // Hide bonus chest
        const bonusChest = document.querySelector('#bonusChest');
        if (bonusChest) {
            bonusChest.classList.add('hidden');
        }
        
        UIComponents.showToast('Daily tasks reset successfully!', 'info');
    }

    /**
     * Get task completion statistics
     */
    getTaskStatistics() {
        return {
            completedTasks: Array.from(this.state.completedTasks),
            completingTasks: Array.from(this.state.completingTasks),
            retryAttempts: Object.fromEntries(this.state.retryAttempts)
        };
    }
}

// Initialize Task Manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.taskManager = new TaskManager();
});

// Export for use in other modules
window.TaskManager = TaskManager;