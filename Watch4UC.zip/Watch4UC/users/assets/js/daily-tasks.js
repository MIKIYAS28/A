/**
 * Daily Tasks Main Module
 * Handles initialization and coordination of daily tasks functionality
 */

class DailyTasksApp {
    constructor() {
        this.config = {
            apiEndpoints: {
                userProfile: '../api/auth/me.php',
                liveTasks: '../api/user/live-tasks.php',
                completeTask: '../api/user/complete-daily-task.php'
            },
            selectors: {
                loadingSpinner: '#loadingSpinner',
                sidebar: '#sidebar',
                mobileMenuButton: '#mobileMenuButton',
                darkModeToggle: '#darkModeToggle',
                userName: '#userName',
                memberSince: '#memberSince',
                pointsBalance: '#pointsBalance',
                tasksCompleted: '#tasksCompleted',
                coinsEarned: '#coinsEarned',
                potentialCoins: '#potentialCoins',
                streakDays: '#streakDays',
                bonusChest: '#bonusChest',
                resetTimer: '#resetTimer',
                watchingTasks: '#watchingTasks',
                socialTasks: '#socialTasks',
                referralTasks: '#referralTasks'
            },
            classes: {
                open: 'open',
                hidden: 'hidden',
                dark: 'dark',
                completed: 'task-card--completed'
            }
        };

        this.state = {
            isLoading: true,
            userData: null,
            tasksData: null,
            darkMode: false
        };

        this.init();
    }

    /**
     * Initialize the application
     */
    async init() {
        try {
            this.showLoading();
            this.setupEventListeners();
            await this.loadUserData();
            await this.loadTasks();
            this.initializeDarkMode();
            this.startResetTimer();
            this.hideLoading();
        } catch (error) {
            console.error('Failed to initialize Daily Tasks app:', error);
            UIComponents.showToast('Failed to load application. Please refresh the page.', 'error');
            this.hideLoading();
        }
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector(this.config.selectors.mobileMenuButton);
        const sidebar = document.querySelector(this.config.selectors.sidebar);

        if (mobileMenuButton && sidebar) {
            mobileMenuButton.addEventListener('click', () => this.toggleMobileMenu());
            
            // Close sidebar when clicking outside
            document.addEventListener('click', (e) => {
                if (!e.target.closest(this.config.selectors.sidebar) && 
                    !e.target.closest(this.config.selectors.mobileMenuButton)) {
                    this.closeMobileMenu();
                }
            });
        }

        // Dark mode toggle
        const darkModeToggle = document.querySelector(this.config.selectors.darkModeToggle);
        if (darkModeToggle && !darkModeToggle.hasAttribute('data-initialized')) {
            darkModeToggle.addEventListener('change', (e) => this.toggleDarkMode(e.target.checked));
            darkModeToggle.setAttribute('data-initialized', 'true');
        }

        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyboardNavigation(e));

        // Window resize handler
        window.addEventListener('resize', () => this.handleResize());
    }

    /**
     * Load user data from API
     */
    async loadUserData() {
        try {
            const response = await fetch(this.config.apiEndpoints.userProfile);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const userData = await response.json();
            
            if (userData && userData.username) {
                this.state.userData = userData;
                this.updateUserInterface(userData);
            } else {
                console.warn('Invalid user data received');
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            // Set default values for guest user
            this.updateUserInterface({
                username: 'Guest',
                joined_at: new Date().toISOString(),
                points: 0
            });
        }
    }

    /**
     * Update user interface with user data
     */
    updateUserInterface(userData) {
        const elements = {
            userName: document.querySelector(this.config.selectors.userName),
            memberSince: document.querySelector(this.config.selectors.memberSince),
            pointsBalance: document.querySelector(this.config.selectors.pointsBalance)
        };

        if (elements.userName) {
            elements.userName.textContent = userData.username || 'Guest';
        }

        if (elements.memberSince) {
            const joinDate = new Date(userData.joined_at || Date.now());
            elements.memberSince.textContent = joinDate.toLocaleDateString();
        }

        if (elements.pointsBalance) {
            elements.pointsBalance.textContent = userData.points || 0;
        }
    }

    /**
     * Load tasks from API
     */
    async loadTasks() {
        try {
            const response = await fetch(this.config.apiEndpoints.liveTasks);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.ok) {
                this.state.tasksData = data;
                this.renderTasks(data);
            } else {
                throw new Error(data.message || 'Failed to load tasks');
            }
        } catch (error) {
            console.error('Error loading tasks:', error);
            this.renderEmptyState();
            UIComponents.showToast('Failed to load tasks. Please try again later.', 'error');
        }
    }

    /**
     * Render tasks in their respective sections
     */
    renderTasks(data) {
        const taskSections = [
            { key: 'video', containerId: 'watchingTasks', renderer: this.renderVideoTask.bind(this) },
            { key: 'social', containerId: 'socialTasks', renderer: this.renderSocialTask.bind(this) },
            { key: 'referral', containerId: 'referralTasks', renderer: this.renderReferralTask.bind(this) }
        ];

        taskSections.forEach(section => {
            const container = document.querySelector(`#${section.containerId}`);
            if (!container) return;

            container.innerHTML = '';

            const tasks = data.tasks?.[section.key] || data[section.key] || [];
            
            if (tasks.length === 0) {
                this.renderEmptyTaskSection(container, section.key);
            } else {
                tasks.forEach(task => {
                    const taskElement = section.renderer(task);
                    container.appendChild(taskElement);
                });
            }
        });

        this.updateStatistics(data);
    }

    /**
     * Render video task card
     */
    renderVideoTask(task) {
        const isCompleted = task.completed;
        const taskCard = document.createElement('div');
        taskCard.className = `task-card ${isCompleted ? this.config.classes.completed : ''}`;
        taskCard.setAttribute('role', 'listitem');

        taskCard.innerHTML = `
            <div class="task-card-header">
                <div class="task-card-icon task-card-icon--video">
                    <i class="ri-video-line" aria-hidden="true"></i>
                </div>
                <div class="task-card-content">
                    <h3 class="task-card-title">${this.escapeHtml(task.title)}</h3>
                    <p class="task-card-subtitle">${this.escapeHtml(task.type)}</p>
                </div>
            </div>
            <div class="task-card-footer">
                <span class="task-reward">+${task.reward} coins</span>
                ${isCompleted 
                    ? '<span class="task-status task-status--completed">✓ Completed</span>'
                    : `<button class="task-button" onclick="TaskManager.completeTask('video', ${task.reward}, ${task.id})" aria-label="Start ${this.escapeHtml(task.title)}">
                         <i class="ri-play-line" aria-hidden="true"></i> Start
                       </button>`
                }
            </div>
        `;

        return taskCard;
    }

    /**
     * Render social media task card
     */
    renderSocialTask(task) {
        const isCompleted = task.completed;
        const taskCard = document.createElement('div');
        taskCard.className = `task-card ${isCompleted ? this.config.classes.completed : ''}`;
        taskCard.setAttribute('role', 'listitem');

        const platformIcon = this.getPlatformIcon(task.platform);

        taskCard.innerHTML = `
            <div class="task-card-header">
                <div class="task-card-icon task-card-icon--social">
                    <i class="${platformIcon}" aria-hidden="true"></i>
                </div>
                <div class="task-card-content">
                    <h3 class="task-card-title">${this.escapeHtml(task.name)}</h3>
                    <p class="task-card-subtitle">${this.escapeHtml(task.platform)}</p>
                </div>
            </div>
            <div class="task-card-footer">
                <span class="task-reward">+${task.reward} coins</span>
                ${isCompleted 
                    ? '<span class="task-status task-status--completed">✓ Completed</span>'
                    : `<button class="task-button" onclick="TaskManager.completeTask('social', ${task.reward}, ${task.id})" aria-label="Complete ${this.escapeHtml(task.name)}">
                         Complete
                       </button>`
                }
            </div>
        `;

        return taskCard;
    }

    /**
     * Render referral task card
     */
    renderReferralTask(task) {
        const isCompleted = task.completed;
        const taskCard = document.createElement('div');
        taskCard.className = `task-card ${isCompleted ? this.config.classes.completed : ''}`;
        taskCard.setAttribute('role', 'listitem');

        let actionButton = '';
        if (task.type === 'share') {
            actionButton = `<button class="task-button" onclick="TaskManager.copyReferralLink()" aria-label="Copy referral link">
                              <i class="ri-link" aria-hidden="true"></i> Copy Link
                            </button>`;
        } else if (!isCompleted) {
            actionButton = `<span class="task-status task-status--progress">${task.progress || 0}/${task.count || 0}</span>`;
        } else {
            actionButton = '<span class="task-status task-status--completed">✓ Completed</span>';
        }

        taskCard.innerHTML = `
            <div class="task-card-header">
                <div class="task-card-icon task-card-icon--referral">
                    <i class="ri-user-add-line" aria-hidden="true"></i>
                </div>
                <div class="task-card-content">
                    <h3 class="task-card-title">${this.escapeHtml(task.title)}</h3>
                    <p class="task-card-subtitle">${this.escapeHtml(task.description)}</p>
                </div>
            </div>
            <div class="task-card-footer">
                <span class="task-reward">+${task.reward} coins</span>
                ${actionButton}
            </div>
        `;

        return taskCard;
    }

    /**
     * Render empty state for task sections
     */
    renderEmptyTaskSection(container, taskType) {
        const emptyState = document.createElement('div');
        emptyState.className = 'task-empty-state';
        emptyState.innerHTML = `
            <i class="ri-inbox-line task-empty-icon" aria-hidden="true"></i>
            <p>No ${taskType} tasks available right now.</p>
        `;
        container.appendChild(emptyState);
    }

    /**
     * Render empty state for all tasks
     */
    renderEmptyState() {
        const taskContainers = [
            this.config.selectors.watchingTasks,
            this.config.selectors.socialTasks,
            this.config.selectors.referralTasks
        ];

        taskContainers.forEach(selector => {
            const container = document.querySelector(selector);
            if (container) {
                this.renderEmptyTaskSection(container, selector.replace('#', '').replace('Tasks', ''));
            }
        });
    }

    /**
     * Update statistics display
     */
    updateStatistics(data) {
        // This would be implemented based on the actual data structure
        // For now, keeping the existing static values
        console.log('Statistics updated with data:', data);
    }

    /**
     * Initialize dark mode
     */
    initializeDarkMode() {
        const darkModeToggle = document.querySelector(this.config.selectors.darkModeToggle);
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        
        this.state.darkMode = isDarkMode;
        document.body.classList.toggle(this.config.classes.dark, isDarkMode);
        
        if (darkModeToggle) {
            darkModeToggle.checked = isDarkMode;
        }
    }

    /**
     * Toggle dark mode
     */
    toggleDarkMode(isDark) {
        this.state.darkMode = isDark;
        document.body.classList.toggle(this.config.classes.dark, isDark);
        localStorage.setItem('darkMode', isDark);
        
        // Smooth transition for background
        document.body.style.backgroundColor = isDark ? '#111827' : '#ffffff';
    }

    /**
     * Toggle mobile menu
     */
    toggleMobileMenu() {
        const sidebar = document.querySelector(this.config.selectors.sidebar);
        const mobileMenuButton = document.querySelector(this.config.selectors.mobileMenuButton);
        
        if (sidebar && mobileMenuButton) {
            const isOpen = sidebar.classList.toggle(this.config.classes.open);
            mobileMenuButton.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        }
    }

    /**
     * Close mobile menu
     */
    closeMobileMenu() {
        const sidebar = document.querySelector(this.config.selectors.sidebar);
        const mobileMenuButton = document.querySelector(this.config.selectors.mobileMenuButton);
        
        if (sidebar && mobileMenuButton) {
            sidebar.classList.remove(this.config.classes.open);
            mobileMenuButton.setAttribute('aria-expanded', 'false');
        }
    }

    /**
     * Handle keyboard navigation
     */
    handleKeyboardNavigation(e) {
        // ESC key closes mobile menu
        if (e.key === 'Escape') {
            this.closeMobileMenu();
        }
    }

    /**
     * Handle window resize
     */
    handleResize() {
        // Close mobile menu on desktop resize
        if (window.innerWidth >= 1024) {
            this.closeMobileMenu();
        }
    }

    /**
     * Start reset timer countdown
     */
    startResetTimer() {
        const resetTimerElement = document.querySelector(this.config.selectors.resetTimer);
        if (!resetTimerElement) return;

        // Calculate time until next reset (example: 4 hours 22 minutes)
        const now = new Date();
        const nextReset = new Date(now);
        nextReset.setHours(nextReset.getHours() + 4, nextReset.getMinutes() + 22, 0, 0);

        const updateTimer = () => {
            const timeLeft = nextReset - new Date();
            
            if (timeLeft <= 0) {
                resetTimerElement.textContent = 'Tasks resetting...';
                // Reload tasks when timer expires
                this.loadTasks();
                return;
            }

            const hours = Math.floor(timeLeft / (1000 * 60 * 60));
            const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            
            resetTimerElement.textContent = `${hours} hours ${minutes} minutes`;
        };

        updateTimer();
        setInterval(updateTimer, 60000); // Update every minute
    }

    /**
     * Show loading spinner
     */
    showLoading() {
        const spinner = document.querySelector(this.config.selectors.loadingSpinner);
        if (spinner) {
            spinner.classList.remove(this.config.classes.hidden);
        }
    }

    /**
     * Hide loading spinner
     */
    hideLoading() {
        const spinner = document.querySelector(this.config.selectors.loadingSpinner);
        if (spinner) {
            spinner.classList.add(this.config.classes.hidden);
        }
    }

    /**
     * Get platform icon class
     */
    getPlatformIcon(platform) {
        const iconMap = {
            'twitter': 'ri-twitter-x-line',
            'facebook': 'ri-facebook-line',
            'instagram': 'ri-instagram-line',
            'youtube': 'ri-youtube-line',
            'tiktok': 'ri-tiktok-line',
            'linkedin': 'ri-linkedin-line'
        };
        
        return iconMap[platform?.toLowerCase()] || 'ri-share-line';
    }

    /**
     * Escape HTML to prevent XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Refresh tasks data
     */
    async refreshTasks() {
        this.showLoading();
        await this.loadTasks();
        this.hideLoading();
        UIComponents.showToast('Tasks refreshed successfully!', 'success');
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dailyTasksApp = new DailyTasksApp();
});

// Export for use in other modules
window.DailyTasksApp = DailyTasksApp;
// Mobile touch handling
class MobileLayoutManager {
    constructor() {
        this.setupMobileGestures();
    }

    setupMobileGestures() {
        // Swipe to close sidebar
        let startX = 0;
        let currentX = 0;

        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
        });

        document.addEventListener('touchmove', (e) => {
            currentX = e.touches[0].clientX;
            const sidebar = document.querySelector('.sidebar');
            
            if (startX < 50 && currentX > startX + 50) {
                sidebar.classList.add('open');
            } else if (startX > 100 && currentX < startX - 50) {
                sidebar.classList.remove('open');
            }
        });

        // Handle viewport height on mobile
        this.setViewportHeight();
        window.addEventListener('resize', () => this.setViewportHeight());
    }

    setViewportHeight() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
}

// Initialize mobile manager
const mobileManager = new MobileLayoutManager();