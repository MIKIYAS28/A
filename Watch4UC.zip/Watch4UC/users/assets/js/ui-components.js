/**
 * UI Components Module
 * Provides reusable UI components and utilities
 */

class UIComponents {
    constructor() {
        this.config = {
            toastDuration: 5000,
            animationDuration: 300,
            debounceDelay: 250
        };

        this.state = {
            activeToasts: new Set(),
            debounceTimers: new Map()
        };

        this.init();
    }

    /**
     * Initialize UI Components
     */
    init() {
        this.setupGlobalMethods();
        this.initializeToastContainer();
        this.setupKeyboardShortcuts();
        this.setupAccessibilityFeatures();
    }

    /**
     * Setup global methods for easy access
     */
    setupGlobalMethods() {
        window.UIComponents = {
            showToast: this.showToast.bind(this),
            hideToast: this.hideToast.bind(this),
            showModal: this.showModal.bind(this),
            hideModal: this.hideModal.bind(this),
            showLoading: this.showLoading.bind(this),
            hideLoading: this.hideLoading.bind(this),
            debounce: this.debounce.bind(this),
            throttle: this.throttle.bind(this),
            formatNumber: this.formatNumber.bind(this),
            formatDate: this.formatDate.bind(this),
            validateInput: this.validateInput.bind(this),
            animateElement: this.animateElement.bind(this)
        };
    }

    /**
     * Initialize toast container if it doesn't exist
     */
    initializeToastContainer() {
        if (!document.querySelector('.toast-container')) {
            const container = document.createElement('div');
            container.className = 'toast-container fixed top-4 right-4 z-50 space-y-2';
            container.setAttribute('aria-live', 'polite');
            container.setAttribute('aria-label', 'Notifications');
            document.body.appendChild(container);
        }
    }

    /**
     * Show toast notification
     * @param {string} message - Toast message
     * @param {string} type - Toast type (success, error, warning, info)
     * @param {number} duration - Duration in milliseconds
     */
    showToast(message, type = 'info', duration = this.config.toastDuration) {
        if (!message) return;

        const toastId = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const toast = this.createToastElement(toastId, message, type);
        
        const container = document.querySelector('.toast-container') || document.body;
        container.appendChild(toast);
        
        this.state.activeToasts.add(toastId);

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });

        // Auto-hide after duration
        if (duration > 0) {
            setTimeout(() => {
                this.hideToast(toastId);
            }, duration);
        }

        return toastId;
    }

    /**
     * Create toast element
     */
    createToastElement(toastId, message, type) {
        const toast = document.createElement('div');
        toast.id = toastId;
        toast.className = `toast toast--${type} transform translate-x-full transition-transform duration-300`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');

        const iconMap = {
            success: 'ri-check-line',
            error: 'ri-error-warning-line',
            warning: 'ri-alert-line',
            info: 'ri-information-line'
        };

        toast.innerHTML = `
            <div class="toast-content flex items-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="toast-icon flex-shrink-0 w-5 h-5 mr-3 text-${this.getTypeColor(type)}-500">
                    <i class="${iconMap[type]}" aria-hidden="true"></i>
                </div>
                <div class="toast-message flex-1 text-sm text-gray-800 dark:text-gray-200">
                    ${this.escapeHtml(message)}
                </div>
                <button class="toast-close ml-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200" 
                        onclick="UIComponents.hideToast('${toastId}')"
                        aria-label="Close notification">
                    <i class="ri-close-line w-4 h-4" aria-hidden="true"></i>
                </button>
            </div>
        `;

        return toast;
    }

    /**
     * Hide toast notification
     */
    hideToast(toastId) {
        const toast = document.getElementById(toastId);
        if (!toast) return;

        toast.classList.remove('show');
        toast.classList.add('translate-x-full');

        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
            this.state.activeToasts.delete(toastId);
        }, this.config.animationDuration);
    }

    /**
     * Show modal dialog
     */
    showModal(options = {}) {
        const {
            title = 'Modal',
            content = '',
            type = 'info',
            showCancel = true,
            confirmText = 'OK',
            cancelText = 'Cancel',
            onConfirm = null,
            onCancel = null
        } = options;

        const modalId = `modal-${Date.now()}`;
        const modal = this.createModalElement(modalId, title, content, type, showCancel, confirmText, cancelText);
        
        document.body.appendChild(modal);
        document.body.classList.add('modal-open');

        // Focus management
        const firstFocusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (firstFocusable) {
            firstFocusable.focus();
        }

        // Setup event handlers
        this.setupModalEventHandlers(modalId, onConfirm, onCancel);

        // Animate in
        requestAnimationFrame(() => {
            modal.classList.add('show');
        });

        return modalId;
    }

    /**
     * Create modal element
     */
    createModalElement(modalId, title, content, type, showCancel, confirmText, cancelText) {
        const modal = document.createElement('div');
        modal.id = modalId;
        modal.className = 'modal fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50 opacity-0 transition-opacity duration-300';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', `${modalId}-title`);

        const iconMap = {
            success: 'ri-check-line text-green-500',
            error: 'ri-error-warning-line text-red-500',
            warning: 'ri-alert-line text-yellow-500',
            info: 'ri-information-line text-blue-500'
        };

        modal.innerHTML = `
            <div class="modal-content bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full transform scale-95 transition-transform duration-300">
                <div class="modal-header flex items-center p-6 border-b border-gray-200 dark:border-gray-700">
                    <div class="modal-icon w-8 h-8 mr-3">
                        <i class="${iconMap[type]}" aria-hidden="true"></i>
                    </div>
                    <h2 id="${modalId}-title" class="modal-title text-lg font-semibold text-gray-800 dark:text-gray-200">
                        ${this.escapeHtml(title)}
                    </h2>
                </div>
                <div class="modal-body p-6">
                    <div class="text-gray-600 dark:text-gray-400">
                        ${content}
                    </div>
                </div>
                <div class="modal-footer flex justify-end space-x-3 p-6 border-t border-gray-200 dark:border-gray-700">
                    ${showCancel ? `
                        <button class="modal-cancel px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors duration-200">
                            ${this.escapeHtml(cancelText)}
                        </button>
                    ` : ''}
                    <button class="modal-confirm px-4 py-2 bg-primary text-white rounded-button hover:opacity-90 transition-opacity duration-200">
                        ${this.escapeHtml(confirmText)}
                    </button>
                </div>
            </div>
        `;

        return modal;
    }

    /**
     * Setup modal event handlers
     */
    setupModalEventHandlers(modalId, onConfirm, onCancel) {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        const confirmBtn = modal.querySelector('.modal-confirm');
        const cancelBtn = modal.querySelector('.modal-cancel');

        if (confirmBtn) {
            confirmBtn.addEventListener('click', () => {
                if (onConfirm) onConfirm();
                this.hideModal(modalId);
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                if (onCancel) onCancel();
                this.hideModal(modalId);
            });
        }

        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                if (onCancel) onCancel();
                this.hideModal(modalId);
            }
        });

        // Close on Escape key
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                if (onCancel) onCancel();
                this.hideModal(modalId);
                document.removeEventListener('keydown', handleEscape);
            }
        };
        document.addEventListener('keydown', handleEscape);
    }

    /**
     * Hide modal dialog
     */
    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        modal.classList.remove('show');
        modal.classList.add('opacity-0');

        setTimeout(() => {
            if (modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
            document.body.classList.remove('modal-open');
        }, this.config.animationDuration);
    }

    /**
     * Show loading overlay
     */
    showLoading(message = 'Loading...') {
        let loader = document.getElementById('global-loader');
        
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'global-loader';
            loader.className = 'fixed inset-0 z-50 flex items-center justify-center bg-white dark:bg-gray-900 bg-opacity-75';
            loader.innerHTML = `
                <div class="text-center">
                    <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                    <p class="text-gray-600 dark:text-gray-400">${this.escapeHtml(message)}</p>
                </div>
            `;
            document.body.appendChild(loader);
        }

        loader.classList.remove('hidden');
    }

    /**
     * Hide loading overlay
     */
    hideLoading() {
        const loader = document.getElementById('global-loader');
        if (loader) {
            loader.classList.add('hidden');
        }
    }

    /**
     * Debounce function calls
     */
    debounce(func, delay = this.config.debounceDelay, key = 'default') {
        if (this.state.debounceTimers.has(key)) {
            clearTimeout(this.state.debounceTimers.get(key));
        }

        const timerId = setTimeout(() => {
            func();
            this.state.debounceTimers.delete(key);
        }, delay);

        this.state.debounceTimers.set(key, timerId);
    }

    /**
     * Throttle function calls
     */
    throttle(func, delay = this.config.debounceDelay) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, delay);
            }
        };
    }

    /**
     * Format numbers with proper separators
     */
    formatNumber(number, options = {}) {
        const {
            locale = 'en-US',
            minimumFractionDigits = 0,
            maximumFractionDigits = 2
        } = options;

        return new Intl.NumberFormat(locale, {
            minimumFractionDigits,
            maximumFractionDigits
        }).format(number);
    }

    /**
     * Format dates
     */
    formatDate(date, options = {}) {
        const {
            locale = 'en-US',
            dateStyle = 'medium',
            timeStyle = undefined
        } = options;

        return new Intl.DateTimeFormat(locale, {
            dateStyle,
            timeStyle
        }).format(new Date(date));
    }

    /**
     * Validate input fields
     */
    validateInput(input, rules = {}) {
        const value = input.value.trim();
        const errors = [];

        if (rules.required && !value) {
            errors.push('This field is required');
        }

        if (rules.minLength && value.length < rules.minLength) {
            errors.push(`Minimum length is ${rules.minLength} characters`);
        }

        if (rules.maxLength && value.length > rules.maxLength) {
            errors.push(`Maximum length is ${rules.maxLength} characters`);
        }

        if (rules.pattern && !rules.pattern.test(value)) {
            errors.push(rules.patternMessage || 'Invalid format');
        }

        if (rules.email && value && !this.isValidEmail(value)) {
            errors.push('Please enter a valid email address');
        }

        // Update input styling
        if (errors.length > 0) {
            input.classList.add('border-red-500', 'focus:border-red-500');
            input.classList.remove('border-green-500', 'focus:border-green-500');
        } else if (value) {
            input.classList.add('border-green-500', 'focus:border-green-500');
            input.classList.remove('border-red-500', 'focus:border-red-500');
        }

        return {
            isValid: errors.length === 0,
            errors
        };
    }

    /**
     * Animate element with CSS classes
     */
    animateElement(element, animation, duration = this.config.animationDuration) {
        return new Promise((resolve) => {
            element.classList.add(animation);
            
            setTimeout(() => {
                element.classList.remove(animation);
                resolve();
            }, duration);
        });
    }

    /**
     * Setup keyboard shortcuts
     */
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + K for search (if implemented)
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                // Implement search functionality
            }

            // Escape to close modals/dropdowns
            if (e.key === 'Escape') {
                // Close any open dropdowns or modals
                document.querySelectorAll('.modal.show').forEach(modal => {
                    const modalId = modal.id;
                    this.hideModal(modalId);
                });
            }
        });
    }

    /**
     * Setup accessibility features
     */
    setupAccessibilityFeatures() {
        // Skip to main content link
        if (!document.querySelector('.skip-link')) {
            const skipLink = document.createElement('a');
            skipLink.className = 'skip-link sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-primary text-white px-4 py-2 rounded z-50';
            skipLink.href = '#main-content';
            skipLink.textContent = 'Skip to main content';
            document.body.insertBefore(skipLink, document.body.firstChild);
        }

        // Announce page changes to screen readers
        this.announcePageChange();

        // High contrast mode detection
        if (window.matchMedia('(prefers-contrast: high)').matches) {
            document.body.classList.add('high-contrast');
        }

        // Reduced motion detection
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            document.body.classList.add('reduced-motion');
        }
    }

    /**
     * Announce page changes to screen readers
     */
    announcePageChange() {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.textContent = 'Page content updated';
        document.body.appendChild(announcement);

        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }

    /**
     * Get color class for toast type
     */
    getTypeColor(type) {
        const colorMap = {
            success: 'green',
            error: 'red',
            warning: 'yellow',
            info: 'blue'
        };
        return colorMap[type] || 'blue';
    }

    /**
     * Validate email format
     */
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * Escape HTML to prevent XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Create loading button state
     */
    setButtonLoading(button, isLoading, originalText = null) {
        if (isLoading) {
            button.dataset.originalText = originalText || button.textContent;
            button.innerHTML = '<i class="ri-loader-4-line animate-spin mr-2" aria-hidden="true"></i>Loading...';
            button.disabled = true;
        } else {
            button.innerHTML = button.dataset.originalText || 'Submit';
            button.disabled = false;
            delete button.dataset.originalText;
        }
    }

    /**
     * Create progress bar
     */
    createProgressBar(container, progress = 0, options = {}) {
        const {
            showPercentage = true,
            animated = true,
            color = 'primary'
        } = options;

        const progressBar = document.createElement('div');
        progressBar.className = 'progress-bar w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2';
        progressBar.setAttribute('role', 'progressbar');
        progressBar.setAttribute('aria-valuenow', progress);
        progressBar.setAttribute('aria-valuemin', '0');
        progressBar.setAttribute('aria-valuemax', '100');

        const progressFill = document.createElement('div');
        progressFill.className = `progress-bar-fill bg-${color} h-2 rounded-full transition-all duration-300`;
        progressFill.style.width = `${progress}%`;

        progressBar.appendChild(progressFill);

        if (showPercentage) {
            const percentage = document.createElement('span');
            percentage.className = 'progress-percentage text-sm text-gray-600 dark:text-gray-400 mt-1 block';
            percentage.textContent = `${progress}%`;
            progressBar.appendChild(percentage);
        }

        container.appendChild(progressBar);

        return {
            update: (newProgress) => {
                progressFill.style.width = `${newProgress}%`;
                progressBar.setAttribute('aria-valuenow', newProgress);
                if (showPercentage) {
                    const percentage = progressBar.querySelector('.progress-percentage');
                    if (percentage) {
                        percentage.textContent = `${newProgress}%`;
                    }
                }
            }
        };
    }

    /**
     * Cleanup resources
     */
    cleanup() {
        // Clear all timers
        this.state.debounceTimers.forEach(timerId => clearTimeout(timerId));
        this.state.debounceTimers.clear();

        // Remove all active toasts
        this.state.activeToasts.forEach(toastId => this.hideToast(toastId));
        this.state.activeToasts.clear();
    }
}

// Initialize UI Components when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.uiComponents = new UIComponents();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.uiComponents) {
        window.uiComponents.cleanup();
    }
});

// Export for use in other modules
window.UIComponents = UIComponents;