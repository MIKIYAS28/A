<?php
require_once 'includes/functions.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? '')) die('Invalid CSRF');

    $current = $_POST['current'];
    $new     = $_POST['new'];
    $confirm = $_POST['confirm'];

    if ($new !== $confirm || strlen($new) < 8) {
        $_SESSION['msg'] = 'Password mismatch or too short';
        header('Location: profile.php'); exit;
    }

    $stmt = $pdo->prepare('SELECT password FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $hash = $stmt->fetchColumn();

    if (!password_verify($current, $hash)) {
        $_SESSION['msg'] = 'Current password wrong';
        header('Location: profile.php'); exit;
    }

    $newHash = password_hash($new, PASSWORD_DEFAULT);
    updatePassword($_SESSION['user_id'], $newHash);
    $_SESSION['msg'] = 'Password changed';
    header('Location: profile.php'); exit;
}