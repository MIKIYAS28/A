<?php
// Load user data and require authentication
require_once 'includes/user-data.php';
requireLogin(); // Redirect to login if not authenticated
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Redeem PUBG UC</title>
  <script src="https://cdn.tailwindcss.com/3.4.16"></script>
  <!-- 1. Tailwind CDN (already identical) -->
<script src="https://cdn.tailwindcss.com/3.4.16"></script>
<script>
tailwind.config = { darkMode:'class', theme:{extend:{colors:{primary:'#FFD700',secondary:'#357ABD'}}}}
</script>

<!-- 2. Fonts & Icons (already identical) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
<script src="assets/js/global.js"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            primary: '#FBD300',
            secondary: '#357ABD',
            dark: '#111827',
            darker: '#0B1120'
          },
          borderRadius: {
            'none': '0px',
            'sm': '8px',
            DEFAULT: '12px',
            'md': '16px',
            'lg': '20px',
            'xl': '24px',
            '2xl': '28px',
            '3xl': '32px',
            'full': '9999px',
            'button': '12px'
          }
        }
      }
    }
  </script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css">
  <style>
    /* Custom styles */
    body {
      font-family: 'Inter', sans-serif;
      transition: background-color 0.5s ease, color 0.5s ease;
    }
    
    .sidebar {
      transition: transform 0.3s ease;
    }
    
    .sidebar-item:hover {
      background-color: rgba(255, 215, 0, 0.15);
    }
    
    .sidebar-item.active {
      background: linear-gradient(90deg, rgba(255, 215, 0, 0.2) 0%, rgba(53, 122, 189, 0.1) 100%);
      border-left: 3px solid #FFD700;
    }
    
    .progress-bar {
      height: 8px;
      background-color: #1f2937;
      border-radius: 4px;
      overflow: hidden;
    }
    
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, #4A90E2 0%, #357ABD 100%);
      border-radius: 4px;
      transition: width 0.3s ease;
    }
    
    .chatbot-button {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 56px;
      height: 56px;
      border-radius: 28px;
      background: linear-gradient(135deg, #4A90E2 0%, #357ABD 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      box-shadow: 0 4px 12px rgba(74, 144, 226, 0.3);
      cursor: pointer;
      transition: transform 0.3s ease;
      z-index: 50;
    }
    
    .chatbot-button:hover {
      transform: scale(1.05);
    }
    
    .mobile-menu-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 30;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s ease;
    }
    
    .mobile-menu-overlay.active {
      opacity: 1;
      pointer-events: all;
    }
    
    @media (max-width: 1024px) {
      .sidebar {
        transform: translateX(-100%);
        position: fixed;
        z-index: 40;
        transition: transform 0.3s ease;
      }
      .sidebar.open {
        transform: translateX(0);
      }
      .main-content {
        margin-left: 0;
      }
    }
    
    .uc-card {
      background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(30, 64, 175, 0.1) 100%);
      border: 1px solid rgba(59, 130, 246, 0.2);
    }
    
    .input-field {
      transition: all 0.3s ease;
    }
    
    .input-field:focus {
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
    }
    
    .success-toast {
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%) translateY(100px);
      background-color: #10B981;
      color: white;
      padding: 12px 24px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 100;
      transition: transform 0.4s ease;
      display: flex;
      align-items: center;
    }
    
    .success-toast.show {
      transform: translateX(-50%) translateY(0);
    }
    
    .success-toast i {
      margin-right: 8px;
    }
    
    /* Dark mode toggle styles */
    .custom-switch {
      position: relative;
      display: inline-block;
      width: 48px;
      height: 24px;
    }
    
    .custom-switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: .4s;
      border-radius: 24px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 18px;
      width: 18px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #4A90E2;
    }
    
    input:checked + .slider:before {
      transform: translateX(24px);
    }
    
    /* Dark mode specific styles */
    .dark .bg-card-dark {
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    }
    
    .dark .bg-white {
      background-color: #1f2937 !important;
    }
    
    .dark .text-gray-800 {
      color: #f3f4f6 !important;
    }
    
    .dark .text-gray-700 {
      color: #e5e7eb !important;
    }
    
    .dark .bg-gray-50 {
      background-color: #374151 !important;
    }
    
    .dark .main-gray-200 {
      border-color: #374151 !important;
    }
    
    .dark .div-row {
      background-color: #1f2937;
    }
    
    .dark input,
    .dark select,
    .dark textarea {
      background-color: #1f2937 !important;
      border-color: #374151 !important;
      color: #fff !important;
    }
    
    .dark input::placeholder {
      color: #6b7280 !important;
    }
    
    /* Input styles matching deposit.html */
    input, select, textarea {
      background-color: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      padding: 0.5rem 0.75rem;
      width: 100%;
      transition: all 0.2s ease;
    }
    
    input:focus, select:focus, textarea:focus {
      outline: none;
      border-color: #FFD700;
      box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.2);
    }
    
    .dark input, .dark select, .dark textarea {
      background-color: #1f2937 !important;
      border-color: #374151 !important;
      color: #fff !important;
    }
    
    .dark input:focus, .dark select:focus, .dark textarea:focus {
      border-color: #FFD700;
      box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.3);
    }
    
    /* Button styles matching deposit.html */
    .btn-primary {
      background: linear-gradient(90deg, #FFD700 0%, #357ABD 100%);
      color: white;
      border-radius: 8px;
      padding: 0.5rem 1rem;
      font-weight: 500;
      transition: all 0.2s ease;
    }
    
    .btn-primary:hover {
      opacity: 0.9;
      transform: translateY(-1px);
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }
    
    .btn-outline {
      border: 1px solid #FFD700;
      color: #FFD700;
      border-radius: 8px;
      padding: 0.5rem 1rem;
      font-weight: 500;
      transition: all 0.2s ease;
    }
    
    .btn-outline:hover {
      background-color: rgba(255, 215, 0, 0.1);
    }
    
    @media (max-width: 1024px) {
      .profile-header h1 {
        font-size: 1.25rem;
      }
      
      .recent-redemptions p {
        font-size: 0.875rem;
      }
      
      .chatbot-button {
        bottom: 16px;
        right: 16px;
      }
    }
    
    @media (max-width: 768px) {
      .grid-cols-1 {
        grid-template-columns: 1fr;
      }
      
      .points-summary {
        order: 2;
      }
      
      .uc-form {
        order: 1;
      }
      
      .main-content {
        padding: 1rem;
      }
      
      .pubg-info-box {
        flex-direction: column;
        align-items: flex-start;
      }
    }
    
    @media (max-width: 480px) {
      .progress-bar {
        width: 100%;
      }
      
      .redemption-history-item {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white">
  
  <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-10 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
    <!-- Logo -->
    <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
      <div class="flex items-center gap-3">
        <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
          <img src="image.png" alt="Logo" class="object-contain" />
        </div>
        <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
      </div>
    </div>
    
    <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>
    <!-- Mobile menu button -->
    <!-- ✅  Global right-top toggle -->
<button
  id="mobileMenuButton"
  class="fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700"
  aria-controls="sidebar"
  aria-expanded="false"
  aria-label="Open menu"
>
  <i class="ri-menu-line text-xl text-primary"></i>
</button>
    
    <!-- Main Content -->
    <main class="main-content flex-1 lg:ml-[280px] transition-all duration-300">
      
      <!-- Replace the entire header section (line 204) with this: -->
<div class="bg-gray-900 p-4 sm:p-6 border-b border-gray-800">
    <div class="flex items-center justify-between">
        <div class="flex items-center">
            <h1 class="text-lg sm:text-xl font-semibold text-gray-100">Redeem PUBG UC</h1>
        </div>
        <div class="flex items-center">
            <!-- Notification icon and dropdown -->
            <div class="relative mr-4">
                <button id="notificationButton" class="w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center cursor-pointer text-gray-300 hover:text-primary">
                    <i class="ri-notification-3-line ri-lg"></i>
                    <span id="notificationCount" class="absolute top-0 right-0 h-4 w-4 sm:h-5 sm:w-5 bg-red-500 rounded-full flex items-center justify-center text-xs text-white">2</span>
                </button>
                <div id="notificationDropdown" class="hidden absolute right-0 mt-2 w-80 bg-gray-800 rounded-lg shadow-lg border border-gray-700 z-50">
                    <div class="p-4 border-b border-gray-700">
                        <h3 class="font-semibold text-white">Notifications</h3>
                    </div>
                    <div id="notificationList" class="max-h-80 overflow-y-auto">
                        <div class="p-4 border-b border-gray-700">
                            <p class="text-gray-300">Your UC redemption is being processed</p>
                            <p class="text-xs text-gray-500 mt-1">1 hour ago</p>
                        </div>
                        <div class="p-4 border-b border-gray-700">
                            <p class="text-gray-300">New UC redemption options available</p>
                            <p class="text-xs text-gray-500 mt-1">3 hours ago</p>
                        </div>
                    </div>
                    <a href="#" class="block p-3 text-center text-sm font-medium text-primary hover:bg-gray-700">View All Notifications</a>
                </div>
            </div>
            
            <!-- Profile dropdown -->
            <?php include '../includes/user-info.php'; ?>
                    <div class="relative">
                        <button type="button" id="profileButton" class="flex items-center">
                           <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white">
                            <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile" class="w-full h-full object-cover">
                            </div>
                        </button>
                        <div id="profileDropdown" class="hidden absolute right-0 mt-2 w-56 bg-gray-800 rounded-md shadow-lg z-50">
                            <div class="p-3 border-b border-gray-700">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white">
                            <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile" class="w-full h-full object-cover">
                            </div>
                                    <div>
                                        <h4 class="font-medium text-white"><?= $username ?></h4>
                                        <p class="text-xs text-gray-400"><?= $_SESSION['email'] ?? 'user@example.com' ?></p>
                                    </div>
                                </div>
                            </div>
                            <a href="/users/profile-update.php" class="px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 block">
                                <i class="ri-user-line mr-2"></i> My Profile
                            </a>
                            <a href="/users/settings.php" class="px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 block">
                                <i class="ri-settings-3-line mr-2"></i> Settings
                            </a>
                            <a href="/users/wallet.php" class="px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 block">
                                <i class="ri-wallet-3-line mr-2"></i> Wallet
                            </a>
                            <div class="border-t border-gray-700"></div>
                            <a href="/logout.php" class="px-4 py-2 text-sm text-red-500 hover:bg-gray-700 block">
                                <i class="ri-logout-box-r-line mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<!-- Add this script at the bottom of the file: -->
<script>
  // Notification and profile dropdown toggle
  const notificationButton = document.getElementById('notificationButton');
  const notificationDropdown = document.getElementById('notificationDropdown');
  const profileButton = document.getElementById('profileButton');
  const profileDropdown = document.getElementById('profileDropdown');

  notificationButton.addEventListener('click', (e) => {
      e.stopPropagation();
      notificationDropdown.classList.toggle('hidden');
      profileDropdown.classList.add('hidden');
  });

  profileButton.addEventListener('click', (e) => {
      e.stopPropagation();
      profileDropdown.classList.toggle('hidden');
      notificationDropdown.classList.add('hidden');
  });

  // Close dropdowns when clicking outside
  document.addEventListener('click', (e) => {
      if (!notificationButton.contains(e.target) && !notificationDropdown.contains(e.target)) {
          notificationDropdown.classList.add('hidden');
      }
      if (!profileButton.contains(e.target) && !profileDropdown.contains(e.target)) {
          profileDropdown.classList.add('hidden');
      }
  });
</script>


      
      <!-- Withdrawal Page Content -->
      <div class="px-4 py-6 sm:px-6 sm:py-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Points Summary Card -->
          <div class="lg:col-span-1">
            <div class="bg-gray-900 rounded-md shadow-sm p-4 sm:p-6 border border-gray-800">
              <h2 class="text-lg font-semibold text-gray-100 mb-6">Points Overview</h2>
              
              <div class="mb-6">
                <p class="text-sm text-gray-400 mb-1">Available Points</p>
                <div class="flex items-end">
                  <h3 class="text-2xl sm:text-3xl font-bold text-gray-100" id="currentPoints">8,450</h3>
                  <span class="text-sm text-gray-400 ml-2 mb-1">Points</span>
                </div>
                <div class="mt-2 text-sm text-primary">
                  Next Reward: 600 UC at 10,000 points
                </div>
              </div>
              
              <div class="space-y-4">
                <div>
                  <div class="flex justify-between mb-1">
                    <p class="text-sm text-gray-400">Progress to Redemption</p>
                    <p class="text-sm font-medium text-gray-300"><span id="earnedPoints">8,450</span>/10,000</p>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-fill" id="pointsProgress" style="width: 84.5%"></div>
                  </div>
                </div>
              </div>
              
              <div class="mt-6 pt-6 border-t border-gray-800">
                <h3 class="text-sm font-semibold text-gray-100 mb-3">Recent Redemptions</h3>
                <div class="space-y-3">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center">
                      <div class="w-8 h-8 flex items-center justify-center bg-green-900 rounded-full text-green-400 mr-3">
                        <i class="ri-gift-line ri-sm"></i>
                      </div>
                      <div>
                        <p class="text-sm font-medium text-gray-100">600 UC</p>
                        <p class="text-xs text-gray-400">Pending Approval</p>
                      </div>
                    </div>
                    <p class="text-sm font-medium text-gray-400">May 15, 2024</p>
                  </div>
                  <div class="flex items-center justify-between">
                    <div class="flex items-center">
                      <div class="w-8 h-8 flex items-center justify-center bg-blue-900 rounded-full text-blue-400 mr-3">
                        <i class="ri-check-line ri-sm"></i>
                      </div>
                      <div>
                        <p class="text-sm font-medium text-gray-100">600 UC</p>
                        <p class="text-xs text-gray-400">Completed: May 1, 2024</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- UC Redemption Form -->
          <div class="lg:col-span-2">
            <div class="bg-gray-900 rounded-md shadow-sm p-4 sm:p-6 border border-gray-800">
              <h2 class="text-lg font-semibold text-gray-100 mb-6">Redeem Your UC</h2>
              <form id="ucWithdrawalForm">
                <!-- Redemption Info -->
                <div class="uc-card p-4 rounded-md mb-6">
                  <div class="flex items-center mb-4">
                    <div class="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center bg-blue-900 rounded-full text-blue-400 mr-3 sm:mr-4">
                      <i class="ri-coins-line ri-lg"></i>
                    </div>
                    <div>
                      <p class="text-sm font-medium text-gray-300">Redemption Rate</p>
                      <p class="text-xl font-bold text-primary">10,000 Points = 600 UC</p>
                    </div>
                  </div>
                </div>
                
                <!-- PUBG Account Details -->
                <div class="mb-6">
                  <label class="block text-sm font-medium text-gray-300 mb-4">PUBG Account Information</label>
                  <div class="space-y-4">
                    <div>
                      <label for="pubgUsername" class="block text-sm text-gray-400 mb-2">Username</label>
                      <input type="text" id="pubgUsername" class="input-field w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-gray-100 placeholder-gray-500" placeholder="Enter PUBG username" required>
                    </div>
                    <div>
                      <label for="pubgUserID" class="block text-sm text-gray-400 mb-2">Player ID</label>
                      <input type="text" id="pubgUserID" class="input-field w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-gray-100 placeholder-gray-500" placeholder="Enter PUBG ID" required>
                    </div>
                  </div>
                </div>
                
                <!-- Terms and Conditions -->
                <div class="flex items-start mb-6">
                  <input type="checkbox" id="ucTerms" name="ucTerms" class="mt-1 mr-2 accent-primary">
                  <label for="ucTerms" class="text-sm text-gray-400">
                    I verify my PUBG account details are correct. UC will be delivered within 48 hours after admin approval.
                    <a href="#" class="text-primary hover:underline">View full policy</a>
                  </label>
                </div>
                
                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row sm:justify-between gap-3">
                  <button type="button" id="cancelBtn" class="px-4 sm:px-6 py-3 border border-gray-600 rounded-button text-gray-300 hover:bg-gray-800 transition-colors">
                    Cancel
                  </button>
                  <button type="submit" id="redeemBtn" class="px-4 sm:px-6 py-3 bg-primary text-gray-900 font-medium rounded-button hover:bg-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors" disabled>
                    Redeem UC (600)
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Footer -->
      <footer class="px-4 sm:px-6 py-6 bg-gray-900 mt-6 border-t border-gray-800">
        <div class="flex flex-col md:flex-row justify-between items-center">
          <div class="mb-4 md:mb-0">
            <p class="text-sm text-gray-500">© MIKIYAS OLANA Rewards Platform. All rights reserved.</p>
          </div>
          <div class="flex space-x-4">
            <a href="#" class="text-sm text-gray-500 hover:text-primary">Terms</a>
            <a href="#" class="text-sm text-gray-500 hover:text-primary">Privacy</a>
            <a href="#" class="text-sm text-gray-500 hover:text-primary">Contact</a>
          </div>
        </div>
      </footer>
    </main>
  </div>
  
  <!-- Chatbot Button -->
  <div class="chatbot-button">
    <div class="w-6 h-6 flex items-center justify-center">
      <i class="ri-message-3-line ri-lg"></i>
    </div>
  </div>
  
  <!-- Success Toast -->
  <div class="success-toast" id="successToast">
    <i class="ri-checkbox-circle-line"></i>
    <span>Redemption request submitted successfully!</span>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const btn = document.getElementById('mobileMenuButton');
      
      // Mobile menu toggle
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
        btn.setAttribute('aria-expanded', isOpen);
      });
      
      // Close menu when clicking outside
      document.addEventListener('click', (e) => {
        if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
          sidebar.classList.add('-translate-x-full');
          btn.setAttribute('aria-expanded', false);
        }
      });
      
      // Dark mode toggle
      const darkModeToggle = document.getElementById('darkModeToggle');
      const html = document.documentElement;
      
      // Check for saved user preference or system preference
      const savedMode = localStorage.getItem('darkMode');
      const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      
      if (savedMode === 'true' || (!savedMode && systemPrefersDark)) {
        html.classList.add('dark');
        darkModeToggle.checked = true;
      } else {
        html.classList.remove('dark');
        darkModeToggle.checked = false;
      }
      
      // Toggle dark mode
      darkModeToggle.addEventListener('change', function() {
        if (this.checked) {
          html.classList.add('dark');
          localStorage.setItem('darkMode', 'true');
        } else {
          html.classList.remove('dark');
          localStorage.setItem('darkMode', 'false');
        }
      });
      
      // UC Redemption Logic
      let currentPoints = 10_000;
      const redeemButton = document.getElementById('redeemBtn');
      const pointsElement = document.getElementById('currentPoints');
      const progressBar = document.getElementById('pointsProgress');
      const successToast = document.getElementById('successToast');
      
      function updatePointsDisplay() {
        pointsElement.textContent = currentPoints.toLocaleString();
        document.getElementById('earnedPoints').textContent = currentPoints.toLocaleString();
        const progressPercent = (currentPoints / 10000) * 100;
        progressBar.style.width = `${progressPercent}%`;
        
        if (currentPoints >= 10000) {
          redeemButton.disabled = false;
          redeemButton.textContent = "Redeem UC (600)";
        } else {
          const needed = 10000 - currentPoints;
          redeemButton.disabled = true;
          redeemButton.textContent = `Need ${needed.toLocaleString()} More Points`;
        }
      }
      
      // Form validation
      const form = document.getElementById('ucWithdrawalForm');
      const inputs = form.querySelectorAll('input');
      
      inputs.forEach(input => {
        input.addEventListener('input', function() {
          const allFilled = Array.from(inputs).every(input => input.value.trim() !== '');
          const termsChecked = document.getElementById('ucTerms').checked;
          
          if (allFilled && termsChecked && currentPoints >= 10000) {
            redeemButton.disabled = false;
          } else {
            redeemButton.disabled = true;
          }
        });
      });
      
      document.getElementById('ucTerms').addEventListener('change', function() {
        const allFilled = Array.from(inputs).every(input => input.value.trim() !== '');
        const termsChecked = this.checked;
        
        if (allFilled && termsChecked && currentPoints >= 10000) {
          redeemButton.disabled = false;
        } else {
          redeemButton.disabled = true;
        }
      });
      
      // Form submission
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (currentPoints < 10000) {
          alert('You need 10,000 points to redeem UC!');
          return;
        }
        
        const username = document.getElementById('pubgUsername').value.trim();
        const userId = document.getElementById('pubgUserID').value.trim();
        
        if (!username || !userId) {
          alert('Please fill in all PUBG account details');
          return;
        }
        
        if (!document.getElementById('ucTerms').checked) {
          alert('Please agree to the terms and conditions');
          return;
        }
        
        // Simulate API call
        redeemButton.disabled = true;
        redeemButton.textContent = "Processing...";
        
        setTimeout(() => {
          currentPoints -= 10000;
          updatePointsDisplay();
          
          // Show success toast
          successToast.classList.add('show');
          setTimeout(() => {
            successToast.classList.remove('show');
          }, 3000);
          
          // Reset form
          form.reset();
          redeemButton.disabled = true;
          
          // Update button text after a delay to show it's ready again
          setTimeout(() => {
            if (currentPoints >= 10000) {
              redeemButton.disabled = false;
              redeemButton.textContent = "Redeem UC (600)";
            }
          }, 1000);
        }, 1500);
      });
      
      // Cancel button
      document.getElementById('cancelBtn').addEventListener('click', function() {
        form.reset();
        document.getElementById('ucTerms').checked = false;
        redeemButton.disabled = true;
      });
      
      // Initial setup
      updatePointsDisplay();
    });
  </script>
  <script>
/* -------------  GLOBAL PER-USER REDEMPTION FLOW  ------------- */
const UID = localStorage.getItem('uid') || 1;   // unique user id

function getBalance(uid = UID) {
  const all = JSON.parse(localStorage.getItem('balances') || '{}');
  return all[uid] || 0;
}
function setBalance(uid, val) {
  const all = JSON.parse(localStorage.getItem('balances') || '{}');
  all[uid] = val;
  localStorage.setItem('balances', JSON.stringify(all));
}
function getRedemptions() {
  return JSON.parse(localStorage.getItem('redemptions') || '[]');
}
function pushRedemption(r) {
  const all = getRedemptions();
  all.unshift(r);
  localStorage.setItem('redemptions', JSON.stringify(all));
}

/* -------------  INITIALISE ------------- */
let USER = { name:'Michael Anderson', email:'mike@example.com' };
USER.points = getBalance();

document.getElementById('currentPoints').textContent = USER.points.toLocaleString();
updateRedeemBtn();

/* -------------  FORM SUBMIT ------------- */
document.getElementById('ucWithdrawalForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if (!document.getElementById('ucTerms').checked) return alert('Accept terms first.');
  if (USER.points < 10000) return alert('Not enough points.');

  // 1. deduct 10 000
  setBalance(UID, USER.points - 10000);
  USER.points -= 10000;

  // 2. create request
  pushRedemption({
    id: 'req_' + Date.now(),
    uid: UID,
    user: USER,
    pubgUsername: document.getElementById('pubgUsername').value.trim(),
    pubgId: document.getElementById('pubgUserID').value.trim(),
    pointsUsed: 10000,
    date: new Date().toISOString(),
    status: 'Pending',
    notes: ''
  });

  // 3. update UI
  document.getElementById('currentPoints').textContent = USER.points.toLocaleString();
  updateRedeemBtn();
  document.getElementById('ucWithdrawalForm').reset();
  showToast('✅ Request sent!');
});

function updateRedeemBtn() {
  const btn = document.getElementById('redeemBtn');
  const needed = 10000 - USER.points;
  btn.disabled = needed > 0;
  btn.textContent = needed > 0 ? `Need ${needed.toLocaleString()} more points` : 'Redeem UC (600)';
}
function showToast(msg) {
  const toast = document.getElementById('successToast');
  toast.querySelector('span').textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 4000);
}
</script>
<script>
/* ------------  PHP API HELPERS ------------ */
const UID = localStorage.getItem('uid') || 1;

async function api(action, payload = {}) {
  payload.action = action;
  payload.uid    = UID;
  const res = await fetch('../user/api/redeem.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(payload)
  });
  return res.json();
}

async function getBalance() {
  const {balance} = await api('getBalance');
  return balance;
}
async function setBalance(val) {
  await api('setBalance', {amount:val});
}
async function pushRedemption(obj) {
  await api('addRedemption', obj);
}

/* ------------  initialise ------------ */
(async () => {
  let currentPoints = await getBalance();
  document.getElementById('currentPoints').textContent = currentPoints.toLocaleString();
  updateRedeemBtn(currentPoints);

  document.getElementById('ucWithdrawalForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!document.getElementById('ucTerms').checked || currentPoints < 10000) return alert('Check form');

    await setBalance(currentPoints - 10000);
    await pushRedemption({
      user        : {name:'Michael Anderson', email:'mike@example.com'}, // replace with real user
      pubgUsername: document.getElementById('pubgUsername').value.trim(),
      pubgId      : document.getElementById('pubgUserID').value.trim()
    });

    currentPoints -= 10000;
    document.getElementById('currentPoints').textContent = currentPoints.toLocaleString();
    updateRedeemBtn(currentPoints);
    document.getElementById('ucWithdrawalForm').reset();
    showToast('✅ Request sent!');
  });

  function updateRedeemBtn(val) {
    const btn = document.getElementById('redeemBtn');
    const needed = 10000 - val;
    btn.disabled = needed > 0;
    btn.textContent = needed > 0 ? `Need ${needed.toLocaleString()} more points` : 'Redeem UC (600)';
  }
})();
</script>
<!-- Add this script inside Redeem PUBG UC.html -->
<script>
// User submits redemption request
document.getElementById('ucWithdrawalForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  // Create request object
  const request = {
    id: Date.now(),
    userId: localStorage.getItem('userId') || 1,
    pubgUsername: document.getElementById('pubgUsername').value,
    pubgId: document.getElementById('pubgUserID').value,
    points: 10000,
    date: new Date().toISOString(),
    status: 'pending'
  };

  // Save to localStorage
  const requests = JSON.parse(localStorage.getItem('redemptionRequests') || [];
  requests.push(request);
  localStorage.setItem('redemptionRequests', JSON.stringify(requests));
  
  // Show success message
  showToast('✅ Redemption request submitted! Admin will review it soon.');
});
</script>
</body>
</html>