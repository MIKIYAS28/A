<?php
header('Content-Type: application/json');
if (session_status() === PHP_SESSION_NONE) { session_start(); }
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
require_once __DIR__ . '/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

$userId = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!$data || !isset($data['method']) || !isset($data['details'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}

try {
    // Begin transaction
    $pdo->beginTransaction();
    
    // Check user points
    $stmt = $pdo->prepare("SELECT points FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || $user['points'] < 10000) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'Insufficient points']);
        exit;
    }
    
    // Deduct points
    $updateStmt = $pdo->prepare("UPDATE users SET points = points - 10000 WHERE id = ?");
    $updateStmt->execute([$userId]);
    
    // Create withdrawal request
    $insertStmt = $pdo->prepare("
        INSERT INTO withdrawal_requests 
        (user_id, amount, currency, method, bank_name, account_number, phone_number, account_name, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    
    $insertStmt->execute([
        $userId,
        1000, // 10,000 points = 1,000 ETB
        'ETB',
        $data['method'],
        $data['details']['bankName'] ?? null,
        $data['details']['accountNumber'] ?? null,
        $data['details']['phoneNumber'] ?? null,
        $data['details']['accountHolderName'] ?? null
    ]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'new_points' => $user['points'] - 10000
    ]);
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>