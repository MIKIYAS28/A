<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
    
    $requestId = $data['id'];
    $newStatus = $data['status'];
    
    try {
        // Update withdrawal status
        $stmt = $pdo->prepare("UPDATE withdrawal_requests SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $requestId]);
        
        // If approved, deduct from user balance
        if ($newStatus === 'completed') {
            // Get request amount and user_id
            $stmt = $pdo->prepare("SELECT user_id, amount FROM withdrawal_requests WHERE id = ?");
            $stmt->execute([$requestId]);
            $requestData = $stmt->fetch();
            
            if ($requestData) {
                $userId = $requestData['user_id'];
                $amount = $requestData['amount'];
                
                // Deduct the amount from user's balance
                $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $stmt->execute([$amount, $userId]);
            }
        }
        
        echo json_encode(['success' => true, 'message' => 'Status updated']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>