<?php
require_once __DIR__ . '/includes/user-data.php';
requireLogin('../auth/login.php');
$csrfMeta = htmlspecialchars($csrfToken ?? ($_SESSION['csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8');
?>
<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("Location: login.html");
    exit();
}
?>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= $csrfMeta ?>">
    <title>UC FORGE</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <!-- Font imports -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon library -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    
    <!-- External CSS -->
    <link href="assets/css/dashboard.css" rel="stylesheet">
    
    <script>
        // Tailwind configuration
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#357ABD'
                    },
                    borderRadius: {
                        'none': '0px',
                        'sm': '4px',
                        DEFAULT: '8px',
                        'md': '12px',
                        'lg': '16px',
                        'xl': '20px',
                        '2xl': '24px',
                        '3xl': '32px',
                        'full': '9999px',
                        'button': '8px'
                    }
                }
            }
        };
    </script>
    
</head>
<script>
window.history.forward();
function noForward() { window.history.forward(); }
</script>
<body onload="noForward();" onpageshow="if (event.persisted) noForward();">

<body class="min-h-screen bg-white text-gray-900 dark:bg-gray-900 dark:text-white transition-colors duration-300" data-auth-required="true">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 h-screen bg-white dark:bg-gray-900 fixed left-0 top-0 shadow-md flex flex-col z-50 border-r border-gray-200 dark:border-gray-800 transform -translate-x-full md:translate-x-0 transition-transform duration-300" aria-label="Main sidebar">
        <!-- Logo -->
        <div class="px-6 py-6 border-b border-gray-200 dark:border-gray-800">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 flex items-center justify-center bg-primary bg-opacity-10 rounded-full p-2">
                    <img src="image.png" alt="Logo" class="object-contain" />
                </div>
                <h1 class="font-['Pacifico'] text-2xl text-primary">UC FORGE</h1>
            </div>
        </div>
        <!-- Navigation Menu -->
        <nav class="flex-1 overflow-y-auto py-4">
            <ul>
                <li>
                    <a href="Dashboard.php" class="sidebar-item active flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-dashboard-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Daily Task.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-task-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Daily Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="Deposit.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-money-dollar-box-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="Transfer to Account.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-dollar-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Transfer to Account</span>
                    </a>
                </li>
                <li>
                    <a href="All Transactions.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-exchange-funds-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">All Transactions</span>
                    </a>
                </li>
                <li>
                    <a href="Withdrawal .php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-bank-card-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="Withdraw History.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-time-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                        <span class="text-primary font-bold">Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="Redeem PUBG UC.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                        <i class="ri-gift-line w-6 mr-3 text-primary icon-shadow"></i>
                        <span class="text-primary font-bold">Redeem UC</span>
                    </a>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Videos</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="All video List.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-video-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">All Videos List</span>
                            </a>
                        </li>
                        <li>
                            <a href="View Earning.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-money-dollar-circle-line ri-lg text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">View Earnings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pt-2">
                    <div class="text-xs font-medium text-gray-500 dark:text-gray-400 px-3 uppercase">Settings</div>
                    <ul class="mt-2 space-y-1">
                        <li>
                            <a href="Profile setting.php" class="sidebar-item flex items-center px-6 py-3 text-gray-700 dark:text-gray-300 font-medium">
                                <i class="ri-user-settings-line text-primary icon-shadow w-6 h-6 mr-3"></i>
                                <span class="text-primary font-bold">Profile Settings</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- Bottom Section -->
       <div class="mt-auto p-6">
            <div class="bg-gray-50 dark:bg-gray-800 p-4 rounded-xl text-gray-800 dark:text-white mb-4">
                <div class="flex items-center justify-between mb-4">
                    <span class="text-sm font-medium text-gray-600 dark:text-gray-300">Dark Mode</span>
                    <label class="custom-switch relative inline-block w-12 h-6" for="darkModeToggle">
                        <input type="checkbox" id="darkModeToggle" class="sr-only" aria-label="Toggle dark mode">
                        <span class="slider block w-12 h-6 rounded-full bg-gray-300 transition duration-300"></span>
                    </label>
                </div>
            </div>
            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
<div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile Picture" class="...">

            </div>
            <div>
                <span><?php echo htmlspecialchars($username); ?></span>

            </div>
        </div>
    </div>
</aside>





    <!-- Mobile menu button -->
    <button type="button" id="mobileMenuButton" class="md:hidden fixed top-4 right-4 z-50 bg-white dark:bg-gray-800 p-2 rounded-md shadow-md border border-gray-200 dark:border-gray-700" aria-controls="sidebar" aria-expanded="false" aria-label="Open menu">
  <i class="ri-menu-line text-xl text-primary"></i>
</button>
    
    <!-- Main Content -->
    <main class="flex-1 ml-0 md:ml-72 p-4 md:p-8 transition-all duration-300">
       
        <!-- Header with Profile -->
       <!-- Updated header section -->
<!-- Replace the existing header section (line 248) with this: -->
<div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
    <div class="flex items-center mb-4 md:mb-0">
        <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white overflow-hidden mr-3 md:mr-4 border-2 border-white">
            <img id="headerProfilePic" src="" alt="Profile" class="w-full h-full object-cover">
        </div>
        <div>
            <h1 class="text-2xl font-bold" id="welcomeMessage">Welcome, Loading... 👋</h1>
            <p class="text-sm opacity-80">Member since <span id="memberSince">Loading...</span></p>
        </div>
    </div>
    
    <!-- Add Notification Icon Here -->
  <div class="flex items-center justify-between w-full">
        <div class="relative ml-auto mr-2">
    <button type="button" id="notificationButton" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300" aria-label="View notifications">
        <i class="ri-notification-3-line text-xl" style="font-weight: bold; color: #eab308; filter: drop-shadow(0 0 6px #facc15);"></i>
        <span id="notificationCount" class="absolute top-0 right-0 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center hidden"></span>
    </button>
    <div id="notificationDropdown" class="hidden absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50">
        <div class="p-4 border-b border-gray-200 dark:border-gray-700">
<h3 class="font-semibold" style="font-weight: bold; color: #eab308; filter: drop-shadow(0 0 6px #facc15);">Notifications</h3>
        </div>
        <div id="notificationList" class="max-h-80 overflow-y-auto">
            <!-- Items will be loaded by JS -->
        </div>
        <a href="#" class="block p-3 text-center text-sm font-medium text-primary hover:bg-gray-50 dark:hover:bg-gray-700">View All Notifications</a>
    </div>
</div>

        
            <div class="flex flex-col md:flex-row gap-2 w-full md:w-auto">
            <a href="Profile setting.php" class="px-4 py-2 bg-primary text-white text-sm md:text-base rounded-button hover:bg-opacity-90 transition-all">
                <i class="ri-edit-line mr-2"></i> Edit Profile
            </a>
            <button type="button" class="px-4 py-2 bg-white text-primary text-sm md:text-base rounded-button hover:bg-opacity-90 transition-all">
                <i class="ri-share-line mr-2"></i> Share & Refer
            </button>
        </div>
    </div>
</div>

<!-- Add this script at the bottom of the file: -->
<script>
  // Notification dropdown toggle
  const notificationButton = document.getElementById('notificationButton');
  const notificationDropdown = document.getElementById('notificationDropdown');

  notificationButton.addEventListener('click', (e) => {
      e.stopPropagation();
      notificationDropdown.classList.toggle('hidden');
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
      if (!notificationButton.contains(e.target) && !notificationDropdown.contains(e.target)) {
          notificationDropdown.classList.add('hidden');
      }
  });
</script>
<script>
function fetchNotifications() {
    fetch('api/get-notifications.php', { credentials: 'include' })
        .then(res => res.json())
        .then(data => {
            const notifCount = document.getElementById('notificationCount');
            const notifList = document.getElementById('notificationList');

            // Update badge count
            if (data.unreadCount > 0) {
                notifCount.textContent = data.unreadCount;
                notifCount.classList.remove('hidden');
            } else {
                notifCount.classList.add('hidden');
            }

            // Clear old notifications
            notifList.innerHTML = '';

            // Inject new ones
            data.notifications.forEach(n => {
                const div = document.createElement('div');
                div.className = 'p-4 border-b border-gray-200 dark:border-gray-700';

                const p = document.createElement('p');
                p.className = 'text-gray-700 dark:text-gray-300';
                p.textContent = n.message;

                const time = document.createElement('p');
                time.className = 'text-xs text-gray-500 dark:text-gray-400 mt-1';
                time.textContent = 'Just now'; // Optional: update with real timestamps if you have them

                div.appendChild(p);
                div.appendChild(time);
                div.addEventListener('click', () => {
                    if (n.url) {
                        window.location = n.url;
                    }
                });

                notifList.appendChild(div);
            });
        });
}

// Load every 15 seconds
fetchNotifications();
setInterval(fetchNotifications, 15000);
</script>


        <!-- Stats Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Main Balance -->
             <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium"></h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-yellow-100 text-yellow-600">
                            <i class="ri-wallet-3-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Br</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-green-500 flex items-center">
                        <i class="ri-arrow-up-line mr-1"></i>
                        <span>0 last week</span>
                    </div>
                </div>
            </div>
            
            <!-- Total Referral Bonus -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Referral Bonus</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-purple-100 text-purple-600">
                            <i class="ri-user-add-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Br</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-green-500 flex items-center">
                        <i class="ri-arrow-up-line mr-1"></i>
                        <span>0 new referrals</span>
                    </div>
                </div>
            </div>
            
            <!-- Total Deposit -->
           <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Total Deposit</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-green-100 text-green-600">
                            <i class="ri-arrow-down-circle-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Br</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-gray-500 flex items-center">
                        <span>Last deposit:</span>
                    </div>
                </div>
            </div>
            
            <!-- Total Withdraw -->
           <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Total Withdraw</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-amber-100 text-amber-600">
                            <i class="ri-arrow-up-circle-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Point</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-gray-500 flex items-center">
                        <span>Last withdraw:</span>
                    </div>
                </div>
            </div>
            
            <!-- Current Credit -->
          <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Current Credit</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-pink-100 text-pink-600">
                            <i class="ri-coupon-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Credits</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-blue-500 flex items-center">
                        <i class="ri-information-line mr-1"></i>
                        <span>Use for premium videos</span>
                    </div>
                </div>
            </div>
            
            <!-- Total Videos Viewed -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Videos Viewed</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-indigo-100 text-indigo-600">
                            <i class="ri-movie-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Videos</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-gray-500 flex items-center">
                        <span>Total earnings: 0 Br</span>
                    </div>
                </div>
            </div>
            
            <!-- Today's Views -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Today's Views</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-teal-100 text-teal-600">
                            <i class="ri-calendar-check-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Videos</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-green-500 flex items-center">
                        <i class="ri-arrow-up-line mr-1"></i>
                        <span>+3 from yesterday</span>
                    </div>
                </div>
            </div>
            
            <!-- Remaining Videos -->
            <div class="stat-card bg-white dark:bg-gray-800 p-5 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300">
                <div class="stat-card-content">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-gray-500 dark:text-gray-400 font-medium">Remaining Videos</h3>
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-orange-100 text-orange-600">
                            <i class="ri-time-line"></i>
                        </div>
                    </div>
                    <div class="flex items-end">
                        <span class="text-2xl font-bold text-gray-800 dark:text-gray-100">0</span>
                        <span class="ml-1 text-lg font-medium text-gray-600">Videos</span>
                    </div>
                    <div class="mt-1">
                        <span class="text-xs text-primary font-semibold">
                            Points: 0
                        </span>
                    </div>
                    <div class="stat-card-footer text-sm text-blue-500 flex items-center">
                        <i class="ri-play-circle-line mr-1"></i>
                        <span>Watch now to earn</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Gamification and Activity Section -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <!-- Level Progress -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="mb-4">
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-500 dark:text-gray-400">Progress to Level 8</span>
                        <span class="text-gray-800 dark:text-gray-100 font-medium">65%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-bar-fill" style="width: 65%"></div>
                    </div>
                </div>
                <div class="flex items-center justify-between text-sm text-gray-500 mb-5">
                    <span>350 XP earned</span>
                    <span>540 XP needed</span>
                </div>
                <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                    <h4 class="font-medium text-gray-700 dark:text-gray-300 mb-3">Achievements</h4>
                    <div class="flex flex-wrap gap-2">
                        <div class="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center" title="5-Day Streak">
                            <i class="ri-fire-line text-yellow-600"></i>
                        </div>
                        <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center" title="10 Referrals">
                            <i class="ri-user-add-line text-green-600"></i>
                        </div>
                        <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center" title="100 Videos Watched">
                            <i class="ri-video-line text-purple-600"></i>
                        </div>
                        <div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center" title="Locked Achievement">
                            <i class="ri-lock-line text-gray-500"></i>
                        </div>
                        <div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center" title="Locked Achievement">
                            <i class="ri-lock-line text-gray-500"></i>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Referral Leadeboard -->
             <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300">Referral Leaderboard</h3>
                    <span class="text-xs text-gray-500">This Month</span>
                </div>
                <ul class="space-y-3">
                    <li class="flex items-center p-2 bg-primary bg-opacity-10 rounded">
                        <div class="w-8 h-8 flex items-center justify-center bg-amber-100 rounded-full text-amber-600 font-bold mr-3">1</div>
                        <div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden">
                            <img src="https://readdy.ai/api/search-image?query=professional%20headshot%20of%20a%20young%20woman%20with%20long%20dark%20hair,%20business%20casual%20attire,%20neutral%20expression,%20high%20quality%20portrait&width=100&height=100&seq=2&orientation=squarish&removebg=false&flag=1f2487a4a3bba3945c0b58dee8808858" alt="User" class="w-full h-full object-cover">
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Sophia Williams</div>
                            <div class="text-xs text-gray-500">32 referrals</div>
                        </div>
                        <div class="ml-auto text-amber-400 font-medium">1,600 Br</div>
                    </li>
                    <li class="flex items-center p-2 rounded">
                        <div class="w-8 h-8 flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded-full text-gray-700 dark:text-gray-300 font-bold mr-3">2</div>
                        <div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden">
                            <img src="https://readdy.ai/api/search-image?query=professional%20headshot%20of%20a%20middle-aged%20man%20with%20glasses,%20business%20casual%20attire,%20neutral%20expression,%20high%20quality%20portrait&width=100&height=100&seq=3&orientation=squarish&removebg=false&flag=b521811ab02cee4f7cf420ae94d2df01" alt="User" class="w-full h-full object-cover">
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">James Johnson</div>
                            <div class="text-xs text-gray-500">28 referrals</div>
                        </div>
                        <div class="ml-auto text-gray-500 dark:text-gray-400 font-medium">1,400 Br</div>
                    </li>
                    <li class="flex items-center p-2 rounded">
                        <div class="w-8 h-8 flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded-full text-gray-700 dark:text-gray-300 font-bold mr-3">3</div>
                        <div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden">
                            <img src="https://readdy.ai/api/search-image?query=professional%20headshot%20of%20a%20young%20woman%20with%20blonde%20hair,%20business%20casual%20attire,%20neutral%20expression,%20high%20quality%20portrait&width=100&height=100&seq=4&orientation=squarish&removebg=false&flag=305f67603db488cac6ddbb3c846b48ac" alt="User" class="w-full h-full object-cover">
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Emma Thompson</div>
                            <div class="text-xs text-gray-500">25 referrals</div>
                        </div>
                        <div class="ml-auto text-gray-500 dark:text-gray-400 font-medium">1,250 Br</div>
                    </li>
                    <li class="flex items-center p-2 bg-blue-100 dark:bg-blue-900 dark:bg-opacity-20 rounded">
                        <div class="w-8 h-8 flex items-center justify-center bg-blue-100 rounded-full text-blue-600 font-bold mr-3">7</div>
                        <div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-3 overflow-hidden">
                            <img src="https://readdy.ai/api/search-image?query=professional%20headshot%20of%20a%20young%20man%20with%20short%20brown%20hair,%20business%20casual%20attire,%20neutral%20expression,%20high%20quality%20portrait&width=100&height=100&seq=1&orientation=squarish&removebg=false" alt="User" class="w-full h-full object-cover">
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-700 dark:text-gray-300">You</div>
                            <div class="text-xs text-gray-500">15 referrals</div>
                        </div>
                        <div class="ml-auto text-blue-500 dark:text-blue-400 font-medium">750 point</div>
                    </li>
                </ul>
                <button class="mt-4 w-full py-2 border border-primary text-primary rounded-button hover:bg-primary hover:bg-opacity-10 transition-all whitespace-nowrap flex items-center justify-center">
                    <i class="ri-share-line mr-2"></i> Invite More Friends
                </button>
            </div>
        </div>
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300">Daily Tasks</h3>
                    <div class="flex items-center bg-amber-100 px-3 py-1 rounded-full">
                        <i class="ri-fire-line text-amber-600 mr-1"></i>
                        <span class="text-amber-600 text-xs font-medium">8 Day Streak</span>
                    </div>
                </div>
                <ul class="space-y-3">
                    <li class="flex items-center">
                        <label class="flex items-center">
                            <input type="checkbox" class="custom-checkbox mr-3" checked aria-label="Watch 5 videos task">
                            <span class="text-gray-700 dark:text-gray-300">Watch 5 videos</span>
                        </label>
                        <span class="ml-auto text-green-500 text-sm">+50 point</span>
                    </li>
                    <li class="flex items-center">
                        <label class="flex items-center">
                            <input type="checkbox" class="custom-checkbox mr-3" checked aria-label="Refer a friend task">
                            <span class="text-gray-700 dark:text-gray-300">Refer a friend</span>
                        </label>
                        <span class="ml-auto text-green-500 text-sm">+15 point</span>
                    </li>
                    <li class="flex items-center">
                        <label class="flex items-center">
                            <input type="checkbox" class="custom-checkbox mr-3" aria-label="Complete profile task">
                            <span class="text-gray-700 dark:text-gray-300">Complete profile</span>
                        </label>
                        <span class="ml-auto text-green-500 text-sm">+5 point</span>
                    </li>
                    <li class="flex items-center">
                        <label class="flex items-center">
                            <input type="checkbox" class="custom-checkbox mr-3" aria-label="Share on social media task">
                            <span class="text-gray-700 dark:text-gray-300">Share on social media</span>
                        </label>
                        <span class="ml-auto text-green-500 text-sm">+10 point</span>
                    </li>
                    <li class="flex items-center">
                        <label class="flex items-center">
                            <input type="checkbox" class="custom-checkbox mr-3" aria-label="Watch premium video task">
                            <span class="text-gray-700 dark:text-gray-300">Watch premium video</span>
                        </label>
                        <span class="ml-auto text-green-500 text-sm">+30 point</span>
                    </li>
                </ul>
                <button type="button" class="mt-4 w-full py-2 bg-gradient-to-r from-primary to-secondary text-white rounded-button hover:opacity-90 transition-all whitespace-nowrap">
                    Claim 75 point Reward
                </button>
            </div>
            
            <!-- Recent Videos Section -->
<!-- Recent Videos Section -->
   <div class="mt-6 md:mt-8">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-xl text-primary font-bold">Recent Videos</h3>
                <a href="All video List.php" class="text-primary font-medium text-sm flex items-center">
                    View All <i class="ri-arrow-right-line ml-1"></i>
                </a>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                <!-- Video Card 1 -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                    <div class="relative h-40 bg-gray-200 dark:bg-gray-700 video-thumbnail">
                        <img src="https://readdy.ai/api/search-image?query=thumbnail%20for%20a%20tech%20tutorial%20video%20about%20smartphones,%20showing%20hands%20holding%20a%20modern%20smartphone%20with%20app%20interface%20visible,%20high%20quality%20product%20photography%20with%20clean% background,%20professional%20lighting&width=400&height=225&seq=5&orientation=landscape&removebg=false&flag=032ffa541e6f1237b38e889d2e83f917" alt="Video Thumbnail" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center play-overlay">
                            <div class="w-12 h-12 flex items-center justify-center bg-white bg-opacity-80 rounded-full">
                                <i class="ri-play-fill text-primary text-2xl"></i>
                            </div>
                        </div>
                        <div class="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                            05:23
                        </div>
                    </div>
                    <div class="p-4">
                        <h4 class="font-medium text-gray-800 dark:text-gray-300 mb-1">Latest Smartphone Review 2025</h4>
                        <div class="flex items-center text-sm text-gray-500 mb-2">
                            <i class="ri-money-dollar-circle-line mr-1"></i>
                            <span>Earn 5 point</span>
                        </div>
                                                   
                        <button  class="w-full py-2 bg-gradient-to-r from-primary to-secondary text-white rounded-button hover:opacity-90 transition-all whitespace-nowrap text-sm">
                            <a href="All video List.php">
                            Watch Now
                            </a>
                        </button>
                        </a>
                    </div>
                </div>
                
                <!-- Video Card 2 -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                    <div class="relative h-40 bg-gray-200 dark:bg-gray-700 video-thumbnail">
                        <img src="https://readdy.ai/api/search-image?query=thumbnail%20for%20a%20cooking%20tutorial%20video%20showing%20a%20professional%20chef%20preparing%20a%20gourmet%20meal%20in%20a%20modern%20kitchen,%20high%20quality%20food%20photography%20with%20soft%20lighting&width=400&height=225&seq=6&orientation=landscape&removebg=false&flag=7789d836acb8fce88a32ac2c53764c11" alt="Video Thumbnail" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center play-overlay">
                            <div class="w-12 h-12 flex items-center justify-center bg-white bg-opacity-80 rounded-full">
                                <i class="ri-play-fill text-primary text-2xl"></i>
                            </div>
                        </div>
                        <div class="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                            08:47
                        </div>
                    </div>
                    <div class="p-4">
                        <h4 class="font-medium text-gray-800 dark:text-gray-300 mb-1">Gourmet Cooking Masterclass</h4>
                        <div class="flex items-center text-sm text-gray-500 mb-2">
                            <i class="ri-money-dollar-circle-line mr-1"></i>
                            <span>Earn 7 point</span>
                        </div>
                        <button class="w-full py-2 bg-gradient-to-r from-primary to-secondary text-white rounded-button hover:opacity-90 transition-all whitespace-nowrap text-sm">
                           <a href="All video List.php">
                            Watch Now
                            </a>
                        </button>
                    </div>
                </div>
                
                <!-- Video Card 3 -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                    <div class="relative h-40 bg-gray-200 dark:bg-gray-700 video-thumbnail">
                        <img src="https://readdy.ai/api/search-image?query=thumbnail%20for%20a%20fitness%20workout%20video%20showing%20a%20fitness%20instructor%20demonstrating%20exercises%20in%20a%20modern%20gym,%20high%20quality%20photography%20with%20dynamic%20composition&width=400&height=225&seq=7&orientation=landscape&removebg=false&flag=e686a73e4360eb233fd89290790f9b18" alt="Video Thumbnail" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center play-overlay">
                            <div class="w-12 h-12 flex items-center justify-center bg-white bg-opacity-80 rounded-full">
                                <i class="ri-play-fill text-primary text-2xl"></i>
                            </div>
                        </div>
                        <div class="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                            12:05
                        </div>
                    </div>
                    <div class="p-4">
                        <div class="flex items-center justify-between">
                            <h4 class="font-medium text-gray-800 dark:text-gray-300 mb-1">30-Min Full Body Workout</h4>
                        </div>
                        <div class="flex items-center text-sm text-gray-500 mb-2">
                            <i class="ri-money-dollar-circle-line mr-1"></i>
                            <span>Earn 10 point</span>
                        </div>
                        <button class="w-full py-2 bg-gradient-to-r from-primary to-secondary text-white rounded-button hover:opacity-90 transition-all whitespace-nowrap text-sm">
                           <a href="All video List.php">
                            Watch Now
                            </a>
                        </button>
                    </div>
                </div>
                
                <!-- Video Card 4 -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                    <div class="relative h-40 bg-gray-200 dark:bg-gray-700 video-thumbnail">
                        <img src="https://readdy.ai/api/search-image?query=thumbnail%20for%20a%20travel%20vlog%20video%20showing%20beautiful%20landscape%20of%20tropical%20beach%20destination%20with%20palm%20trees%20and%20crystal%20clear%20water,%20high%20quality%20travel%20photography%20with%20vibrant%20colors&width=400&height=225&seq=8&orientation=landscape&removebg=false&flag=dd9c583529371deb0d7fde437732f3f0" alt="Video Thumbnail" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center play-overlay">
                            <div class="w-12 h-12 flex items-center justify-center bg-white bg-opacity-80 rounded-full">
                                <i class="ri-play-fill text-primary text-2xl"></i>
                            </div>
                        </div>
                        <div class="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded-full">
                            PREMIUM
                        </div>
                        <div class="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                            15:32
                        </div>
                    </div>
                    <div class="p-4">
                        <h4 class="font-medium text-gray-800 dark:text-gray-300 mb-1">Bali Travel Guide 2025</h4>
                        <div class="flex items-center text-sm text-gray-500 mb-2">
                            <i class="ri-money-dollar-circle-line mr-1"></i>
                            <span>Earn 15 point</span>
                        </div>
                        <button class="w-full py-2 border border-primary text-primary rounded-button hover:bg-primary hover:bg-opacity-10 transition-all whitespace-nowrap text-sm flex items-center justify-center">
                            <i class="ri-lock-line mr-1"></i> Unlock with 5 Credits
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="px-4 py-6 sm:px-6 sm:py-8 bg-white dark:bg-gray-900 mt-6 border-t border-gray-200 dark:border-gray-800">
                <div class="flex flex-col sm:flex-row justify-between items-center">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-xs sm:text-sm text-gray-600 dark:text-gray-400">© MIKIYAS OLANA Rewards Platform. All rights reserved.</p>
                    </div>
                    </div>
</footer>
    
    <!-- Shared user data loader -->
    <script src="assets/js/user-data.js"></script>
    <script>
      // Mark dashboard as protected so guests are redirected
      document.body.setAttribute('data-auth-required', 'true');
      // Ensure freshest data after tasks on other pages
      window.refreshUserData = () => window.UserData?.refresh();
    </script>

    <!-- Chatbot Button -->
    <div class="chatbot-button">
        <i class="ri-customer-service-2-line text-white text-xl"></i>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('mobileMenuButton');
            
            // Mobile menu toggle
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                // Only toggle on mobile screens
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (isMobile) {
                    const isOpen = sidebar.classList.toggle('-translate-x-full') === false;
                    btn.setAttribute('aria-expanded', isOpen);
                }
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !btn.contains(e.target)) {
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            });
            
            // Handle responsive behavior on resize
            function handleResize() {
                const isMobile = window.innerWidth < 768; // md breakpoint
                if (!isMobile) {
                    // On desktop, ensure sidebar is visible and reset button state
                    sidebar.classList.remove('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                } else {
                    // On mobile, ensure sidebar starts hidden
                    sidebar.classList.add('-translate-x-full');
                    btn.setAttribute('aria-expanded', false);
                }
            }
            
            // Call on load and resize
            handleResize();
            window.addEventListener('resize', handleResize);
            
            // Dark mode toggle
            const darkModeToggle = document.getElementById('darkModeToggle');
            const body = document.body;
            
            // Check for saved user preference
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            darkModeToggle.checked = isDarkMode;
            body.classList.toggle('dark', isDarkMode);
            
            darkModeToggle.addEventListener('change', function() {
                const isDark = this.checked;
                body.classList.toggle('dark', isDark);
                localStorage.setItem('darkMode', isDark);
                
                // Smooth transition for background
                if(isDark) {
                    body.style.backgroundColor = '#111827';
                } else {
                    body.style.backgroundColor = '#ffffff';
                }
            });
        });
        
// Load user data from API (handled by assets/js/user-data.js)
        (async () => {
            try {
                const response = await fetch('../auth/me.php', { credentials: 'include' });
                if (!response.ok) {
                    console.error('Failed to fetch user data');
                    return;
                }
                const data = await response.json();
                
                // Check if user is logged in
                if (data.loggedIn && data.username) {
                    // Update welcome message
                    const welcomeMsg = document.getElementById('welcomeMessage');
                    if (welcomeMsg) {
                        welcomeMsg.textContent = `Welcome, ${data.username} 👋`;
                    }
                    
                    // Update member since date
                    const memberSince = document.getElementById('memberSince');
                    if (memberSince && data.joined_at) {
                        memberSince.textContent = new Date(data.joined_at).toLocaleDateString();
                    }
                    
                    // Create profile picture with user initials
                    const initials = data.username.substring(0, 2).toUpperCase();
                    const profilePic = `data:image/svg+xml;base64,${btoa(`
                        <svg width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">
                        <circle cx=\"20\" cy=\"20\" r=\"20\" fill=\"#FFD700\"/>
                        <text x=\"50%\" y=\"50%\" dominant-baseline=\"middle\" text-anchor=\"middle\" fill=\"#111827\" font-size=\"14\" font-weight=\"bold\" font-family=\"sans-serif\">${initials}</text>
                        </svg>
                    `)}`;
                    
                    // Update profile pictures
                    const sidebarPic = document.getElementById('sidebarProfilePic');
                    const headerPic = document.getElementById('headerProfilePic');
                    if (sidebarPic) sidebarPic.src = profilePic;
                    if (headerPic) headerPic.src = profilePic;
                    
                    // Update sidebar username
                    const sidebarUsername = document.getElementById('sidebarUsername');
                    if (sidebarUsername) {
                        sidebarUsername.textContent = data.username;
                    }
                    
                    // Update points displays
                    const points = data.balance || 0;
                    document.querySelectorAll('.text-2xl.font-bold.text-gray-800').forEach(el => {
                        if (el.parentElement && el.parentElement.innerHTML.includes('Points:')) {
                            el.textContent = points;
                        }
                    });
                    
                    // Store user data globally so other pages can access it
                    window.userData = {
                        username: data.username,
                        points: points,
                        memberSince: new Date(data.joined_at).toLocaleDateString(),
                        loggedIn: true
                    };
                    localStorage.setItem('userData', JSON.stringify(window.userData));
                } else {
                    // User not logged in, show default values
                    console.log('User not logged in');
                }
                
            } catch (error) {
                console.error('Error loading user data:', error);
            }
        })();
        
// User data is initialized by user-data.js
        
        // Country restriction check
        const highCPMCountries = ["US", "CA", "UK", "AU", "DE", "FR", "JP", "KR", "NO", "AE"];
        
        fetch("https://ipapi.co/json/")
            .then(response => response.json())
            .then(data => {
                const userCountry = data.country_code;
                
                if (!highCPMCountries.includes(userCountry)) {
                    // Replace entire body with a fake error page
                    document.body.innerHTML = `
                        <div style="font-family:sans-serif; text-align:center; margin-top:15%;">
                            <div style="font-size:50px; color:#666;">☹</div>
                            <h1 style="color:#333;">This site can't be reached</h1>
                            <p><strong>www.ucforge.com</strong> took too long to respond.</p>
                            <br>
                            <p>Try:</p>
                            <ul style="list-style:disc; display:inline-block; text-align:left; margin: 0 auto;">
                                <li>Checking the connection</li>
                                <li>Checking the proxy and the firewall</li>
                                <li>Running Windows Network Diagnostics</li>
                            </ul>
                        </div>
                    `;
                    document.title = "This site can't be reached";
                }
            });
    </script>

</body>
        </body>
</html>