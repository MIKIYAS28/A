<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$userId = $_SESSION['user_id'];
$coins = (int)($data['coins'] ?? 0);
$type = $data['type'] ?? '';

if ($coins <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid coin amount']);
    exit;
}

try {
    // Update points
    $stmt = $pdo->prepare("UPDATE users SET points = points + :points WHERE id = :id");
    $stmt->execute([':points' => $coins, ':id' => $userId]);
    
    // Record transaction
    $stmt = $pdo->prepare("INSERT INTO point_transactions (user_id, amount, type) VALUES (:user_id, :amount, :type)");
    $stmt->execute([':user_id' => $userId, ':amount' => $coins, ':type' => $type]);

    echo json_encode(['success' => true, 'new_balance' => $coins]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}