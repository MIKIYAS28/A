<?php
// Set JSON content type header
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Turn off error display for clean JSON
ini_set('display_errors', 0);
error_reporting(0);

session_start();

// Default guest response
$guestResponse = [
    'loggedIn' => false,
    'id' => null,
    'username' => 'Guest',
    'email' => null,
    'role' => 'guest',
    'balance' => 0,
    'points' => 0,
    'joined_at' => null,
    'avatar' => '/assets/img/default-avatar.png'
];

// Check if user is logged in
if (!isset($_SESSION['uid']) || !$_SESSION['uid']) {
    echo json_encode($guestResponse);
    exit;
}

try {
    require __DIR__ . '/../../config.php';
    
    $stmt = $pdo->prepare("SELECT id, username, email, role, balance, joined_at, profile_pic 
                           FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        // Session exists but user not found - clear session and return guest
        session_destroy();
        echo json_encode($guestResponse);
        exit;
    }
    
    // Format the joined date
    $joinedDate = new DateTime($user['joined_at']);
    $memberSince = $joinedDate->format('M j, Y');
    
    // Set default profile picture if none exists
    $profilePic = $user['profile_pic'] ?: '/assets/img/default-avatar.png';
    
    // Return consistent structure
    echo json_encode([
        'loggedIn' => true,
        'id' => (int)$user['id'],
        'username' => $user['username'],
        'email' => $user['email'],
        'role' => $user['role'] ?? 'user',
        'balance' => (float)($user['balance'] ?? 0),
        'points' => (int)($user['balance'] ?? 0),
        'joined_at' => $user['joined_at'],
        'avatar' => $profilePic
    ]);
    exit;
    
} catch (Exception $e) {
    // Return guest response on error
    echo json_encode($guestResponse);
    exit;
}
?>
