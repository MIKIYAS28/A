CREATE DATABASE IF NOT EXISTS rewarding CHARACTER SET utf8mb4;
USE rewarding;

CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  UNIQUE NOT NULL,
  email         VARCHAR(100) UNIQUE NOT NULL,
  password_hash CHAR(255)    NOT NULL,
  role          ENUM('viewer','content-creator','moderator','admin')
                DEFAULT 'viewer',
  balance       INT DEFAULT 0,
  email_verified TINYINT(1) DEFAULT 0,
  joined_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_username (username)
);
CREATE TABLE videos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  category VARCHAR(50),
  verificationCode VARCHAR(20) NOT NULL,
  points INT DEFAULT 100,
  youtubeId VARCHAR(20) NOT NULL,
  views INT DEFAULT 0
);
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    status ENUM('unread', 'read') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);