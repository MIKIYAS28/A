<?php
require __DIR__ . "/../config.php";
session_start();
if (empty($_SESSION['uid'])) { 
    http_response_code(401); 
    exit('{"error":"login"}'); 
}

$uid = (int) $_SESSION['uid'];
$taskId = (int) $_POST['taskId'] ?? 0;
$taskType = $_POST['type'] ?? '';
$coins = (int) $_POST['coins'] ?? 0;

// Validate input
if (!$taskId || !$taskType || $coins <= 0) {
    http_response_code(400);
    exit('{"error":"invalid_input"}');
}

try {
    $pdo->beginTransaction();
    
    // Record transaction
    $pdo->prepare("INSERT INTO transactions (user_id, type, amount) VALUES (?, ?, ?)")
         ->execute([$uid, $taskType.'_credit', $coins]);
    
    // Record task completion
    $pdo->prepare("INSERT INTO task_completions (user_id, task_id) VALUES (?, ?)")
         ->execute([$uid, $taskId]);
    
    // Update user's coin balance
    $pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?")
         ->execute([$coins, $uid]);
    
    $pdo->commit();
    echo json_encode(['ok' => true, 'coins' => $coins]);
} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    error_log($e->getMessage());
    echo json_encode(['ok' => false, 'error' => 'database_error']);
}