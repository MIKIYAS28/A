/* api/user/referral-track.php */
require __DIR__ . "/../config.php";
session_start();

// 1. /referral-track.php?code=ABC123   (landing page)
$code = $_GET['code'] ?? '';
if ($code) {
    setcookie('ref', $code, 0, '/');          // remember code
    header('Location: /user/login.html');     // go register
    exit;
}

// 2. /referral-track.php (POST after register)
$uid = (int) $_SESSION['uid'];
$code = $_COOKIE['ref'] ?? '';

if ($code) {
    $stmt = $pdo->prepare("SELECT * FROM referrals WHERE code=? AND new_user_id IS NULL");
    $stmt->execute([$code]);
    $row = $stmt->fetch();
    if ($row && !$row['claimed']) {
        // assign new user to sharer
        $pdo->prepare("UPDATE referrals SET new_user_id=? WHERE code=?")->execute([$uid,$code]);
        // pay sharer
        $pdo->prepare("INSERT INTO transactions (user_id,type,amount) VALUES (?,'referral_bonus',15)")
            ->execute([$row['sharer_id']]);
    }
    setcookie('ref', '', -1, '/');  // clear cookie
}