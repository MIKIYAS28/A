<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../config.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit;
}

try {
    // Get all tasks from the database
    $stmt = $pdo->prepare("
        SELECT 
            id,
            type,
            title,
            description,
            url,
            reward,
            target_count,
            enabled,
            created_at,
            DATE_FORMAT(created_at, '%b %d, %Y') as formatted_date
        FROM daily_tasks 
        ORDER BY created_at DESC
    ");
    
    $stmt->execute();
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate statistics
    $stats = [
        'total_tasks' => count($tasks),
        'active_tasks' => count(array_filter($tasks, fn($t) => $t['enabled'] == 1)),
        'video_tasks' => count(array_filter($tasks, fn($t) => $t['type'] === 'video')),
        'social_tasks' => count(array_filter($tasks, fn($t) => $t['type'] === 'social')),
        'referral_tasks' => count(array_filter($tasks, fn($t) => $t['type'] === 'referral'))
    ];
    
    // Convert enabled field to boolean for frontend compatibility
    foreach ($tasks as &$task) {
        $task['enabled'] = (bool) $task['enabled'];
    }
    
    echo json_encode([
        'success' => true,
        'tasks' => $tasks,
        'stats' => $stats
    ]);
    
} catch (PDOException $e) {
    error_log("List tasks error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load tasks']);
}
?>
