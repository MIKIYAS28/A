<?php
require __DIR__ . "/../../config.php";
$in = json_decode(file_get_contents('php://input'), true);
$type = $in['type'] ?? '';
$id   = (int)($in['id'] ?? 0);

$pdo->prepare("UPDATE daily_tasks SET enabled = NOT enabled WHERE id = ?")->execute([$id]);
echo json_encode(['ok' => true]);