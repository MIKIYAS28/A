<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../config.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf']) || !isset($_SESSION['csrf_token']) || 
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf'])) {
    http_response_code(419);
    echo json_encode(['error' => 'CSRF token invalid']);
    exit;
}

$task_id     = (int)($_POST['task_id'] ?? 0);
$type        = $_POST['type'] ?? '';
$title       = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$url         = $_POST['url'] ?? '';
$reward      = (int)($_POST['reward'] ?? 0);
$target      = (int)($_POST['target_count'] ?? 1);
$enabled     = isset($_POST['enabled']) ? 1 : 0;

// Basic validation
if ($task_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid task ID']);
    exit;
}

if (!in_array($type, ['social', 'video', 'referral'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid task type']);
    exit;
}

if (empty($title) || empty($description) || $reward <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    // Check if task exists
    $checkStmt = $pdo->prepare("SELECT id FROM daily_tasks WHERE id = ?");
    $checkStmt->execute([$task_id]);
    
    if (!$checkStmt->fetch()) {
        http_response_code(404);
        echo json_encode(['error' => 'Task not found']);
        exit;
    }
    
    // Update the task
    $stmt = $pdo->prepare("
        UPDATE daily_tasks 
        SET type = ?, title = ?, description = ?, url = ?, reward = ?, target_count = ?, enabled = ?
        WHERE id = ?
    ");
    
    $stmt->execute([$type, $title, $description, $url, $reward, $target, $enabled, $task_id]);
    
    echo json_encode(['ok' => true, 'success' => true, 'message' => 'Task updated successfully']);
    
} catch (PDOException $e) {
    error_log("Update task error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to update task']);
}
?>
