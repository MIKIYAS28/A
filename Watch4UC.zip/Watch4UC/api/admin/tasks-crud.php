require __DIR__ . "/../../config.php";
$method = $_SERVER['REQUEST_METHOD'];
$input  = json_decode(file_get_contents('php://input'), true);

switch ($method) {
  case 'GET':
    echo json_encode([
      'social'   => $pdo->query("SELECT * FROM admin_tasks WHERE type='social'")->fetchAll(PDO::FETCH_ASSOC),
      'video'    => $pdo->query("SELECT * FROM admin_tasks WHERE type='video'")->fetchAll(PDO::FETCH_ASSOC),
      'referral' => $pdo->query("SELECT * FROM admin_tasks WHERE type='referral'")->fetchAll(PDO::FETCH_ASSOC)
    ]);
    break;

  case 'POST':
    $pdo->prepare("INSERT INTO admin_tasks (type,title,description,reward) VALUES (?,?,?,?)")
        ->execute([$input['type'],$input['title'],$input['description'],$input['reward']]);
    echo json_encode(['ok'=>true]);
    break;
}