<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require __DIR__ . "/../../config.php";

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf']) || !isset($_SESSION['csrf_token']) || 
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf'])) {
    http_response_code(419);
    echo json_encode(['error' => 'CSRF token invalid']);
    exit;
}

$task_id = (int)($_POST['task_id'] ?? 0);

if ($task_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid task ID']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    // Check if task exists
    $checkStmt = $pdo->prepare("SELECT id FROM daily_tasks WHERE id = ?");
    $checkStmt->execute([$task_id]);
    
    if (!$checkStmt->fetch()) {
        $pdo->rollback();
        http_response_code(404);
        echo json_encode(['error' => 'Task not found']);
        exit;
    }
    
    // Delete associated user task completions first (foreign key constraint)
    $deleteUserTasksStmt = $pdo->prepare("DELETE FROM user_task_completions WHERE task_id = ?");
    $deleteUserTasksStmt->execute([$task_id]);
    
    // Delete the task
    $deleteTaskStmt = $pdo->prepare("DELETE FROM daily_tasks WHERE id = ?");
    $deleteTaskStmt->execute([$task_id]);
    
    $pdo->commit();
    
    echo json_encode(['ok' => true, 'success' => true, 'message' => 'Task deleted successfully']);
    
} catch (PDOException $e) {
    $pdo->rollback();
    error_log("Delete task error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to delete task']);
}
