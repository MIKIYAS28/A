<?php
require __DIR__ . "/../../config.php";
header('Content-Type: application/json');

// Check if user is logged in and is admin
if (!isset($_SESSION['uid']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit;
}

$s=$pdo->query("SELECT
 (SELECT COUNT(*) FROM users) AS total,
 (SELECT COUNT(*) FROM users WHERE role='admin') AS admins,
 (SELECT COUNT(*) FROM users WHERE joined_at>=NOW()-INTERVAL 30 DAY) AS new30
")->fetch(PDO::FETCH_ASSOC);
echo json_encode($s);
?>