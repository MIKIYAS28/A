<?php
header('Content-Type: application/json');
$pdo = new PDO('mysql:host=localhost;dbname=watch4u;charset=utf8','root','');

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
  case 'GET':
      $id = $_GET['id'] ?? null;
      $sql = $id ? "SELECT * FROM videos WHERE id=?" : "SELECT * FROM videos";
      $stmt = $pdo->prepare($sql);
      if($id) $stmt->execute([$id]); else $stmt->execute();
      echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
      break;

  case 'POST':
      $in = json_decode(file_get_contents('php://input'),true);
      $vid = extractVideoId($in['url']);
      $stmt=$pdo->prepare("INSERT INTO videos(title,category,verificationCode,points,youtubeId,views) VALUES(?,?,?,?,?,0)");
      $stmt->execute([$in['title'],$in['category'],$in['code'],$in['points'],$vid]);
      echo json_encode(['ok'=>true]);
      break;

  case 'DELETE':
      $id=$_GET['id'];
      $pdo->prepare("DELETE FROM videos WHERE id=?")->execute([$id]);
      echo json_encode(['ok'=>true]);
      break;
}

function extractVideoId($url){
  preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i',$url,$m);
  return $m[1] ?? null;
}