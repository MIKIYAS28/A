<?php
require __DIR__ . "/../../config.php";

// Check if user is logged in and is admin
if (!isset($_SESSION['uid']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit;
}

$rows = $pdo->query("SELECT id,username,email,role,joined_at,balance,email_verified FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($rows);
