<?php
require __DIR__ . "/../../config.php";
if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit;

$in = json_decode(file_get_contents('php://input'), true);
$type = $in['type'] ?? '';
$task = $in['task'] ?? [];

if (!in_array($type, ['video','social','referral'])) exit;

$stmt = $pdo->prepare("REPLACE INTO daily_tasks
  (id, type, subtype, title, description, url, reward, count, enabled)
  VALUES (?,?,?,?,?,?,?,?,1)");
$stmt->execute([
  $task['id'],
  $type,
  $task['type'] ?? ($type === 'social' ? $task['platform'] : ($type === 'referral' ? $task['type'] : $task['type'])),
  $task['title'] ?? $task['name'],
  $task['description'] ?? '',
  $task['url'] ?? '',
  $task['reward'],
  $task['count'] ?? 1
]);