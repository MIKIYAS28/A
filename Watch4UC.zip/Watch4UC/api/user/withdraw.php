<?php
require __DIR__ . "/../../config.php";
session_start();
$uid   = (int)$_SESSION['uid'];
$amt   = (float)filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
$pdo->prepare("INSERT INTO transactions (user_id,type,amount) VALUES (?,'withdraw',?)")
    ->execute([$uid,$amt]);
echo json_encode(['ok'=>true]);