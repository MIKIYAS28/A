<?php
// JSON API for updating profile (username + optional profile picture)
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', 0);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.cookie_path', '/');
    session_start();
}

try {
    require_once __DIR__ . '/../../config.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database configuration not found']);
    exit;
}

$userId = $_SESSION['uid'] ?? null;
if (!$userId) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf'] ?? ($_POST['csrf_token'] ?? '');
if (isset($_SESSION['csrf_token']) && !hash_equals($_SESSION['csrf_token'], (string)$csrf)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

$username = isset($_POST['username']) ? trim((string)$_POST['username']) : '';
$email    = isset($_POST['email']) ? trim((string)$_POST['email']) : null;

if ($username === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Username is required']);
    exit;
}
if ($email !== null && $email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid email address']);
    exit;
}

$hasFile = isset($_FILES['profile_pic']) && is_array($_FILES['profile_pic']) && (int)($_FILES['profile_pic']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK;
$publicProfilePath = null;

if ($hasFile) {
    $allowedMime = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $tmpPath = $_FILES['profile_pic']['tmp_name'];
    $size    = (int)$_FILES['profile_pic']['size'];

    if (!is_uploaded_file($tmpPath)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid upload']);
        exit;
    }
    if ($size > 2 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Image too large (max 2MB)']);
        exit;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($tmpPath) ?: 'application/octet-stream';
    if (!isset($allowedMime[$mime])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Unsupported image type']);
        exit;
    }

    $uploadsDir = __DIR__ . '/../../uploads';
    if (!is_dir($uploadsDir)) {
        if (!mkdir($uploadsDir, 0777, true) && !is_dir($uploadsDir)) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Uploads directory not writable']);
            exit;
        }
    }

    $ext = $allowedMime[$mime];
    $safeBase = preg_replace('/[^A-Za-z0-9_-]+/', '_', strtolower($username));
    $filename = sprintf('%d_%s_%s.%s', $userId, $safeBase, bin2hex(random_bytes(6)), $ext);
    $destFs   = $uploadsDir . '/' . $filename;

    if (!move_uploaded_file($tmpPath, $destFs)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to save uploaded file']);
        exit;
    }

    $publicProfilePath = 'uploads/' . $filename;
}

try {
    $fields = ['username' => $username];
    $params = [];

    if ($email !== null && $email !== '') {
        $fields['email'] = $email;
    }
    if ($publicProfilePath !== null) {
        $fields['profile_pic'] = $publicProfilePath;
    }

    $setParts = [];
    foreach ($fields as $col => $val) {
        $setParts[] = "$col = ?";
        $params[]   = $val;
    }
    if (empty($setParts)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'No fields to update']);
        exit;
    }

    $params[] = $userId;

    $sql = 'UPDATE users SET ' . implode(', ', $setParts) . ' WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $_SESSION['username'] = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
    if ($email !== null && $email !== '') {
        $_SESSION['email'] = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
    }
    if ($publicProfilePath !== null) {
        $_SESSION['profile_pic'] = $publicProfilePath;
    }

    echo json_encode([
        'success' => true,
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'] ?? null,
        'profile_pic' => $_SESSION['profile_pic'] ?? null
    ]);
    exit;

} catch (Throwable $e) {
    error_log('profile-update error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error. Please try again later.']);
    exit;
}
