<?php
require __DIR__ . "/../../config.php";
session_start();
if (empty($_SESSION['uid'])) { http_response_code(401); exit('{"error":"not logged in"}'); }

$uid   = (int)$_SESSION['uid'];
$vid   = filter_input(INPUT_POST, 'video_id', FILTER_SANITIZE_STRING);
$pts   = (int)filter_input(INPUT_POST, 'points', FILTER_VALIDATE_INT);

$pdo->beginTransaction();
$pdo->prepare("INSERT INTO transactions (user_id,type,amount) VALUES (?,'video_credit',?)")
    ->execute([$uid,$pts]);
$pdo->prepare("INSERT INTO video_views (user_id,video_id,earned_points) VALUES (?,?,?)")
    ->execute([$uid,$vid,$pts]);
$pdo->commit();

echo json_encode(['ok'=>true]);