<?php
require __DIR__ . "/../../config.php";
session_start();
if (empty($_SESSION['uid'])) { 
    http_response_code(401); 
    exit('{"error":"login"}'); 
}

$uid = (int)$_SESSION['uid'];
$tasks = [
  'video'  => [],
  'social' => [],
  'referral' => []
];

// Video tasks
$rows = $pdo->query("SELECT * FROM daily_tasks WHERE type='video' AND enabled=1")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
  $stmt = $pdo->prepare("SELECT 1 FROM task_completions WHERE user_id=? AND task_id=?");
  $stmt->execute([$uid, $r['id']]);
  $done = (bool)$stmt->fetchColumn();
  
  $tasks['video'][] = [
    'id' => $r['id'],
    'title' => $r['title'],
    'type'  => $r['subtype'],
    'reward' => $r['reward'],
    'completed' => $done
  ];
}

// Social tasks
$rows = $pdo->query("SELECT * FROM daily_tasks WHERE type='social' AND enabled=1")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
  $stmt = $pdo->prepare("SELECT 1 FROM task_completions WHERE user_id=? AND task_id=?");
  $stmt->execute([$uid, $r['id']]);
  $done = (bool)$stmt->fetchColumn();
  
  $tasks['social'][] = [
    'id' => $r['id'],
    'platform' => $r['subtype'],
    'name' => $r['title'],
    'reward' => $r['reward'],
    'completed' => $done
  ];
}

// Referral tasks
$rows = $pdo->query("SELECT * FROM daily_tasks WHERE type='referral' AND enabled=1")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
  $stmt = $pdo->prepare("SELECT 1 FROM task_completions WHERE user_id=? AND task_id=?");
  $stmt->execute([$uid, $r['id']]);
  $done = (bool)$stmt->fetchColumn();
  
  $tasks['referral'][] = [
    'id' => $r['id'],
    'title' => $r['title'],
    'description' => $r['description'],
    'type'  => $r['subtype'],
    'count' => $r['count'],
    'progress' => $r['progress'],
    'reward' => $r['reward'],
    'completed' => $done
  ];
}

header('Content-Type: application/json');
echo json_encode(['ok' => true, 'tasks' => $tasks]);