<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Login required']);
    exit;
}

$userId = (int)$_SESSION['user_id'];

try {
    // Fetch all active tasks with completion status for the user
    $tasksStmt = $pdo->prepare("
        SELECT 
            dt.id,
            dt.type,
            dt.title,
            dt.description,
            dt.url,
            dt.reward as points,
            dt.target_count,
            dt.created_at,
            CASE 
                WHEN utc.id IS NOT NULL THEN true 
                ELSE false 
            END as completed
        FROM daily_tasks dt
        LEFT JOIN user_task_completions utc ON dt.id = utc.task_id 
            AND utc.user_id = ? 
            AND DATE(utc.completed_at) = CURDATE()
        WHERE dt.enabled = 1
        ORDER BY dt.created_at DESC
    ");
    
    $tasksStmt->execute([$userId]);
    $tasks = $tasksStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Add additional fields expected by the frontend
    foreach ($tasks as &$task) {
        $task['completed'] = (bool) $task['completed'];
        $task['points'] = (int) $task['points'];
        $task['target_count'] = (int) $task['target_count'];
        $task['completed_count'] = $task['completed'] ? $task['target_count'] : 0;
    }
    
    echo json_encode([
        'success' => true,
        'tasks' => $tasks
    ]);
    
} catch (PDOException $e) {
    error_log("Daily tasks error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load tasks']);
}
?>
