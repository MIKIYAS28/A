<?php
require __DIR__ . "/../../config.php";
session_start();

header('Content-Type: application/json');

if (empty($_SESSION['uid'])) { 
    http_response_code(401); 
    exit(json_encode(['ok' => false, 'error' => 'Not authenticated'])); 
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['ok' => false, 'error' => 'Method not allowed']));
}

$uid = (int)$_SESSION['uid'];
$type = $_POST['type'] ?? '';
$coins = (int)($_POST['coins'] ?? 0);
$taskId = (int)($_POST['taskId'] ?? 0);

if (!$type || !$coins || !$taskId) {
    exit(json_encode(['ok' => false, 'error' => 'Missing required fields']));
}

try {
    $pdo->beginTransaction();
    
    // Check if task exists and is enabled
    $stmt = $pdo->prepare("SELECT id FROM daily_tasks WHERE id = ? AND type = ? AND enabled = 1");
    $stmt->execute([$taskId, $type]);
    if (!$stmt->fetchColumn()) {
        $pdo->rollback();
        exit(json_encode(['ok' => false, 'error' => 'Invalid task']));
    }
    
    // Check if task is already completed
    $stmt = $pdo->prepare("SELECT id FROM task_completions WHERE user_id = ? AND task_id = ?");
    $stmt->execute([$uid, $taskId]);
    if ($stmt->fetchColumn()) {
        $pdo->rollback();
        exit(json_encode(['ok' => false, 'error' => 'Task already completed']));
    }
    
    // Mark task as completed
    $stmt = $pdo->prepare("INSERT INTO task_completions (user_id, task_id) VALUES (?, ?)");
    $stmt->execute([$uid, $taskId]);
    
    // Add coins to user balance
    $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->execute([$coins, $uid]);
    
    $pdo->commit();
    
    echo json_encode(['ok' => true, 'message' => 'Task completed successfully', 'coins_added' => $coins]);
    
} catch (Exception $e) {
    $pdo->rollback();
    error_log('Task completion error: ' . $e->getMessage());
    exit(json_encode(['ok' => false, 'error' => 'Database error']));
}
?>
