// get_withdrawal_history.php
<?php
session_start();
header('Content-Type: application/json');

// Database configuration
$servername = "localhost";
$username = "your_db_username";
$password = "your_db_password";
$dbname = "your_db_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed"]));
}

// Get user ID from session
$userId = $_SESSION['user_id'] ?? null;

if (!$userId) {
    echo json_encode(["error" => "User not authenticated"]);
    exit;
}

// Fetch withdrawal history
$sql = "SELECT * FROM withdrawal_history WHERE user_id = ? ORDER BY date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$transactions = [];
while ($row = $result->fetch_assoc()) {
    $transactions[] = [
        'id' => $row['id'],
        'date' => date('M j, Y', strtotime($row['date'])),
        'amount' => number_format($row['amount'], 2) . ' ' . $row['currency'],
        'destination_account' => $row['destination_account'],
        'destination_details' => $row['destination_details'],
        'status' => $row['status'],
        'transaction_id' => $row['transaction_id'],
        'note' => $row['note']
    ];
}

echo json_encode([
    "transactions" => $transactions,
    "total" => count($transactions)
]);

$stmt->close();
$conn->close();
?>