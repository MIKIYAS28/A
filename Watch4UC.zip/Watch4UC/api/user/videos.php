<?php
header('Content-Type: application/json');
$pdo = new PDO('mysql:host=localhost;dbname=watch4u;charset=utf8','root','');
$stmt = $pdo->query("SELECT id,title,category,points,youtubeId FROM videos WHERE status='Active'");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));