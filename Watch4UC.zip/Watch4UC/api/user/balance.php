<?php
require __DIR__ . "/../../config.php";

if (!isset($_SESSION['uid'])) {
    http_response_code(401);
    echo json_encode(['error'=>'Not authenticated']);
    exit;
}

$stmt = $pdo->prepare("SELECT balance FROM users WHERE id=?");
$stmt->execute([$_SESSION['uid']]);
echo json_encode(['balance'=>$stmt->fetchColumn()]);
