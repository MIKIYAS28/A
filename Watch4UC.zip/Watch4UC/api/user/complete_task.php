<?php
// Check if session is already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Login required']);
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf']) || !isset($_SESSION['csrf_token']) || 
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf'])) {
    http_response_code(419);
    echo json_encode(['error' => 'CSRF token invalid']);
    exit;
}

$userId = (int)$_SESSION['user_id'];
$taskId = (int)($_POST['task_id'] ?? 0);

if ($taskId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid task ID']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    // Check if task exists and is active
    $taskStmt = $pdo->prepare("
        SELECT id, title, reward, enabled 
        FROM daily_tasks 
        WHERE id = ? AND enabled = 1
    ");
    $taskStmt->execute([$taskId]);
    $task = $taskStmt->fetch();
    
    if (!$task) {
        $pdo->rollback();
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Task not found or inactive']);
        exit;
    }
    
    // Check if user has already completed this task today
    $completedStmt = $pdo->prepare("
        SELECT id FROM user_task_completions 
        WHERE user_id = ? AND task_id = ? AND DATE(completed_at) = CURDATE()
    ");
    $completedStmt->execute([$userId, $taskId]);
    
    if ($completedStmt->fetch()) {
        $pdo->rollback();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Task already completed today']);
        exit;
    }
    
    // Mark task as completed
    $completeTaskStmt = $pdo->prepare("
        INSERT INTO user_task_completions (user_id, task_id, completed_at, reward_given) 
        VALUES (?, ?, NOW(), ?)
    ");
    $completeTaskStmt->execute([$userId, $taskId, $task['reward']]);
    
    // Award points to user - first check if user has balance column
    $checkColumnStmt = $pdo->prepare("SHOW COLUMNS FROM users LIKE 'balance'");
    $checkColumnStmt->execute();
    $hasBalance = $checkColumnStmt->fetch();
    
    if ($hasBalance) {
        // Update balance column
        $updateBalanceStmt = $pdo->prepare("
            UPDATE users 
            SET balance = balance + ? 
            WHERE id = ?
        ");
        $updateBalanceStmt->execute([$task['reward'], $userId]);
        
        // Get new balance
        $balanceStmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
        $balanceStmt->execute([$userId]);
        $newBalance = $balanceStmt->fetchColumn();
    } else {
        // Fallback: just return success without updating balance
        $newBalance = 0;
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Task completed successfully',
        'points_earned' => (int)$task['reward'],
        'new_points' => (int)$newBalance
    ]);
    
} catch (PDOException $e) {
    $pdo->rollback();
    error_log("Complete task error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to complete task']);
}
?>
