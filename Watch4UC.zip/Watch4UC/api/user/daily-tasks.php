<?php
require __DIR__ . "/../../config.php";
$tasks = $pdo->query("SELECT * FROM daily_tasks ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($tasks);