<?php
require __DIR__ . "/../../config.php";
session_start();
if (empty($_SESSION['uid'])) { http_response_code(401); exit('{"error":"not logged in"}'); }

$uid = (int)$_SESSION['uid'];

$stats = $pdo->query(
  "SELECT
     COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type='video_credit'),0)  AS main_balance,
     COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type='referral_bonus'),0) AS referral_bonus,
     COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type='deposit'),0)        AS total_deposit,
     COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type='withdraw'),0)       AS total_withdraw,
     COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type='credit'),0)         AS current_credit,
     COALESCE((SELECT COUNT(*) FROM video_views WHERE user_id=$uid),0)                               AS videos_viewed,
     COALESCE((SELECT COUNT(*) FROM video_views WHERE user_id=$uid AND DATE(viewed_at)=CURDATE()),0) AS today_views
")->fetch(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($stats);