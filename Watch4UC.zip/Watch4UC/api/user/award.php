<?php
session_start();
$pdo = new PDO('mysql:host=localhost;dbname=watch4u;charset=utf8','root','');
$in = json_decode(file_get_contents('php://input'),true);
$pdo->prepare("UPDATE users SET balance = balance + ? WHERE id=?")->execute([$in['points'],$_SESSION['uid']]);
echo json_encode(['ok'=>true]);