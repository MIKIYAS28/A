-- run once
CREATE TABLE referrals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sharer_id INT NOT NULL,
  new_user_id INT UNIQUE,
  code VARCHAR(64) UNIQUE,
  claimed TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);