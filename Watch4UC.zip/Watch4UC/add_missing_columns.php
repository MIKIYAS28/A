<?php
require_once 'config.php';

echo "Checking and adding missing columns...\n\n";

// List of columns we need
$required_columns = [
    'points' => "INT(11) DEFAULT 0",
    'avatar' => "VARCHAR(255) DEFAULT NULL",
    'created_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP"
];

foreach ($required_columns as $column => $definition) {
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE '$column'");
    if ($stmt->fetch()) {
        echo "✅ $column column already exists\n";
    } else {
        echo "❌ $column column missing - adding it...\n";
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN $column $definition");
            echo "✅ $column column added successfully\n";
        } catch (PDOException $e) {
            echo "❌ Failed to add $column: " . $e->getMessage() . "\n";
        }
    }
}

// Update me.php to use profile_pic as avatar
echo "\n📝 Note: The 'profile_pic' column will be used as 'avatar' in API responses\n";

// List final structure
echo "\nFinal users table structure:\n";
$stmt = $pdo->query("DESCRIBE users");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo sprintf("  %-30s %-30s %s\n", $row['Field'], $row['Type'], $row['Default'] ?? 'NULL');
}
?>
