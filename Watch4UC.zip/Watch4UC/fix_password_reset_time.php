<?php
echo "<h2>🕒 Password Reset Timezone Fix</h2>";

require_once 'config.php';

// Set timezone to avoid issues
date_default_timezone_set('UTC');

echo "<h3>Current Time Information:</h3>";
echo "<p><strong>Server Time (PHP):</strong> " . date('Y-m-d H:i:s') . "</p>";
echo "<p><strong>MySQL NOW():</strong> ";

try {
    $stmt = $pdo->query("SELECT NOW() as current_time");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo $result['current_time'];
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
echo "</p>";

// Check token status with proper time handling
echo "<h3>Reset Token Status:</h3>";

try {
    $stmt = $pdo->query("SELECT id, username, email, password_reset_token, password_reset_expires,
                        CASE 
                            WHEN password_reset_expires > NOW() THEN 'Valid' 
                            ELSE 'Expired' 
                        END as status,
                        TIMESTAMPDIFF(MINUTE, NOW(), password_reset_expires) as minutes_remaining
                        FROM users 
                        WHERE password_reset_token IS NOT NULL 
                        ORDER BY password_reset_expires DESC 
                        LIMIT 5");
    $tokens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($tokens)) {
        echo "<p>No password reset tokens found.</p>";
    } else {
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>Username</th><th>Email</th><th>Expires</th><th>Status</th><th>Minutes Left</th><th>Action</th></tr>";
        
        foreach ($tokens as $token) {
            $status = $token['status'];
            $statusColor = $status === 'Valid' ? 'green' : 'red';
            $minutesLeft = $token['minutes_remaining'];
            
            echo "<tr>";
            echo "<td>" . htmlspecialchars($token['username']) . "</td>";
            echo "<td>" . htmlspecialchars($token['email']) . "</td>";
            echo "<td>" . $token['password_reset_expires'] . "</td>";
            echo "<td style='color: $statusColor;'><strong>$status</strong></td>";
            echo "<td>" . ($minutesLeft > 0 ? "+$minutesLeft min" : "$minutesLeft min") . "</td>";
            
            if ($status === 'Expired') {
                echo "<td><a href='?extend=" . $token['id'] . "' style='color: blue;'>🔄 Extend Token</a></td>";
            } else {
                echo "<td><a href='debug_reset_token.php?token=" . urlencode($token['password_reset_token']) . "' target='_blank'>🧪 Test Token</a></td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<div style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

// Handle token extension
if (isset($_GET['extend']) && is_numeric($_GET['extend'])) {
    $userId = (int)$_GET['extend'];
    
    try {
        // Extend token by 1 hour from now
        $newExpiry = date('Y-m-d H:i:s', time() + 3600);
        $stmt = $pdo->prepare("UPDATE users SET password_reset_expires = ? WHERE id = ? AND password_reset_token IS NOT NULL");
        $stmt->execute([$newExpiry, $userId]);
        
        if ($stmt->rowCount() > 0) {
            echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
            echo "<h4>✅ Token Extended!</h4>";
            echo "<p>Password reset token has been extended by 1 hour (until $newExpiry).</p>";
            echo "</div>";
            echo "<meta http-equiv='refresh' content='2'>";
        } else {
            echo "<div style='color: red;'>❌ Failed to extend token</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color: red;'>Error extending token: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}

echo "<hr>";
echo "<h3>🧪 Test Password Reset Process:</h3>";

echo "<h4>Step 1: Request Fresh Password Reset</h4>";
echo "<form method='post' style='background: #f5f5f5; padding: 15px; border-radius: 5px;'>";
echo "<p>Enter email to send fresh password reset:</p>";
echo "<input type='email' name='test_email' placeholder='Enter email address' style='padding: 8px; width: 250px;' required>";
echo "<button type='submit' name='send_reset' style='padding: 8px 16px; background: #10b981; color: white; border: none; border-radius: 4px; margin-left: 10px;'>📧 Send Reset Email</button>";
echo "</form>";

// Handle test password reset
if (isset($_POST['send_reset'])) {
    $testEmail = trim($_POST['test_email']);
    
    if (filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
        echo "<h4>📧 Sending Password Reset...</h4>";
        
        // Simulate the forgot password process
        try {
            $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
            $stmt->execute([$testEmail]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // Generate new token
                $resetToken = bin2hex(random_bytes(32));
                $expiryTime = date('Y-m-d H:i:s', time() + 3600); // 1 hour
                
                // Update user with new token
                $stmt = $pdo->prepare("UPDATE users SET password_reset_token = ?, password_reset_expires = ? WHERE id = ?");
                $stmt->execute([$resetToken, $expiryTime, $user['id']]);
                
                echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
                echo "<h4>✅ Reset Token Generated!</h4>";
                echo "<p><strong>User:</strong> " . htmlspecialchars($user['username']) . "</p>";
                echo "<p><strong>Token expires:</strong> $expiryTime</p>";
                echo "<p><strong>Reset URL:</strong><br>";
                echo "<a href='reset_password.php?token=" . urlencode($resetToken) . "' target='_blank'>";
                echo "http://localhost/Watch4UC/reset_password.php?token=" . htmlspecialchars($resetToken);
                echo "</a></p>";
                echo "<p><strong>Debug URL:</strong><br>";
                echo "<a href='debug_reset_token.php?token=" . urlencode($resetToken) . "' target='_blank'>";
                echo "Test this token";
                echo "</a></p>";
                echo "</div>";
                
                // Try sending email
                try {
                    require_once 'includes/email_functions.php';
                    $emailSent = sendPasswordResetEmail($testEmail, $user['username'], $resetToken);
                    
                    if ($emailSent) {
                        echo "<div style='color: green; background: #e8f5e8; padding: 10px; border-radius: 5px;'>";
                        echo "📧 Password reset email sent successfully!";
                        echo "</div>";
                    } else {
                        echo "<div style='color: orange; background: #fff3cd; padding: 10px; border-radius: 5px;'>";
                        echo "⚠️ Token generated but email sending failed. Use the reset URL above directly.";
                        echo "</div>";
                    }
                } catch (Exception $e) {
                    echo "<div style='color: orange; background: #fff3cd; padding: 10px; border-radius: 5px;'>";
                    echo "⚠️ Email error: " . htmlspecialchars($e->getMessage()) . "<br>Use the reset URL above directly.";
                    echo "</div>";
                }
                
            } else {
                echo "<div style='color: red;'>❌ User not found with email: " . htmlspecialchars($testEmail) . "</div>";
            }
        } catch (Exception $e) {
            echo "<div style='color: red;'>Database error: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    } else {
        echo "<div style='color: red;'>❌ Please enter a valid email address</div>";
    }
}

echo "<hr>";
echo "<h3>🔧 Quick Fixes:</h3>";
echo "<ol>";
echo "<li><strong>For Expired Tokens:</strong> Click '🔄 Extend Token' above to extend expiry time</li>";
echo "<li><strong>For Fresh Test:</strong> Use the form above to generate a new reset token</li>";
echo "<li><strong>For Real Use:</strong> Go to <a href='login.html'>login page</a> and use 'Forgot Password'</li>";
echo "</ol>";

echo "<p><strong>Links:</strong></p>";
echo "<ul>";
echo "<li><a href='login.html'>🔗 Login Page</a></li>";
echo "<li><a href='debug_reset_token.php'>🔍 Debug Token (without token)</a></li>";
echo "<li><a href='setup_email.php'>📧 Email Setup</a></li>";
echo "</ul>";
?>
