<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/email_functions.php';

$token = $_GET['token'] ?? '';
$error = '';
$success = '';
$userInfo = null;

// Check if token is provided and valid
if ($token) {
    try {
        // Find user with this activation token that hasn't expired
        $stmt = $pdo->prepare("
            SELECT id, username, email, email_verified 
            FROM users 
            WHERE email_verification_token = ? 
            AND email_verification_expires > NOW()
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            if ($user['email_verified']) {
                // Account already activated
                $success = 'Your account has already been activated! You can now log in.';
                $userInfo = $user;
            } else {
                // Activate the account
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET email_verified = 1, 
                        email_verification_token = NULL, 
                        email_verification_expires = NULL 
                    WHERE id = ?
                ");
                $stmt->execute([$user['id']]);
                
                $success = 'Congratulations! Your account has been successfully activated. You can now log in and start earning points!';
                $userInfo = $user;
                
                // Send welcome email after successful activation
                try {
                    sendWelcomeEmail($user['email'], $user['username']);
                } catch (Exception $e) {
                    error_log("Failed to send welcome email after activation: " . $e->getMessage());
                }
            }
        } else {
            // Check if token exists but has expired
            $stmt = $pdo->prepare("
                SELECT id, username, email 
                FROM users 
                WHERE email_verification_token = ?
            ");
            $stmt->execute([$token]);
            $expiredUser = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($expiredUser) {
                $error = 'This activation link has expired. Please request a new activation email.';
                $userInfo = $expiredUser;
            } else {
                $error = 'Invalid activation link. This link may have been used already or does not exist.';
            }
        }
    } catch (PDOException $e) {
        error_log("Database error in account activation: " . $e->getMessage());
        $error = 'A database error occurred. Please try again later.';
    }
} else {
    $error = 'No activation token provided.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $success ? 'Account Activated' : 'Account Activation'; ?> - Watch4UC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #10b981;
            --secondary-color: #059669;
            --error-color: #ef4444;
            --warning-color: #f59e0b;
            --background: #ffffff;
            --foreground: #111827;
            --gray: #e5e7eb;
            --gray-2: #6b7280;
        }

        html.dark {
            --background: #121212;
            --foreground: #ffffff;
            --gray: #333333;
            --gray-2: #aaaaaa;
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        body {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--foreground);
            padding: 20px;
        }

        .container {
            background: var(--background);
            padding: 2rem;
            border-radius: 1.5rem;
            box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        .logo {
            margin-bottom: 2rem;
        }

        .logo h1 {
            color: var(--primary-color);
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .status-icon {
            font-size: 4rem;
            margin: 1rem 0;
        }

        .success-icon {
            color: var(--primary-color);
        }

        .error-icon {
            color: var(--error-color);
        }

        .warning-icon {
            color: var(--warning-color);
        }

        .message {
            padding: 1.5rem;
            border-radius: 0.5rem;
            margin: 1.5rem 0;
            font-size: 1.1rem;
            line-height: 1.6;
        }

        .success-message {
            background: #d1fae5;
            color: #059669;
            border-left: 4px solid var(--primary-color);
        }

        .error-message {
            background: #fee2e2;
            color: #dc2626;
            border-left: 4px solid var(--error-color);
        }

        .user-info {
            background: var(--gray);
            padding: 1rem;
            border-radius: 0.5rem;
            margin: 1rem 0;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            margin: 10px;
            border: none;
            border-radius: 0.5rem;
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }

        .btn-secondary {
            background-color: var(--gray);
            color: var(--foreground);
        }

        .btn-secondary:hover {
            background-color: var(--gray-2);
            color: white;
        }

        .features {
            text-align: left;
            background: #f8fafc;
            padding: 1.5rem;
            border-radius: 0.5rem;
            margin: 1.5rem 0;
        }

        .features h3 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .features ul {
            list-style: none;
        }

        .features li {
            padding: 0.5rem 0;
            padding-left: 2rem;
            position: relative;
        }

        .features li:before {
            content: "✅";
            position: absolute;
            left: 0;
        }

        .resend-section {
            background: #fff3cd;
            color: #856404;
            padding: 1rem;
            border-radius: 0.5rem;
            margin: 1rem 0;
            border-left: 4px solid #ffc107;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }

        .toggle {
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
            transition: transform 0.3s ease;
            width: 48px;
            height: 48px;
            position: relative;
        }

        .toggle .face {
            position: relative;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: var(--background);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toggle .face:before {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(-45deg, var(--primary-color), var(--secondary-color));
            opacity: 0.7;
        }

        .toggle svg {
            position: relative;
            width: 24px;
            height: 24px;
            z-index: 2;
            color: var(--foreground);
        }

        .hide {
            display: none;
        }

        @media (max-width: 480px) {
            .container {
                padding: 1.5rem;
                margin: 10px;
            }
            
            .logo h1 {
                font-size: 2rem;
            }
            
            .status-icon {
                font-size: 3rem;
            }
        }
    </style>
</head>
<body>
    <div class="theme-toggle">
        <button aria-pressed="false" class="toggle" id="themeToggle">
            <div class="face">
                <svg id="darkIcon" class="hide" viewBox="0 0 24 24" fill="none">
                    <path d="M12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="currentColor"/>
                    <path d="M12 2V4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <svg id="lightIcon" viewBox="0 0 24 24" fill="none">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" fill="currentColor"/>
                </svg>
            </div>
        </button>
    </div>

    <div class="container">
        <div class="logo">
            <h1>Watch4UC</h1>
            <p>Account Activation</p>
        </div>

        <?php if ($success): ?>
            <div class="status-icon success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            
            <div class="success-message message">
                <?php echo htmlspecialchars($success); ?>
            </div>
            
            <?php if ($userInfo): ?>
                <div class="user-info">
                    <strong>Welcome, <?php echo htmlspecialchars($userInfo['username']); ?>!</strong><br>
                    <small><?php echo htmlspecialchars($userInfo['email']); ?></small>
                </div>
            <?php endif; ?>
            
            <div class="features">
                <h3>🎉 You can now:</h3>
                <ul>
                    <li>Watch videos and earn points</li>
                    <li>Complete daily tasks for bonus rewards</li>
                    <li>Redeem your points for PUBG UC</li>
                    <li>Track your progress and earnings</li>
                    <li>Participate in special promotions</li>
                </ul>
            </div>
            
            <a href="login.html" class="btn btn-primary">
                <i class="fas fa-sign-in-alt"></i> Login Now
            </a>
            
        <?php else: ?>
            <div class="status-icon error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            
            <div class="error-message message">
                <?php echo htmlspecialchars($error); ?>
            </div>
            
            <?php if ($userInfo && strpos($error, 'expired') !== false): ?>
                <div class="resend-section">
                    <h4>Need a new activation link?</h4>
                    <p>Your activation link has expired, but don't worry! You can request a new one.</p>
                    
                    <form method="POST" action="resend_activation.php" style="margin-top: 1rem;">
                        <input type="hidden" name="email" value="<?php echo htmlspecialchars($userInfo['email']); ?>">
                        <button type="submit" class="btn btn-secondary">
                            <i class="fas fa-envelope"></i> Send New Activation Email
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <div style="margin-top: 2rem;">
            <a href="login.html" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Login
            </a>
        </div>
    </div>

    <script>
        // Theme toggle functionality
        const themeToggle = document.getElementById('themeToggle');
        const darkIcon = document.getElementById('darkIcon');
        const lightIcon = document.getElementById('lightIcon');
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

        if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
            document.documentElement.classList.add('dark');
            lightIcon.style.display = 'none';
            darkIcon.style.display = 'block';
        } else {
            document.documentElement.classList.remove('dark');
            lightIcon.style.display = 'block';
            darkIcon.style.display = 'none';
        }

        themeToggle.addEventListener('click', () => {
            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('theme', 'light');
                lightIcon.style.display = 'block';
                darkIcon.style.display = 'none';
            } else {
                document.documentElement.classList.add('dark');
                localStorage.setItem('theme', 'dark');
                lightIcon.style.display = 'none';
                darkIcon.style.display = 'block';
            }
        });

        // Auto redirect to login after successful activation
        <?php if ($success && $userInfo): ?>
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 5000);
        <?php endif; ?>
    </script>
</body>
</html>
