<?php
echo "<h2>Database Structure Fix</h2>";

require_once 'config.php';

try {
    echo "<h3>Adding missing email verification columns...</h3>";
    
    // Add email_verification_token column
    $stmt = $pdo->query("ALTER TABLE users ADD COLUMN email_verification_token VARCHAR(64) NULL");
    echo "<div style='color: green;'>✓ Added email_verification_token column</div>";
    
    // Add email_verification_expires column
    $stmt = $pdo->query("ALTER TABLE users ADD COLUMN email_verification_expires DATETIME NULL");
    echo "<div style='color: green;'>✓ Added email_verification_expires column</div>";
    
    echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>✅ Database Fixed Successfully!</h3>";
    echo "<p>Your database now has all the required columns for email verification.</p>";
    echo "</div>";
    
    // Verify the fix
    echo "<h3>Verifying database structure:</h3>";
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<ul>";
    foreach ($columns as $column) {
        $isNew = in_array($column['Field'], ['email_verification_token', 'email_verification_expires']);
        $style = $isNew ? "color: green; font-weight: bold;" : "";
        echo "<li style='$style'>" . htmlspecialchars($column['Field']) . " - " . htmlspecialchars($column['Type']) . "</li>";
    }
    echo "</ul>";
    
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "<div style='color: orange; background: #fff3cd; padding: 15px; border-radius: 5px;'>";
        echo "<h3>⚠️ Columns Already Exist</h3>";
        echo "<p>The email verification columns have already been added to your database.</p>";
        echo "</div>";
    } else {
        echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
        echo "<h3>❌ Database Error</h3>";
        echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "</div>";
    }
}

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li><a href='test_signup_detailed.php'>Re-run the detailed test</a> to verify all issues are fixed</li>";
echo "<li><a href='login.html'>Try signing up</a> with the real form</li>";
echo "<li>Configure your email settings in <code>includes/email_config.php</code> for email activation to work</li>";
echo "</ol>";
?>
