<?php
session_start();
require 'config.php';

echo "<h1>Debug User Data</h1>";

echo "<h2>Session Data:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h2>Session UID:</h2>";
echo isset($_SESSION['uid']) ? $_SESSION['uid'] : 'NOT SET';

echo "<h2>Database Connection Test:</h2>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "Successfully connected to database. Users count: " . $count;
} catch (Exception $e) {
    echo "Database error: " . $e->getMessage();
}

echo "<h2>Users in Database:</h2>";
try {
    $stmt = $pdo->query("SELECT id, username, email FROM users LIMIT 5");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>";
    print_r($users);
    echo "</pre>";
} catch (Exception $e) {
    echo "Error fetching users: " . $e->getMessage();
}

if (isset($_SESSION['uid'])) {
    echo "<h2>Current User Data:</h2>";
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['uid']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<pre>";
        print_r($user);
        echo "</pre>";
    } catch (Exception $e) {
        echo "Error fetching current user: " . $e->getMessage();
    }
}
?>
