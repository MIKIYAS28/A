<?php
require_once 'config.php';

echo "Checking database tables:\n";
echo "========================\n\n";

try {
    // Check if tables exist
    $tables_to_check = ['users', 'daily_tasks', 'task_completions'];
    
    foreach ($tables_to_check as $table) {
        echo "Checking table: $table\n";
        try {
            $result = $pdo->query("SHOW TABLES LIKE '$table'")->fetchColumn();
            if ($result) {
                echo "✅ Table $table EXISTS\n";
                
                // Show table structure
                $columns = $pdo->query("DESCRIBE $table")->fetchAll(PDO::FETCH_ASSOC);
                echo "   Columns: ";
                foreach ($columns as $col) {
                    echo $col['Field'] . " ";
                }
                echo "\n";
                
                // Show row count
                $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
                echo "   Rows: $count\n";
            } else {
                echo "❌ Table $table MISSING\n";
            }
        } catch (Exception $e) {
            echo "❌ Error checking $table: " . $e->getMessage() . "\n";
        }
        echo "\n";
    }
    
    echo "All tables check:\n";
    $all_tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables in database: " . implode(', ', $all_tables) . "\n";
    
} catch (Exception $e) {
    echo "Database connection error: " . $e->getMessage() . "\n";
}
?>
