<?php
// Prevent any HTML output
ini_set('display_errors', 0);
error_reporting(0);
ob_start();

header('Content-Type: application/json');

try {
    // Test database connection
    $pdo = new PDO("mysql:host=localhost;dbname=watch4uc", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Test if users table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    $tableExists = $stmt->rowCount() > 0;
    
    if ($tableExists) {
        // Count users
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
        $userCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo json_encode([
            'success' => true,
            'message' => 'Database connection successful',
            'users_table_exists' => true,
            'user_count' => $userCount
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Database connected but users table not found'
        ]);
    }
    
} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed',
        'details' => $e->getMessage()
    ]);
}
?>
