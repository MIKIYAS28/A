<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

echo "<h1>🔍 Authentication Debug Tool</h1>";

// Test database connection
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✅ Users table exists</p>";
        
        // Show table structure
        $stmt = $pdo->query("DESCRIBE users");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>📋 Users Table Structure:</h3>";
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show existing users
        $stmt = $pdo->query("SELECT id, username, email, email_verified, role FROM users");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>👥 Existing Users (" . count($users) . "):</h3>";
        if (empty($users)) {
            echo "<p>No users found in database.</p>";
        } else {
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Verified</th><th>Role</th></tr>";
            foreach ($users as $user) {
                echo "<tr>";
                echo "<td>{$user['id']}</td>";
                echo "<td>{$user['username']}</td>";
                echo "<td>{$user['email']}</td>";
                echo "<td>" . ($user['email_verified'] ? '✅' : '❌') . "</td>";
                echo "<td>{$user['role']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    } else {
        echo "<p>❌ Users table does not exist!</p>";
        
        // Create the users table
        echo "<p>🔧 Creating users table...</p>";
        $createTable = "
        CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            balance DECIMAL(10,2) DEFAULT 0.00,
            role ENUM('user', 'admin') DEFAULT 'user',
            email_verified TINYINT(1) DEFAULT 0,
            email_verification_token VARCHAR(64) NULL,
            email_verification_expires DATETIME NULL,
            password_reset_token VARCHAR(64) NULL,
            password_reset_expires DATETIME NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        try {
            $pdo->exec($createTable);
            echo "<p>✅ Users table created successfully!</p>";
        } catch (Exception $e) {
            echo "<p>❌ Failed to create users table: " . $e->getMessage() . "</p>";
        }
    }
} catch (Exception $e) {
    echo "<p>❌ Database connection failed: " . $e->getMessage() . "</p>";
}

// Handle form submissions
if ($_POST) {
    echo "<h3>🧪 Processing Form Data:</h3>";
    
    if ($_POST['action'] === 'clear_users') {
        try {
            $pdo->exec("DELETE FROM users");
            echo "<p style='color:green;'>✅ All users cleared from database</p>";
        } catch (Exception $e) {
            echo "<p style='color:red;'>❌ Failed to clear users: " . $e->getMessage() . "</p>";
        }
    }
    
    if ($_POST['action'] === 'test_signup') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        echo "<p><strong>Input Data:</strong></p>";
        echo "<ul>";
        echo "<li>Username: " . htmlspecialchars($username) . "</li>";
        echo "<li>Email: " . htmlspecialchars($email) . "</li>";
        echo "<li>Password: " . str_repeat('*', strlen($password)) . "</li>";
        echo "</ul>";
        
        if (!$username || !$email || !$password) {
            echo "<p style='color:red;'>❌ All fields required</p>";
        } else {
            // Check if user exists
            try {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $email]);
                $existing = $stmt->fetch();
                
                if ($existing) {
                    echo "<p style='color:orange;'>⚠️ User already exists with ID: " . $existing['id'] . "</p>";
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Insert new user with email_verified = 1 for testing
                    $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, balance, email_verified, role) VALUES (?, ?, ?, 0.00, 1, 'user')");
                    $result = $stmt->execute([$username, $email, $hash]);
                    
                    if ($result) {
                        $newId = $pdo->lastInsertId();
                        echo "<p style='color:green;'>✅ User created successfully with ID: $newId</p>";
                    } else {
                        echo "<p style='color:red;'>❌ Failed to create user</p>";
                    }
                }
            } catch (PDOException $e) {
                echo "<p style='color:red;'>❌ Database error: " . $e->getMessage() . "</p>";
            }
        }
    }
    
    if ($_POST['action'] === 'test_login') {
        $email = trim($_POST['login_email']);
        $password = $_POST['login_password'];
        
        echo "<p><strong>Login Attempt:</strong></p>";
        echo "<ul>";
        echo "<li>Email: " . htmlspecialchars($email) . "</li>";
        echo "<li>Password: " . str_repeat('*', strlen($password)) . "</li>";
        echo "</ul>";
        
        try {
            $stmt = $pdo->prepare("SELECT id, username, role, password_hash, email_verified FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                echo "<p style='color:red;'>❌ No user found with email: $email</p>";
            } else {
                echo "<p><strong>Found User:</strong></p>";
                echo "<ul>";
                echo "<li>ID: {$user['id']}</li>";
                echo "<li>Username: {$user['username']}</li>";
                echo "<li>Role: {$user['role']}</li>";
                echo "<li>Email Verified: " . ($user['email_verified'] ? 'Yes' : 'No') . "</li>";
                echo "</ul>";
                
                if (password_verify($password, $user['password_hash'])) {
                    echo "<p style='color:green;'>✅ Password is correct!</p>";
                    
                    // Set session
                    $_SESSION['uid'] = $user['id'];
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    
                    echo "<p style='color:green;'>✅ Session set successfully!</p>";
                    echo "<p><strong>Redirect would be:</strong> " . ($user['role'] === 'admin' ? '/admin/users.html' : '/users/Dashboard.html') . "</p>";
                } else {
                    echo "<p style='color:red;'>❌ Password is incorrect</p>";
                }
            }
        } catch (Exception $e) {
            echo "<p style='color:red;'>❌ Database error: " . $e->getMessage() . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Watch4UC Debug</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .section { border: 1px solid #ccc; padding: 15px; margin: 15px 0; border-radius: 5px; }
        input, button { padding: 8px; margin: 5px; }
        button { background: #007bff; color: white; border: none; border-radius: 3px; cursor: pointer; }
        button:hover { background: #0056b3; }
        button.danger { background: #dc3545; }
        button.danger:hover { background: #c82333; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>

<div class="section">
    <h3>🧹 Database Management</h3>
    <form method="POST">
        <input type="hidden" name="action" value="clear_users">
        <button type="submit" class="danger" onclick="return confirm('Are you sure you want to delete all users?')">
            Clear All Users
        </button>
    </form>
</div>

<div class="section">
    <h3>📝 Test Signup</h3>
    <form method="POST">
        <input type="hidden" name="action" value="test_signup">
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Test Signup</button>
    </form>
</div>

<div class="section">
    <h3>🔐 Test Login</h3>
    <form method="POST">
        <input type="hidden" name="action" value="test_login">
        <input type="email" name="login_email" placeholder="Email" required>
        <input type="password" name="login_password" placeholder="Password" required>
        <button type="submit">Test Login</button>
    </form>
</div>

<div class="section">
    <h3>🔗 Quick Links</h3>
    <p><a href="login.html">Main Login Page</a></p>
    <p><a href="users/Dashboard.html">Dashboard</a> | <a href="admin/users.html">Admin Panel</a></p>
</div>

<?php if (isset($_SESSION['username'])): ?>
<div class="section" style="background: #d4edda;">
    <h3>✅ Current Session</h3>
    <p>Logged in as: <strong><?= htmlspecialchars($_SESSION['username']) ?></strong></p>
    <p>Role: <strong><?= htmlspecialchars($_SESSION['role']) ?></strong></p>
    <p><a href="auth/logout.php">Logout</a></p>
</div>
<?php endif; ?>

</body>
</html>
