<?php
// Simple Email Configuration Checker
echo "<h1>🔍 Quick Email Configuration Check</h1>";
echo "<style>
body{font-family:Arial,sans-serif;max-width:800px;margin:20px auto;padding:20px;}
.success{color:#059669;background:#d1fae5;padding:10px;border-radius:5px;margin:10px 0;}
.error{color:#dc2626;background:#fee2e2;padding:10px;border-radius:5px;margin:10px 0;}
.warning{color:#d97706;background:#fef3c7;padding:10px;border-radius:5px;margin:10px 0;}
</style>";

// Check 1: Configuration file
echo "<h2>📁 Configuration File</h2>";
if (file_exists(__DIR__ . '/includes/email_config.php')) {
    require_once __DIR__ . '/includes/email_config.php';
    echo "<div class='success'>✅ email_config.php found and loaded</div>";
    
    // Check 2: Basic settings
    echo "<h2>⚙️ SMTP Configuration</h2>";
    echo "<div class='success'>✅ SMTP Host: " . SMTP_HOST . "</div>";
    echo "<div class='success'>✅ SMTP Port: " . SMTP_PORT . "</div>";
    echo "<div class='success'>✅ SMTP Security: " . SMTP_SECURE . "</div>";
    echo "<div class='success'>✅ Username: " . SMTP_USERNAME . "</div>";
    
    $passLength = strlen(SMTP_PASSWORD);
    if ($passLength == 16) {
        echo "<div class='success'>✅ Password: " . str_repeat('*', $passLength) . " (Gmail App Password format: $passLength chars)</div>";
    } elseif ($passLength > 0) {
        echo "<div class='warning'>⚠️ Password: " . str_repeat('*', $passLength) . " ($passLength chars - might not be Gmail App Password)</div>";
    } else {
        echo "<div class='error'>❌ Password: Not set!</div>";
    }
    
    // Check if FROM_EMAIL matches SMTP_USERNAME
    if (FROM_EMAIL == SMTP_USERNAME) {
        echo "<div class='success'>✅ From Email matches Username</div>";
    } else {
        echo "<div class='error'>❌ From Email (" . FROM_EMAIL . ") doesn't match Username (" . SMTP_USERNAME . ")</div>";
    }
    
} else {
    echo "<div class='error'>❌ email_config.php not found!</div>";
    exit;
}

// Check 3: PHPMailer
echo "<h2>📚 PHPMailer</h2>";
if (file_exists(__DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/PHPMailer.php')) {
    echo "<div class='success'>✅ PHPMailer found</div>";
} else {
    echo "<div class='error'>❌ PHPMailer not found</div>";
}

// Check 4: PHP Extensions
echo "<h2>🐘 PHP Extensions</h2>";
echo extension_loaded('openssl') ? "<div class='success'>✅ OpenSSL enabled</div>" : "<div class='error'>❌ OpenSSL disabled</div>";
echo extension_loaded('sockets') ? "<div class='success'>✅ Sockets enabled</div>" : "<div class='warning'>⚠️ Sockets disabled</div>";

// Check 5: Common Issues
echo "<h2>🛠️ Common Issues to Check</h2>";
echo "<div class='warning'>";
echo "<h3>If emails are failing, verify:</h3>";
echo "<ul>";
echo "<li><strong>Gmail 2-Factor Authentication:</strong> Must be enabled before creating App Password</li>";
echo "<li><strong>App Password:</strong> Use 16-character App Password, not regular Gmail password</li>";
echo "<li><strong>IMAP Access:</strong> Enable in Gmail Settings → Forwarding and POP/IMAP</li>";
echo "<li><strong>Firewall/Antivirus:</strong> May block SMTP connections on port 587</li>";
echo "<li><strong>ISP Blocking:</strong> Some ISPs block SMTP ports</li>";
echo "</ul>";
echo "</div>";

// Quick fixes
echo "<h2>🚀 Quick Fixes to Try</h2>";
echo "<div class='warning'>";
echo "<h3>1. Try Alternative Port/Security:</h3>";
echo "<p>Edit <code>includes/email_config.php</code> and change:</p>";
echo "<pre>define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl');</pre>";

echo "<h3>2. Verify Gmail App Password:</h3>";
echo "<ol>";
echo "<li>Go to <a href='https://myaccount.google.com' target='_blank'>Google Account Settings</a></li>";
echo "<li>Security → 2-Step Verification (turn ON)</li>";
echo "<li>Security → App passwords → Generate for 'Mail'</li>";
echo "<li>Copy the 16-character password (no spaces)</li>";
echo "</ol>";

echo "<h3>3. Enable Gmail IMAP:</h3>";
echo "<ol>";
echo "<li>Go to Gmail → Settings (⚙️)</li>";
echo "<li>Forwarding and POP/IMAP</li>";
echo "<li>Enable IMAP access</li>";
echo "</ol>";
echo "</div>";

echo "<h2>🔬 Next Steps</h2>";
echo "<p><strong>1. Run detailed diagnostic:</strong> <a href='smtp_diagnostic.php'>smtp_diagnostic.php</a></p>";
echo "<p><strong>2. Test email sending:</strong> <a href='test_email.php'>test_email.php</a></p>";
echo "<p><strong>3. Check error logs:</strong> C:\\xampp\\apache\\logs\\error.log</p>";
?>
