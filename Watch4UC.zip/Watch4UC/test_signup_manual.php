<?php
echo "<h2>Manual Signup Test Result</h2>";

if ($_POST) {
    echo "<h3>Form Data Received:</h3>";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
    
    // Simulate the signup process
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    echo "<h3>Processing Signup...</h3>";
    
    // Include required files
    try {
        require_once 'config.php';
        
        // Check if user already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingUser) {
            echo "<div style='color: red; background: #ffebee; padding: 10px; border-radius: 5px;'>";
            echo "✗ User with this email or username already exists";
            echo "</div>";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Check if email verification columns exist
            $stmt = $pdo->query("DESCRIBE users");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'Field');
            
            $hasVerificationColumns = in_array('email_verification_token', $columnNames) && 
                                     in_array('email_verification_expires', $columnNames);
            
            if ($hasVerificationColumns) {
                // Insert with email verification
                $verificationToken = bin2hex(random_bytes(32));
                $verificationExpiry = date('Y-m-d H:i:s', time() + 86400);
                
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, balance, email_verified, email_verification_token, email_verification_expires) VALUES (?, ?, ?, 0, 0, ?, ?)");
                $stmt->execute([$username, $email, $hash, $verificationToken, $verificationExpiry]);
                
                echo "<div style='color: green; background: #e8f5e8; padding: 10px; border-radius: 5px;'>";
                echo "✓ User created successfully with email verification token";
                echo "<br><strong>Token:</strong> " . $verificationToken;
                echo "</div>";
                
                // Test email sending (without actually sending)
                echo "<h4>Email Test:</h4>";
                if (file_exists(__DIR__ . '/includes/email_functions.php')) {
                    echo "<div style='color: green;'>✓ Email functions file exists</div>";
                    
                    // Check email configuration
                    if (file_exists(__DIR__ . '/includes/email_config.php')) {
                        require_once __DIR__ . '/includes/email_config.php';
                        if (SMTP_USERNAME !== 'yourrealemail@gmail.com') {
                            echo "<div style='color: green;'>✓ Email appears to be configured</div>";
                            echo "<div style='color: blue; background: #e3f2fd; padding: 10px; border-radius: 5px;'>";
                            echo "Note: Email sending is attempted in the real signup process. Check your email provider settings if emails aren't being received.";
                            echo "</div>";
                        } else {
                            echo "<div style='color: orange; background: #fff3cd; padding: 10px; border-radius: 5px;'>";
                            echo "⚠️ Email not configured - update includes/email_config.php with real email credentials";
                            echo "</div>";
                        }
                    } else {
                        echo "<div style='color: red;'>✗ Email configuration file missing</div>";
                    }
                } else {
                    echo "<div style='color: red;'>✗ Email functions file missing</div>";
                }
                
            } else {
                // Insert without email verification (fallback)
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, balance, email_verified) VALUES (?, ?, ?, 0, 1)");
                $stmt->execute([$username, $email, $hash]);
                
                echo "<div style='color: orange; background: #fff3cd; padding: 10px; border-radius: 5px;'>";
                echo "⚠️ User created without email verification (missing database columns)";
                echo "</div>";
            }
            
            $userId = $pdo->lastInsertId();
            echo "<p><strong>New User ID:</strong> " . $userId . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red; background: #ffebee; padding: 10px; border-radius: 5px;'>";
        echo "✗ Error: " . htmlspecialchars($e->getMessage());
        echo "</div>";
    }
} else {
    echo "<p>No form data received. Please use the test form from the detailed test page.</p>";
}

echo "<hr>";
echo "<p><a href='test_signup_detailed.php'>← Back to Detailed Test</a></p>";
echo "<p><a href='login.html'>Try Real Signup Form</a></p>";
?>
