-- Add email verification token column to users table
-- Run this SQL in your phpMyAdmin

ALTER TABLE users 
ADD COLUMN email_verification_token VARCHAR(64) NULL DEFAULT NULL,
ADD COLUMN email_verification_expires DATETIME NULL DEFAULT NULL;

-- Create index for faster lookups
CREATE INDEX idx_email_verification_token ON users(email_verification_token);

-- Optional: Update existing users to have verified emails (for existing accounts)
-- UPDATE users SET email_verified = 1 WHERE email_verified IS NULL;

-- Clean up expired tokens (can be run periodically)
-- UPDATE users SET email_verification_token = NULL, email_verification_expires = NULL 
-- WHERE email_verification_expires < NOW() AND email_verified = 0;
