<?php
session_start();

echo "<h2>Session and User Data Test</h2>\n";
echo "<h3>Current Session Data:</h3>\n";
echo "<pre>";
print_r($_SESSION);
echo "</pre>\n";

echo "<h3>Testing API Endpoint:</h3>\n";
echo "<p>Calling /api/auth/me.php...</p>\n";

// Test the API endpoint
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost/Watch4UC/api/auth/me.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Cookie: ' . session_name() . '=' . session_id()
));

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "<p>HTTP Code: $httpCode</p>\n";
if ($error) {
    echo "<p>cURL Error: $error</p>\n";
}

echo "<h3>API Response:</h3>\n";
echo "<pre>";
echo htmlspecialchars($response);
echo "</pre>\n";

$data = json_decode($response, true);
if ($data) {
    echo "<h3>Parsed Data:</h3>\n";
    echo "<pre>";
    print_r($data);
    echo "</pre>\n";
}

// Test direct database query if session exists
if (isset($_SESSION['uid'])) {
    require_once 'config.php';
    echo "<h3>Direct Database Query:</h3>\n";
    try {
        $stmt = $pdo->prepare("SELECT id, username, email, role, balance, joined_at FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['uid']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<pre>";
        print_r($user);
        echo "</pre>\n";
    } catch (Exception $e) {
        echo "<p>Database Error: " . $e->getMessage() . "</p>\n";
    }
}

echo "<hr>\n";
echo "<p><a href='auth/login.php'>Test Login</a> | <a href='users/dashboard-dynamic.php'>Go to Dashboard</a></p>\n";
?>
