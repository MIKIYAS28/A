<?php
/**
 * Watch4UC Platform Test Script
 * Run this script to test the basic functionality of your platform
 */

require_once 'config.php';

echo "=== Watch4UC Platform Test ===\n\n";

// Test 1: Database Connection
echo "1. Testing Database Connection...\n";
try {
    $pdo->query("SELECT 1");
    echo "✓ Database connection successful\n\n";
} catch (Exception $e) {
    echo "✗ Database connection failed: " . $e->getMessage() . "\n\n";
    exit(1);
}

// Test 2: Check Required Tables
echo "2. Checking Required Tables...\n";
$required_tables = [
    'users', 'videos', 'daily_tasks', 'user_task_completions', 
    'video_watches', 'referrals', 'notifications', 'withdrawal_requests',
    'transactions', 'redemptions'
];

foreach ($required_tables as $table) {
    try {
        $result = $pdo->query("SELECT COUNT(*) FROM $table");
        $count = $result->fetchColumn();
        echo "✓ Table '$table' exists with $count records\n";
    } catch (Exception $e) {
        echo "✗ Table '$table' missing or error: " . $e->getMessage() . "\n";
    }
}
echo "\n";

// Test 3: Check Admin User
echo "3. Checking Admin User...\n";
try {
    $stmt = $pdo->prepare("SELECT username, role FROM users WHERE role = 'admin' LIMIT 1");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "✓ Admin user found: " . $admin['username'] . "\n";
    } else {
        echo "✗ No admin user found\n";
    }
} catch (Exception $e) {
    echo "✗ Error checking admin user: " . $e->getMessage() . "\n";
}
echo "\n";

// Test 4: Test User Registration
echo "4. Testing User Registration...\n";
$test_username = "test_user_" . time();
$test_email = "test" . time() . "@example.com";
$test_password = "testpass123";

try {
    $hash = password_hash($test_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, balance, email_verified) VALUES (?, ?, ?, 0, 0)");
    $stmt->execute([$test_username, $test_email, $hash]);
    $test_user_id = $pdo->lastInsertId();
    echo "✓ Test user created successfully (ID: $test_user_id)\n";
    
    // Test login
    $stmt = $pdo->prepare("SELECT id, username, role, password_hash, email_verified FROM users WHERE email = ?");
    $stmt->execute([$test_email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($test_password, $user['password_hash'])) {
        echo "✓ Test user login verification successful\n";
    } else {
        echo "✗ Test user login verification failed\n";
    }
    
} catch (Exception $e) {
    echo "✗ User registration test failed: " . $e->getMessage() . "\n";
}
echo "\n";

// Test 5: Test Daily Tasks
echo "5. Testing Daily Tasks...\n";
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM daily_tasks WHERE enabled = 1");
    $active_tasks = $stmt->fetchColumn();
    echo "✓ Found $active_tasks active daily tasks\n";
} catch (Exception $e) {
    echo "✗ Error checking daily tasks: " . $e->getMessage() . "\n";
}
echo "\n";

// Test 6: Test API Endpoints
echo "6. Testing API Endpoints (simulation)...\n";

// Simulate session for API testing
session_start();
if (isset($test_user_id)) {
    $_SESSION['uid'] = $test_user_id;
    $_SESSION['username'] = $test_username;
    $_SESSION['role'] = 'viewer';
    echo "✓ Test session created\n";
} else {
    echo "✗ Could not create test session\n";
}

// Test balance API
try {
    ob_start();
    include 'api/user/balance.php';
    $balance_output = ob_get_clean();
    $balance_data = json_decode($balance_output, true);
    
    if (isset($balance_data['balance'])) {
        echo "✓ Balance API working (Balance: " . $balance_data['balance'] . ")\n";
    } else {
        echo "✗ Balance API failed: " . $balance_output . "\n";
    }
} catch (Exception $e) {
    echo "✗ Balance API error: " . $e->getMessage() . "\n";
}

// Cleanup test user
if (isset($test_user_id)) {
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$test_user_id]);
        echo "✓ Test user cleaned up\n";
    } catch (Exception $e) {
        echo "✗ Error cleaning up test user: " . $e->getMessage() . "\n";
    }
}

echo "\n=== Test Complete ===\n";
echo "If you see mostly ✓ marks, your platform is set up correctly!\n";
echo "If you see ✗ marks, please check the error messages and fix the issues.\n\n";

echo "Next steps:\n";
echo "1. Run the setup_complete_db.sql script in your MySQL database\n";
echo "2. Update config.php with your correct database credentials\n";
echo "3. Set up your web server to serve the HTML files\n";
echo "4. Test the admin login with username: admin, password: admin123\n";
?>
