<?php
session_start();
require_once __DIR__ . '/config.php';

$token = $_GET['token'] ?? '';
$error = '';
$success = '';
$validToken = false;

// Check if token is valid and not expired
if ($token) {
    try {
        // Check if password reset columns exist
        $stmt = $pdo->query("DESCRIBE users");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        $hasResetColumns = in_array('password_reset_token', $columnNames) && 
                          in_array('password_reset_expires', $columnNames);
        
        if (!$hasResetColumns) {
            $error = 'Password reset functionality is not properly configured. Please contact support.';
        } else {
            $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE password_reset_token = ? AND password_reset_expires > NOW()");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                $validToken = true;
            } else {
                // Check if token exists but is expired
                $stmt = $pdo->prepare("SELECT id, username, email, password_reset_expires FROM users WHERE password_reset_token = ?");
                $stmt->execute([$token]);
                $expiredUser = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($expiredUser) {
                    $error = 'This reset token has expired. Password reset tokens are valid for 1 hour. Please request a new password reset.';
                } else {
                    $error = 'Invalid reset token. This token may have been used already or does not exist. Please request a new password reset.';
                }
            }
        }
    } catch (PDOException $e) {
        error_log("Reset password database error: " . $e->getMessage());
        $error = 'Database error occurred. Please try again.';
    }
} else {
    $error = 'No reset token provided.';
}

// Handle password reset form submission
if ($_POST['action'] ?? '' === 'reset_password' && $validToken) {
    $newPassword = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    if (!$newPassword || !$confirmPassword) {
        $error = 'Both password fields are required.';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } elseif (strlen($newPassword) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } else {
        try {
            // Get user information BEFORE updating password and clearing token
            $stmt = $pdo->prepare("SELECT id, username, role FROM users WHERE password_reset_token = ?");
            $stmt->execute([$token]);
            $resetUser = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($resetUser) {
                // Update password and clear reset token
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, password_reset_token = NULL, password_reset_expires = NULL WHERE password_reset_token = ?");
                $stmt->execute([$hashedPassword, $token]);
                
                if ($stmt->rowCount()) {
                    // Password reset successful - now auto-login the user
                    $_SESSION['uid'] = $resetUser['id'];
                    $_SESSION['user_id'] = $resetUser['id'];
                    $_SESSION['username'] = $resetUser['username'];
                    $_SESSION['role'] = $resetUser['role'];
                    
                    $success = 'Password reset successful! Redirecting to your dashboard...';
                    $autoRedirect = true;
                    $validToken = false; // Prevent further form submissions
                } else {
                    $error = 'Failed to reset password. Please try again.';
                }
            } else {
                $error = 'Failed to reset password. Please try again.';
            }
        } catch (PDOException $e) {
            $error = 'Database error occurred. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Watch4UC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #357ABD;
            --background: #ffffff;
            --foreground: #111827;
            --gray: #e5e7eb;
            --gray-2: #4b5563;
        }

        html.dark {
            --primary-color: #FFD700;
            --secondary-color: #7790ef;
            --background: #121212;
            --foreground: #ffffff;
            --gray: #333333;
            --gray-2: #aaaaaa;
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        body {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--foreground);
        }

        .container {
            background: var(--background);
            padding: 2rem;
            border-radius: 1.5rem;
            box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
            width: 100%;
            max-width: 400px;
            margin: 20px;
        }

        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo h1 {
            color: var(--primary-color);
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .logo p {
            color: var(--gray-2);
            font-size: 1rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--foreground);
        }

        .input-group {
            position: relative;
            width: 100%;
        }

        .input-group i {
            position: absolute;
            top: 50%;
            left: 1rem;
            transform: translateY(-50%);
            font-size: 1.2rem;
            color: var(--gray-2);
        }

        .input-group input {
            width: 100%;
            padding: 1rem 3rem;
            font-size: 1rem;
            background-color: var(--gray);
            border-radius: 0.5rem;
            border: 0.125rem solid var(--gray);
            outline: none;
            color: var(--foreground);
            transition: border-color 0.3s ease;
        }

        .input-group input:focus {
            border-color: var(--primary-color);
        }

        .btn {
            cursor: pointer;
            width: 100%;
            border: none;
            padding: 1rem 0;
            border-radius: 0.5rem;
            background-color: var(--primary-color);
            color: #ffffff;
            font-size: 1.2rem;
            font-weight: 600;
            outline: none;
            transition: background-color 0.3s ease;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #e6c200;
        }

        .btn:disabled {
            background-color: var(--gray-2);
            cursor: not-allowed;
        }

        .error {
            background: #fee2e2;
            color: #dc2626;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            border-left: 4px solid #dc2626;
        }

        .success {
            background: #d1fae5;
            color: #059669;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            border-left: 4px solid #059669;
        }

        .back-link {
            text-align: center;
            margin-top: 1.5rem;
        }

        .back-link a {
            color: var(--secondary-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .back-link a:hover {
            color: var(--primary-color);
        }

        .password-requirements {
            font-size: 0.85rem;
            color: var(--gray-2);
            margin-top: 0.5rem;
        }

        .icon-success {
            color: #059669;
            font-size: 3rem;
            text-align: center;
            margin-bottom: 1rem;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }

        .toggle {
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
            transition: transform 0.3s ease;
            width: 48px;
            height: 48px;
            position: relative;
        }

        .toggle:hover {
            transform: scale(1.05);
        }

        .toggle .face {
            position: relative;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: var(--background);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease;
        }

        .toggle .face:before {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(-45deg, var(--primary-color), var(--secondary-color));
            opacity: 0.7;
            transition: opacity 0.3s ease;
        }

        .toggle svg {
            position: relative;
            width: 24px;
            height: 24px;
            z-index: 2;
            color: var(--foreground);
        }

        .hide {
            display: none;
        }
    </style>
</head>
<body>
    <div class="theme-toggle">
        <button aria-pressed="false" class="toggle" id="themeToggle">
            <div class="face">
                <svg id="darkIcon" class="hide" viewBox="0 0 24 24" fill="none">
                    <path d="M12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="currentColor"/>
                    <path d="M12 2V4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M12 20V22" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M4.93 4.93L6.34 6.34" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M17.66 17.66L19.07 19.07" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M2 12H4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M20 12H22" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M6.34 17.66L4.93 19.07" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M19.07 4.93L17.66 6.34" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <svg id="lightIcon" viewBox="0 0 24 24" fill="none">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" fill="currentColor"/>
                </svg>
            </div>
            <span class="sr-only">Toggle Theme</span>
        </button>
    </div>

    <div class="container">
        <div class="logo">
            <h1>Watch4UC</h1>
            <p>Reset Your Password</p>
        </div>

        <?php if ($error): ?>
            <div class="error">
                <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success">
                <div class="icon-success">
                    <i class="fas fa-check-circle"></i>
                </div>
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <?php if ($validToken && !$success): ?>
            <form method="POST">
                <input type="hidden" name="action" value="reset_password">
                
                <div class="form-group">
                    <label for="password">New Password</label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Enter new password" required>
                    </div>
                    <div class="password-requirements">
                        Password must be at least 6 characters long
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password" required>
                    </div>
                </div>

                <button type="submit" class="btn">
                    <i class="fas fa-key"></i> Reset Password
                </button>
            </form>
        <?php endif; ?>

        <div class="back-link">
            <a href="login.html">
                <i class="fas fa-arrow-left"></i> Back to Login
            </a>
        </div>
    </div>

    <script>
        // Theme toggle functionality
        const themeToggle = document.getElementById('themeToggle');
        const darkIcon = document.getElementById('darkIcon');
        const lightIcon = document.getElementById('lightIcon');
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

        if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
            document.documentElement.classList.add('dark');
            lightIcon.style.display = 'none';
            darkIcon.style.display = 'block';
        } else {
            document.documentElement.classList.remove('dark');
            lightIcon.style.display = 'block';
            darkIcon.style.display = 'none';
        }

        themeToggle.addEventListener('click', () => {
            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('theme', 'light');
                lightIcon.style.display = 'block';
                darkIcon.style.display = 'none';
            } else {
                document.documentElement.classList.add('dark');
                localStorage.setItem('theme', 'dark');
                lightIcon.style.display = 'none';
                darkIcon.style.display = 'block';
            }
        });

        // Auto redirect after successful reset
        <?php if (isset($autoRedirect) && $autoRedirect): ?>
            setTimeout(() => {
                window.location.href = 'users/Dashboard.html';
            }, 2000);
        <?php elseif ($success): ?>
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 3000);
        <?php endif; ?>

        // Password confirmation validation
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');

        if (confirmPassword) {
            confirmPassword.addEventListener('input', function() {
                if (password.value !== confirmPassword.value) {
                    confirmPassword.setCustomValidity('Passwords do not match');
                } else {
                    confirmPassword.setCustomValidity('');
                }
            });
        }
    </script>
</body>
</html>
