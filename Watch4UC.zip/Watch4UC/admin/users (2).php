<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        /* ---- Admin-only access check (optional but recommended) ---- */
fetch('../api/auth/me.php')   // we’ll create this next
  .then(r => r.json())
  .then(d => { if(!d.loggedIn || d.role!=='admin') location.href='../user/login.html'; });
  </script>
    <style>
        /* ... (existing styles remain unchanged) ... */
     /* Existing styles from the video dashboard */
        :root {
            --primary: #4a90e2;
            --secondary: #357abd;
            --accent: #ff6b6b;
            --dark: #1a202c;
            --light: #f7fafc;
            --success: #48bb78;
            --warning: #ecc94b;
            --danger: #e53e3e;
            --gray: #718096;
            --gray-light: #e2e8f0;
            --sidebar-width: 260px;
            --header-height: 70px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: var(--dark);
            display: flex;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
            transition: all 0.3s;
            z-index: 100;
        }

        .logo {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .nav-links {
            padding: 0 15px;
        }

        .nav-links li {
            list-style: none;
            margin-bottom: 5px;
        }

        .nav-links a {
            color: #cbd5e0;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            transition: all 0.3s;
        }

        .nav-links a:hover, .nav-links a.active {
            background: rgba(74, 144, 226, 0.2);
            color: white;
        }

        .nav-links i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
        }

        /* Header Styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .header-actions {
            display: flex;
            gap: 15px;
        }

        .search-box {
            position: relative;
        }

        .search-box input {
            padding: 10px 15px 10px 40px;
            border-radius: 50px;
            border: 1px solid var(--gray-light);
            width: 250px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        .user-info h4 {
            font-size: 15px;
            font-weight: 600;
        }

        .user-info p {
            font-size: 13px;
            color: var(--gray);
        }

        /* Stats Section */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .stat-info h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: var(--gray);
            font-size: 14px;
        }

        .bg-blue {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
        }

        .bg-green {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success);
        }

        .bg-orange {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .bg-red {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        .bg-purple {
            background: rgba(159, 122, 234, 0.1);
            color: #9f7aea;
        }

        /* Charts Section */
        .charts-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .chart-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-title h3 {
            font-size: 18px;
            font-weight: 600;
        }

        .chart-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .chart-controls {
            display: flex;
            gap: 10px;
        }

        .chart-btn {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            background: var(--gray-light);
            border: none;
            cursor: pointer;
        }

        .chart-btn.active {
            background: var(--primary);
            color: white;
        }

        .chart-wrapper {
            height: 250px;
            position: relative;
        }

        /* User Table Section */
        .users-container {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .controls {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            border: none;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--secondary);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--gray-light);
            color: var(--gray);
        }

        .btn-outline:hover {
            background: var(--gray-light);
        }

        .filter-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-group label {
            font-size: 14px;
            color: var(--gray);
            font-weight: 500;
        }

        .filter-group select, .filter-group input {
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid var(--gray-light);
            background: white;
            min-width: 150px;
        }

        .filter-group input {
            padding-left: 35px;
        }

        .search-control {
            position: relative;
        }

        .search-control i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8fafc;
            border-bottom: 2px solid var(--gray-light);
        }

        th {
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 14px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid var(--gray-light);
            font-size: 14px;
        }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--gray-light);
            overflow: hidden;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            background-color: var(--primary);
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            margin-bottom: 3px;
        }

        .user-email {
            color: var(--gray);
            font-size: 13px;
        }

        .status {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
        }

        .status-active {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success);
        }

        .status-inactive {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        .status-pending {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .role {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 500;
        }

        .role-admin {
            background: rgba(159, 122, 234, 0.1);
            color: #9f7aea;
        }

        .role-content-creator {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary);
        }

        .role-viewer {
            background: rgba(236, 201, 75, 0.1);
            color: var(--warning);
        }

        .role-moderator {
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            background: transparent;
            color: var(--gray);
        }

        .action-btn:hover {
            background: var(--gray-light);
            color: var(--dark);
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--gray-light);
        }

        .page-info {
            color: var(--gray);
            font-size: 14px;
        }

        .page-controls {
            display: flex;
            gap: 8px;
        }

        .page-btn {
            width: 36px;
            height: 36px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border: 1px solid var(--gray-light);
            cursor: pointer;
            transition: all 0.3s;
        }

        .page-btn:hover, .page-btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        /* User Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .modal-header {
            padding: 20px;
            background: var(--primary);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            font-size: 18px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background 0.3s;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.2);
        }

        .modal-body {
            padding: 20px;
            max-height: 70vh;
            overflow-y: auto;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border-radius: 6px;
            border: 1px solid var(--gray-light);
            font-size: 14px;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .modal-footer {
            padding: 15px 20px;
            background: #f8fafc;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid var(--gray-light);
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
            }
            
            .logo h1 span, .nav-links a span {
                display: none;
            }
            
            .logo h1 {
                justify-content: center;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 12px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .search-box input {
                width: 100%;
            }
            
            .stats-container {
                grid-template-columns: 1fr 1fr;
            }
            
            .filter-controls {
                flex-direction: column;
            }
            
            .controls {
                flex-wrap: wrap;
            }
            
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .page-controls {
                display: none;
            }
            
            .pagination {
                justify-content: center;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <h1><i class="fas fa-play-circle"></i> <span>VideoDash</span></h1>
        </div>
        <ul class="nav-links">
            <li><a href="#"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="add video.html"><i class="fas fa-video"></i> <span>Videos</span></a></li>
            <li><a href="users.html" class="active"><i class="fas fa-users"></i> <span>Users</span></a></li>
            <li><a href="new-users.html"><i class="fas fa-user-plus"></i> <span>New Users</span></a></li>
            <li><a href="analytics.html"><i class="fas fa-chart-line"></i> <span>Analytics</span></a></li>
            <li><a href="redemptions.html"><i class="fas fa-gift"></i> <span>Redemptions</span></a></li>
            <li><a href="tasks.html"><i class="fas fa-tasks"></i> <span>Tasks</span></a></li>
            <li><a href="rewards.html"><i class="fas fa-coins"></i> <span>Rewards</span></a></li>
            <li><a href="setting.html"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
            <li><a href="security.html"><i class="fas fa-lock"></i> <span>Security</span></a></li>
            <li><a href="alerts.html"><i class="fas fa-exclamation-triangle"></i> <span>Alerts</span></a></li>
            <li><a href="database.html"><i class="fas fa-database"></i> <span>Database</span></a></li>
            <li><a href="integration.html"><i class="fas fa-plug"></i> <span>Integrations</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <h1>User Management</h1>
                <p>Manage and analyze your user base</p>
            </div>
            <div class="header-actions">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search users...">
                </div>
                <div class="user-profile">
                    <img src="https://randomuser.me/api/portraits/men/41.jpg" alt="Admin">
                    <div class="user-info">
                        <h4>Admin User</h4>
                        <p>User Manager</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Section - Updated to use API data -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon bg-blue">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalUsers">24,850</h3>
                    <p>Total Users</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-green">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="stat-info">
                    <h3 id="adminUsers">365</h3>
                    <p>Admins</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-orange">
                    <i class="fas fa-user-plus"></i>
                </div>
                <div class="stat-info">
                    <h3 id="newUsers">1,248</h3>
                    <p>New Users (30d)</p>
                </div>
            </div>
        </div>

        <!-- Users Table Section -->
        <div class="users-container">
            <div class="section-header">
                <div class="section-title">
                    <h2>All Users</h2>
                    <p>Manage your user accounts</p>
                </div>
            </div>

            <!-- Users Table -->
            <div class="table-container">
                <table id="userTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Joined At</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                        <!-- Table rows will be populated by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Function to load user data
        async function loadUserData() {
            try {
                // Load stats
                const statsResponse = await fetch('../api/admin/stats.php');
                const statsData = await statsResponse.json();
                
                // Update stats cards
                document.getElementById('totalUsers').textContent = statsData.total;
                document.getElementById('adminUsers').textContent = statsData.admins;
                document.getElementById('newUsers').textContent = statsData.new30;
                
                // Load users
                const usersResponse = await fetch('../api/admin/list_users.php');
                const usersData = await usersResponse.json();
                
                // Populate table
                const tableBody = document.getElementById('userTableBody');
                tableBody.innerHTML = '';
                
                usersData.forEach(user => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${user.id}</td>
                        <td>
                            <div class="user-cell">
                                <div class="user-avatar" style="background-color: ${getRandomColor(user.username)};">
                                    ${getInitials(user.username)}
                                </div>
                                <div class="user-info">
                                    <div class="user-name">${user.username}</div>
                                </div>
                            </div>
                        </td>
                        <td>${user.email}</td>
                        <td><span class="role role-${getRoleClass(user.role)}">${user.role}</span></td>
                        <td>${formatDate(user.joined_at)}</td>
                    `;
                    tableBody.appendChild(row);
                });
                
                // Add hover effect to table rows
                const tableRows = document.querySelectorAll('#userTableBody tr');
                tableRows.forEach(row => {
                    row.addEventListener('mouseenter', function() {
                        this.style.backgroundColor = '#f8fafc';
                    });
                    row.addEventListener('mouseleave', function() {
                        this.style.backgroundColor = '';
                    });
                });
                
            } catch (error) {
                console.error('Error loading user data:', error);
                // Show error message
                document.getElementById('userTableBody').innerHTML = `
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--danger); padding: 20px;">
                            <i class="fas fa-exclamation-triangle"></i> Failed to load user data. Please try again later.
                        </td>
                    </tr>
                `;
            }
        }

        // Helper functions
        function getInitials(username) {
            return username.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        }

        function getRandomColor(username) {
            const colors = ['#4a90e2', '#9f7aea', '#48bb78', '#ecc94b', '#e53e3e', '#667eea'];
            const index = username.charCodeAt(0) % colors.length;
            return colors[index];
        }

        function getRoleClass(role) {
            const roleMap = {
                'admin': 'admin',
                'content creator': 'content-creator',
                'viewer': 'viewer',
                'moderator': 'moderator'
            };
            return roleMap[role.toLowerCase()] || 'viewer';
        }

        function formatDate(dateString) {
            const options = { year: 'numeric', month: 'short', day: 'numeric' };
            return new Date(dateString).toLocaleDateString(undefined, options);
        }

        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#userTableBody tr');
            
            rows.forEach(row => {
                const username = row.cells[1].textContent.toLowerCase();
                const email = row.cells[2].textContent.toLowerCase();
                const role = row.cells[3].textContent.toLowerCase();
                
                if (username.includes(searchTerm) || 
                    email.includes(searchTerm) || 
                    role.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            loadUserData();
        });
    </script>
</body>
</html>