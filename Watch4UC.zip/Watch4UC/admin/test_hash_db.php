<?php
require_once __DIR__ . '/../../config.php'; // adjust if config.php is one dir up
$stmt = $pdo->prepare("SELECT password FROM users WHERE LOWER(username) = 'surafel' LIMIT 1");
$stmt->execute();
$row = $stmt->fetch();
if (!$row) { die("No admin user found"); }
$ok = password_verify("Sura12,3#@!", $row['password']);
echo $ok ? "DB hash matches ✅" : "DB hash does NOT match ❌";
