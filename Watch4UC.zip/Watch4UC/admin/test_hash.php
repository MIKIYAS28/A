<?php
$input = "Sura12,3#@!";
$hash = '$2y$10$hIyxSWmQ5K1xBTrjQepkAOUwNTl0rGmU6Dw0kj3z3guYhD1TkBgcK';

if (password_verify($input, $hash)) {
    echo "Password matches!";
} else {
    echo "Password does NOT match!";
}
