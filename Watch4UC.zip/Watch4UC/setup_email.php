<?php
echo "<h2>📧 Email Configuration Setup</h2>";

require_once 'config.php';

// Check current email configuration
$configFile = __DIR__ . '/includes/email_config.php';
if (file_exists($configFile)) {
    require_once $configFile;
    
    echo "<h3>Current Email Settings:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Setting</th><th>Current Value</th><th>Status</th></tr>";
    
    $settings = [
        'SMTP_HOST' => SMTP_HOST,
        'SMTP_PORT' => SMTP_PORT,
        'SMTP_USERNAME' => SMTP_USERNAME,
        'SMTP_PASSWORD' => SMTP_PASSWORD,
        'FROM_EMAIL' => FROM_EMAIL,
        'FROM_NAME' => FROM_NAME,
    ];
    
    $isConfigured = true;
    foreach ($settings as $key => $value) {
        $status = '';
        if ($key === 'SMTP_USERNAME' || $key === 'FROM_EMAIL') {
            if ($value === 'yourrealemail@gmail.com') {
                $status = "<span style='color: red;'>❌ Needs Configuration</span>";
                $isConfigured = false;
            } else {
                $status = "<span style='color: green;'>✅ Configured</span>";
            }
        } elseif ($key === 'SMTP_PASSWORD') {
            if ($value === 'tvmenidragkwmebr') {
                $status = "<span style='color: red;'>❌ Using Default</span>";
                $isConfigured = false;
            } else {
                $status = "<span style='color: green;'>✅ Set</span>";
            }
            $value = str_repeat('*', strlen($value)); // Hide password
        } else {
            $status = "<span style='color: green;'>✅ OK</span>";
        }
        
        echo "<tr><td><strong>$key</strong></td><td>$value</td><td>$status</td></tr>";
    }
    echo "</table>";
    
    if (!$isConfigured) {
        echo "<div style='color: orange; background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
        echo "<h3>⚠️ Email Not Configured</h3>";
        echo "<p>Your email settings are still using placeholder values. This is why activation emails aren't being sent.</p>";
        echo "</div>";
    } else {
        echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
        echo "<h3>✅ Email Configured</h3>";
        echo "<p>Your email settings appear to be configured. If emails still aren't sending, check the test below.</p>";
        echo "</div>";
    }
}

// Test email sending
if (isset($_POST['test_email'])) {
    $testEmail = trim($_POST['email']);
    
    if (!filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
        echo "<div style='color: red;'>❌ Invalid email address</div>";
    } else {
        echo "<h3>Testing Email Send...</h3>";
        
        try {
            require_once __DIR__ . '/includes/email_functions.php';
            
            // Create a test activation token
            $testToken = bin2hex(random_bytes(32));
            
            // Try to send test activation email
            $result = sendActivationEmail($testEmail, 'TestUser', $testToken);
            
            if ($result) {
                echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
                echo "<h4>✅ Test Email Sent Successfully!</h4>";
                echo "<p>Check <strong>$testEmail</strong> for the test activation email.</p>";
                echo "<p><small>Note: Check spam folder if you don't see it in inbox.</small></p>";
                echo "</div>";
            } else {
                echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
                echo "<h4>❌ Test Email Failed</h4>";
                echo "<p>The email could not be sent. Check your email configuration and error logs.</p>";
                echo "</div>";
            }
        } catch (Exception $e) {
            echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
            echo "<h4>❌ Email Error</h4>";
            echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
            echo "</div>";
        }
    }
}

echo "<hr>";
echo "<h3>📝 How to Configure Email (Gmail Example):</h3>";
echo "<div style='background: #f5f5f5; padding: 15px; border-radius: 5px;'>";
echo "<ol>";
echo "<li><strong>Use Gmail:</strong> Create or use an existing Gmail account</li>";
echo "<li><strong>Enable 2-Factor Authentication:</strong> Go to Google Account → Security → 2-Step Verification</li>";
echo "<li><strong>Generate App Password:</strong> Google Account → Security → App passwords → Generate new</li>";
echo "<li><strong>Update Configuration:</strong> Edit <code>includes/email_config.php</code> with:</li>";
echo "</ol>";
echo "<pre style='background: #e9ecef; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
echo "define('SMTP_USERNAME', 'your-gmail@gmail.com');
define('SMTP_PASSWORD', 'your-16-character-app-password');
define('FROM_EMAIL', 'your-gmail@gmail.com');
define('FROM_NAME', 'Watch4UC Team');";
echo "</pre>";
echo "</div>";

echo "<h3>🧪 Test Email Sending:</h3>";
echo "<form method='post'>";
echo "<p>Enter your email to test if email sending works:</p>";
echo "<p><input type='email' name='email' placeholder='your-email@gmail.com' required style='padding: 10px; width: 300px;'></p>";
echo "<p><button type='submit' name='test_email' style='padding: 10px 20px; background: #007cba; color: white; border: none; border-radius: 5px;'>📧 Send Test Email</button></p>";
echo "</form>";

echo "<hr>";
echo "<h3>🔧 Alternative: Skip Email Verification</h3>";
echo "<p>If you don't want to set up email, you can manually verify users in the database:</p>";

// Show unverified users
try {
    $stmt = $pdo->query("SELECT id, username, email, email_verified, joined_at FROM users WHERE email_verified = 0 ORDER BY joined_at DESC LIMIT 10");
    $unverifiedUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($unverifiedUsers)) {
        echo "<h4>Unverified Users:</h4>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Created</th><th>Action</th></tr>";
        
        foreach ($unverifiedUsers as $user) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . htmlspecialchars($user['username']) . "</td>";
            echo "<td>" . htmlspecialchars($user['email']) . "</td>";
            echo "<td>" . $user['joined_at'] . "</td>";
            echo "<td><a href='?verify=" . $user['id'] . "'>✅ Manually Verify</a></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No unverified users found.</p>";
    }
    
    // Handle manual verification
    if (isset($_GET['verify']) && is_numeric($_GET['verify'])) {
        $userId = (int)$_GET['verify'];
        $stmt = $pdo->prepare("UPDATE users SET email_verified = 1 WHERE id = ?");
        $stmt->execute([$userId]);
        
        if ($stmt->rowCount() > 0) {
            echo "<div style='color: green; background: #e8f5e8; padding: 10px; border-radius: 5px;'>";
            echo "✅ User manually verified! They can now log in.";
            echo "</div>";
            echo "<meta http-equiv='refresh' content='2'>";
        }
    }
    
} catch (Exception $e) {
    echo "<div style='color: red;'>Database error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "<hr>";
echo "<p><strong>Next Steps:</strong></p>";
echo "<ul>";
echo "<li><a href='login.html'>🔗 Try Login/Signup Again</a></li>";
echo "<li><a href='test_signup_detailed.php'>🔍 Run Detailed Test</a></li>";
echo "<li><a href='cleanup_test_users.php'>🗑️ Clean Up Test Users</a></li>";
echo "</ul>";
?>
