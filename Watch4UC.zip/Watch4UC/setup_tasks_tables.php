<?php
require_once 'config.php';

echo "Setting up daily tasks tables...\n";
echo "================================\n\n";

try {
    // Create daily_tasks table
    echo "Creating daily_tasks table...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS daily_tasks (
            id INT PRIMARY KEY AUTO_INCREMENT,
            type VARCHAR(50) NOT NULL,
            subtype VARCHAR(50),
            title VARCHAR(255) NOT NULL,
            description TEXT,
            reward INT NOT NULL DEFAULT 0,
            count INT DEFAULT 1,
            progress INT DEFAULT 0,
            enabled BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");
    echo "✅ daily_tasks table created\n";

    // Create task_completions table
    echo "Creating task_completions table...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS task_completions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            task_id INT NOT NULL,
            completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (task_id) REFERENCES daily_tasks(id) ON DELETE CASCADE,
            UNIQUE KEY unique_completion (user_id, task_id)
        )
    ");
    echo "✅ task_completions table created\n";

    // Insert sample daily tasks
    echo "Inserting sample daily tasks...\n";
    
    $sample_tasks = [
        // Video tasks
        ['video', 'watch', 'Watch Gaming Video #1', 'Watch a gaming video to earn coins', 5],
        ['video', 'watch', 'Watch Gaming Video #2', 'Watch another gaming video to earn more coins', 5],
        ['video', 'watch', 'Watch Tutorial Video', 'Watch an educational video', 10],
        
        // Social tasks
        ['social', 'facebook', 'Like our Facebook Page', 'Follow us on Facebook for updates', 15],
        ['social', 'instagram', 'Follow on Instagram', 'Follow our Instagram account', 15],
        ['social', 'youtube', 'Subscribe to YouTube', 'Subscribe to our YouTube channel', 20],
        
        // Referral tasks
        ['referral', 'share', 'Share Referral Link', 'Share your referral link to earn coins', 50],
        ['referral', 'invite', 'Invite 5 Friends', 'Invite 5 friends to join the platform', 100]
    ];
    
    // Clear existing sample tasks first
    $pdo->exec("DELETE FROM daily_tasks WHERE id <= 10");
    
    $stmt = $pdo->prepare("
        INSERT INTO daily_tasks (type, subtype, title, description, reward) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    foreach ($sample_tasks as $task) {
        $stmt->execute($task);
    }
    echo "✅ Sample tasks inserted\n";

    echo "\nDatabase setup complete!\n";
    echo "You can now view daily tasks on your dashboard.\n";

} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
