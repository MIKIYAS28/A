<?php
echo "<h2>Clean Up Test Users</h2>";

require_once 'config.php';

try {
    // Show existing test users
    echo "<h3>Current test users in database:</h3>";
    $stmt = $pdo->query("SELECT id, username, email, email_verified, joined_at FROM users WHERE username LIKE 'testuser%' OR email LIKE 'test%@example.com' ORDER BY id DESC");
    $testUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($testUsers)) {
        echo "<p>No test users found.</p>";
    } else {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Verified</th><th>Created</th><th>Action</th></tr>";
        
        foreach ($testUsers as $user) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . htmlspecialchars($user['username']) . "</td>";
            echo "<td>" . htmlspecialchars($user['email']) . "</td>";
            echo "<td>" . ($user['email_verified'] ? 'Yes' : 'No') . "</td>";
            echo "<td>" . $user['joined_at'] . "</td>";
            echo "<td><a href='?delete=" . $user['id'] . "' onclick='return confirm(\"Delete this user?\")'>Delete</a></td>";
            echo "</tr>";
        }
        echo "</table>";
        
        echo "<p><a href='?delete_all=1' onclick='return confirm(\"Delete ALL test users?\")' style='color: red;'>🗑️ Delete All Test Users</a></p>";
    }
    
    // Handle deletion
    if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
        $userId = (int)$_GET['delete'];
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND (username LIKE 'testuser%' OR email LIKE 'test%@example.com')");
        $stmt->execute([$userId]);
        
        if ($stmt->rowCount() > 0) {
            echo "<div style='color: green; background: #e8f5e8; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Test user deleted successfully!";
            echo "</div>";
            echo "<meta http-equiv='refresh' content='2'>";
        } else {
            echo "<div style='color: red;'>❌ Could not delete user (not a test user or doesn't exist)</div>";
        }
    }
    
    if (isset($_GET['delete_all'])) {
        $stmt = $pdo->query("DELETE FROM users WHERE username LIKE 'testuser%' OR email LIKE 'test%@example.com'");
        $deletedCount = $stmt->rowCount();
        
        echo "<div style='color: green; background: #e8f5e8; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ Deleted $deletedCount test users!";
        echo "</div>";
        echo "<meta http-equiv='refresh' content='2'>";
    }
    
    // Show all users count
    echo "<h3>Database Summary:</h3>";
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p><strong>Total users in database:</strong> $totalUsers</p>";
    
} catch (Exception $e) {
    echo "<div style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "<hr>";
echo "<h3>Test Signup Now:</h3>";
echo "<p><a href='login.html'>🔗 Go to Login/Signup Page</a></p>";
echo "<p><a href='test_signup_detailed.php'>🔍 Run Detailed Test</a></p>";
?>
