<?php
// Test Email Functionality
// Make sure to update email_config.php with your SMTP settings before running this test

require_once __DIR__ . '/includes/email_functions.php';

echo "<h2>Testing Email Functionality</h2>";

// Test email settings
echo "<h3>Email Configuration:</h3>";
echo "SMTP Host: " . SMTP_HOST . "<br>";
echo "SMTP Port: " . SMTP_PORT . "<br>";
echo "SMTP Secure: " . SMTP_SECURE . "<br>";
echo "From Email: " . FROM_EMAIL . "<br>";
echo "From Name: " . FROM_NAME . "<br>";
echo "Site Name: " . SITE_NAME . "<br>";
echo "<hr>";

if ($_POST['action'] ?? '' === 'test_welcome') {
    $testEmail = $_POST['email'] ?? '';
    $testUsername = $_POST['username'] ?? 'TestUser';
    
    if (!$testEmail) {
        echo "<p style='color: red;'>Please enter an email address!</p>";
    } else {
        echo "<h3>Sending Welcome Email...</h3>";
        $result = sendWelcomeEmail($testEmail, $testUsername);
        
        if ($result) {
            echo "<p style='color: green;'>✅ Welcome email sent successfully to: $testEmail</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to send welcome email. Check your SMTP settings and error logs.</p>";
        }
    }
    echo "<hr>";
}

if ($_POST['action'] ?? '' === 'test_login') {
    $testEmail = $_POST['email'] ?? '';
    $testUsername = $_POST['username'] ?? 'TestUser';
    
    if (!$testEmail) {
        echo "<p style='color: red;'>Please enter an email address!</p>";
    } else {
        echo "<h3>Sending Welcome Back Email...</h3>";
        $result = sendWelcomeBackEmail($testEmail, $testUsername);
        
        if ($result) {
            echo "<p style='color: green;'>✅ Welcome back email sent successfully to: $testEmail</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to send welcome back email. Check your SMTP settings and error logs.</p>";
        }
    }
    echo "<hr>";
}

if ($_POST['action'] ?? '' === 'test_reset') {
    $testEmail = $_POST['email'] ?? '';
    $testUsername = $_POST['username'] ?? 'TestUser';
    $testToken = bin2hex(random_bytes(32)); // Generate test token
    
    if (!$testEmail) {
        echo "<p style='color: red;'>Please enter an email address!</p>";
    } else {
        echo "<h3>Sending Password Reset Email...</h3>";
        $result = sendPasswordResetEmail($testEmail, $testUsername, $testToken);
        
        if ($result) {
            echo "<p style='color: green;'>✅ Password reset email sent successfully to: $testEmail</p>";
            echo "<p style='color: orange;'>🔗 Test reset link: <a href='reset_password.php?token=$testToken' target='_blank'>Click here</a></p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to send password reset email. Check your SMTP settings and error logs.</p>";
        }
    }
    echo "<hr>";
}

if ($_POST['action'] ?? '' === 'test_activation') {
    $testEmail = $_POST['email'] ?? '';
    $testUsername = $_POST['username'] ?? 'TestUser';
    $testToken = bin2hex(random_bytes(32)); // Generate test token
    
    if (!$testEmail) {
        echo "<p style='color: red;'>Please enter an email address!</p>";
    } else {
        echo "<h3>Sending Account Activation Email...</h3>";
        $result = sendActivationEmail($testEmail, $testUsername, $testToken);
        
        if ($result) {
            echo "<p style='color: green;'>✅ Activation email sent successfully to: $testEmail</p>";
            echo "<p style='color: orange;'>🔗 Test activation link: <a href='activate_account.php?token=$testToken' target='_blank'>Click here</a></p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to send activation email. Check your SMTP settings and error logs.</p>";
        }
    }
    echo "<hr>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Email Test - Watch4UC</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        form { background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0; }
        input, button { padding: 10px; margin: 5px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #007cba; color: white; cursor: pointer; }
        button:hover { background: #005a87; }
        .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="warning">
        <strong>⚠️ Important:</strong> Before testing, make sure to update the email settings in 
        <code>includes/email_config.php</code> with your actual SMTP credentials!
    </div>

    <h3>Test Welcome Email (Signup)</h3>
    <form method="POST">
        <input type="hidden" name="action" value="test_welcome">
        <input type="email" name="email" placeholder="Enter test email address" required style="width: 300px;">
        <input type="text" name="username" placeholder="Enter test username" value="TestUser" style="width: 200px;">
        <button type="submit">Send Welcome Email</button>
    </form>

    <h3>Test Welcome Back Email (Login)</h3>
    <form method="POST">
        <input type="hidden" name="action" value="test_login">
        <input type="email" name="email" placeholder="Enter test email address" required style="width: 300px;">
        <input type="text" name="username" placeholder="Enter test username" value="TestUser" style="width: 200px;">
        <button type="submit">Send Welcome Back Email</button>
    </form>

    <h3>Test Password Reset Email (Forgot Password)</h3>
    <form method="POST">
        <input type="hidden" name="action" value="test_reset">
        <input type="email" name="email" placeholder="Enter test email address" required style="width: 300px;">
        <input type="text" name="username" placeholder="Enter test username" value="TestUser" style="width: 200px;">
        <button type="submit">Send Password Reset Email</button>
    </form>

    <h3>Test Account Activation Email (Email Verification)</h3>
    <form method="POST">
        <input type="hidden" name="action" value="test_activation">
        <input type="email" name="email" placeholder="Enter test email address" required style="width: 300px;">
        <input type="text" name="username" placeholder="Enter test username" value="TestUser" style="width: 200px;">
        <button type="submit">Send Activation Email</button>
    </form>

    <h3>Setup Instructions:</h3>
    <ol>
        <li><strong>Update Email Settings:</strong> Edit <code>includes/email_config.php</code> with your SMTP provider details</li>
        <li><strong>Gmail Users:</strong> Enable 2FA and create an App Password</li>
        <li><strong>Other Providers:</strong> Update SMTP host, port, and security settings accordingly</li>
        <li><strong>Test:</strong> Use the forms above to test email sending</li>
        <li><strong>Production:</strong> Remove or secure this test file before going live</li>
    </ol>

    <h3>Common SMTP Providers:</h3>
    <ul>
        <li><strong>Gmail:</strong> smtp.gmail.com:587 (TLS) or smtp.gmail.com:465 (SSL)</li>
        <li><strong>Yahoo:</strong> smtp.mail.yahoo.com:587 (TLS)</li>
        <li><strong>Outlook:</strong> smtp-mail.outlook.com:587 (TLS)</li>
        <li><strong>Custom/VPS:</strong> Check with your hosting provider</li>
    </ul>
</body>
</html>
