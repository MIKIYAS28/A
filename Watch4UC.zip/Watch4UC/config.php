<?php
// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    // Configure session for better security and path handling
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.cookie_path', '/');
    
    session_start();
}

$pdo = new PDO("mysql:host=localhost;dbname=watch4uc", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
