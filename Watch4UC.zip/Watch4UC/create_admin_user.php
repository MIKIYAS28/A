<?php
// Script to create the admin user with secure password hash
require_once 'config.php';

$username = 'surafel';
$password = '8suraman"50@$&8';
$email = 'surafel@watch4uc.com';
$role = 'admin';

// Generate secure password hash
$password_hash = password_hash($password, PASSWORD_DEFAULT);

try {
    // Check if user already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    
    if ($stmt->rowCount() > 0) {
        // Update existing user
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, role = ?, email_verified = 1 WHERE username = ? OR email = ?");
        $stmt->execute([$password_hash, $role, $username, $email]);
        echo "Admin user '$username' updated successfully!\n";
    } else {
        // Create new user
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role, email_verified) VALUES (?, ?, ?, ?, 1)");
        $stmt->execute([$username, $email, $password_hash, $role]);
        echo "Admin user '$username' created successfully!\n";
    }
    
    echo "Login credentials:\n";
    echo "Username: $username\n";
    echo "Password: [password you provided]\n";
    echo "Email: $email\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
