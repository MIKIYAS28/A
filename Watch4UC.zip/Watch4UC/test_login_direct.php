<?php
session_start();

// Include config
require_once 'config.php';

// Test database connection
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $userCount = $stmt->fetchColumn();
    echo "<h2>✅ Database Connection: OK ($userCount users in database)</h2>";
} catch (Exception $e) {
    echo "<h2>❌ Database Connection: Failed - " . $e->getMessage() . "</h2>";
}

// If form is submitted
if ($_POST['action'] === 'test_signup') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if (!$username || !$email || !$password) {
        echo "<div style='color:red;'>All fields required</div>";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            // Create user with email already verified for testing
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, balance, email_verified) VALUES (?, ?, ?, 0, 1)");
            $stmt->execute([$username, $email, $hash]);
            echo "<div style='color:green;'>✅ Test User Created Successfully! (Email verification bypassed for testing)</div>";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate') !== false) {
                echo "<div style='color:orange;'>User already exists</div>";
            } else {
                echo "<div style='color:red;'>Error: " . $e->getMessage() . "</div>";
            }
        }
    }
}

if ($_POST['action'] === 'test_login') {
    $email = trim($_POST['login_email']);
    $password = $_POST['login_password'];
    
    if (!$email || !$password) {
        echo "<div style='color:red;'>Email and password required</div>";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, username, role, password_hash, email_verified FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($password, $user['password_hash'])) {
                echo "<div style='color:red;'>❌ Invalid credentials</div>";
            } else {
                if (!$user['email_verified']) {
                    echo "<div style='color:orange;'>⚠️ Email not verified (in production, this would block login)</div>";
                }
                
                // Set session
                $_SESSION['uid'] = $user['id'];
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                echo "<div style='color:green;'>✅ Login Successful!</div>";
                echo "<div>Welcome, " . htmlspecialchars($user['username']) . "!</div>";
                echo "<div>Role: " . htmlspecialchars($user['role']) . "</div>";
                echo "<div><a href='users/Dashboard.html'>Go to Dashboard</a></div>";
                
                if ($user['role'] === 'admin') {
                    echo "<div><a href='admin/users.html'>Go to Admin Panel</a></div>";
                }
            }
        } catch (PDOException $e) {
            echo "<div style='color:red;'>Database error: " . $e->getMessage() . "</div>";
        }
    }
}

// List existing users
try {
    $stmt = $pdo->query("SELECT username, email, email_verified, role FROM users ORDER BY id DESC LIMIT 10");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $users = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watch4UC - Direct Login Test</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .section { margin: 30px 0; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        .form-group { margin: 15px 0; }
        input { padding: 10px; margin: 5px; border: 1px solid #ddd; border-radius: 4px; }
        button { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .status-verified { color: green; font-weight: bold; }
        .status-unverified { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h1>🧪 Watch4UC Direct Login Test</h1>
    
    <div class="section">
        <h3>📝 Create Test User (Email Verification Bypassed)</h3>
        <form method="POST">
            <input type="hidden" name="action" value="test_signup">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Create Test User</button>
            </div>
        </form>
    </div>

    <div class="section">
        <h3>🔐 Test Login</h3>
        <form method="POST">
            <input type="hidden" name="action" value="test_login">
            <div class="form-group">
                <input type="email" name="login_email" placeholder="Email" required>
                <input type="password" name="login_password" placeholder="Password" required>
                <button type="submit">Test Login</button>
            </div>
        </form>
    </div>

    <div class="section">
        <h3>👥 Existing Users (Last 10)</h3>
        <?php if (empty($users)): ?>
            <p>No users found.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Email Verified</th>
                    <th>Role</th>
                </tr>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td class="<?= $user['email_verified'] ? 'status-verified' : 'status-unverified' ?>">
                            <?= $user['email_verified'] ? '✅ Verified' : '❌ Not Verified' ?>
                        </td>
                        <td><?= htmlspecialchars($user['role']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <div class="section">
        <h3>🔗 Navigation Links</h3>
        <p><a href="login.html">Main Login Page</a></p>
        <p><a href="users/Dashboard.html">User Dashboard</a></p>
        <p><a href="admin/users.html">Admin Panel</a></p>
        <p><a href="test_complete_flow.php">Complete Flow Test</a></p>
    </div>

    <?php if (isset($_SESSION['username'])): ?>
        <div class="section" style="background-color: #e8f5e8;">
            <h3>🎉 Currently Logged In</h3>
            <p>Username: <?= htmlspecialchars($_SESSION['username']) ?></p>
            <p>Role: <?= htmlspecialchars($_SESSION['role'] ?? 'user') ?></p>
            <p><a href="auth/logout.php">Logout</a></p>
        </div>
    <?php endif; ?>
</body>
</html>
