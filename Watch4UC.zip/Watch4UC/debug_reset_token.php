<?php
echo "<h2>🔍 Password Reset Token Debug</h2>";

require_once 'config.php';

$token = $_GET['token'] ?? '';

if (empty($token)) {
    echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ No Token Provided</h3>";
    echo "<p>Please provide a token in the URL like: ?token=your_token_here</p>";
    echo "</div>";
    
    // Show recent reset tokens for debugging
    try {
        echo "<h3>Recent Password Reset Tokens in Database:</h3>";
        $stmt = $pdo->query("SELECT id, username, email, password_reset_token, password_reset_expires, 
                            CASE WHEN password_reset_expires > NOW() THEN 'Valid' ELSE 'Expired' END as status
                            FROM users 
                            WHERE password_reset_token IS NOT NULL 
                            ORDER BY password_reset_expires DESC 
                            LIMIT 10");
        $tokens = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($tokens)) {
            echo "<p>No password reset tokens found in database.</p>";
        } else {
            echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
            echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Token (first 20 chars)</th><th>Expires</th><th>Status</th></tr>";
            
            foreach ($tokens as $tokenData) {
                $tokenPreview = substr($tokenData['password_reset_token'], 0, 20) . '...';
                $status = $tokenData['status'];
                $statusColor = $status === 'Valid' ? 'green' : 'red';
                
                echo "<tr>";
                echo "<td>" . $tokenData['id'] . "</td>";
                echo "<td>" . htmlspecialchars($tokenData['username']) . "</td>";
                echo "<td>" . htmlspecialchars($tokenData['email']) . "</td>";
                echo "<td><code>" . $tokenPreview . "</code></td>";
                echo "<td>" . $tokenData['password_reset_expires'] . "</td>";
                echo "<td style='color: $statusColor;'><strong>$status</strong></td>";
                echo "</tr>";
            }
            echo "</table>";
            
            echo "<p><strong>Current Server Time:</strong> " . date('Y-m-d H:i:s') . "</p>";
        }
    } catch (Exception $e) {
        echo "<div style='color: red;'>Database Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
} else {
    echo "<h3>🔍 Token Validation Test</h3>";
    echo "<p><strong>Token:</strong> <code>" . htmlspecialchars($token) . "</code></p>";
    echo "<p><strong>Token Length:</strong> " . strlen($token) . " characters</p>";
    
    try {
        // Test the exact same query that reset_password.php uses
        $stmt = $pdo->prepare("SELECT id, username, email, password_reset_expires FROM users WHERE password_reset_token = ?");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
            echo "<h4>❌ Token Not Found</h4>";
            echo "<p>No user found with this reset token in the database.</p>";
            echo "</div>";
            
            // Check if token exists but with different case or whitespace
            $stmt = $pdo->prepare("SELECT id, username, email, password_reset_token, password_reset_expires FROM users WHERE password_reset_token LIKE ?");
            $stmt->execute(['%' . $token . '%']);
            $similarTokens = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($similarTokens)) {
                echo "<h4>🔍 Similar Tokens Found:</h4>";
                echo "<table border='1' cellpadding='5'>";
                echo "<tr><th>Username</th><th>Email</th><th>Stored Token</th><th>Match?</th></tr>";
                foreach ($similarTokens as $similar) {
                    $match = ($similar['password_reset_token'] === $token) ? 'Exact' : 'Different';
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($similar['username']) . "</td>";
                    echo "<td>" . htmlspecialchars($similar['email']) . "</td>";
                    echo "<td><code>" . htmlspecialchars($similar['password_reset_token']) . "</code></td>";
                    echo "<td>" . $match . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            
        } else {
            echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
            echo "<h4>✅ Token Found!</h4>";
            echo "<p><strong>User:</strong> " . htmlspecialchars($user['username']) . "</p>";
            echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
            echo "<p><strong>Expires:</strong> " . $user['password_reset_expires'] . "</p>";
            echo "<p><strong>Current Time:</strong> " . date('Y-m-d H:i:s') . "</p>";
            echo "</div>";
            
            // Check if token is expired
            if ($user['password_reset_expires'] && strtotime($user['password_reset_expires']) < time()) {
                echo "<div style='color: orange; background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
                echo "<h4>⏰ Token is Expired</h4>";
                echo "<p>The token was found but has expired.</p>";
                $expiredMinutes = floor((time() - strtotime($user['password_reset_expires'])) / 60);
                echo "<p><strong>Expired:</strong> $expiredMinutes minutes ago</p>";
                echo "</div>";
            } else {
                echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
                echo "<h4>✅ Token is Valid and Not Expired</h4>";
                $remainingMinutes = floor((strtotime($user['password_reset_expires']) - time()) / 60);
                echo "<p><strong>Valid for:</strong> $remainingMinutes more minutes</p>";
                echo "</div>";
                
                // Test the reset password page
                echo "<h4>🧪 Test Reset Password Page:</h4>";
                echo "<p><a href='reset_password.php?token=" . urlencode($token) . "' target='_blank'>🔗 Open Reset Password Page</a></p>";
            }
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
        echo "<h4>❌ Database Error</h4>";
        echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "</div>";
    }
}

echo "<hr>";
echo "<h3>🔧 Debugging Tips:</h3>";
echo "<ul>";
echo "<li>Copy the reset token from your email and add it to this URL: <code>?token=YOUR_TOKEN_HERE</code></li>";
echo "<li>Check if the token exists in the database</li>";
echo "<li>Verify the token hasn't expired (tokens expire after 1 hour)</li>";
echo "<li>Make sure there are no extra spaces or characters in the token</li>";
echo "</ul>";

echo "<p><strong>Links:</strong></p>";
echo "<ul>";
echo "<li><a href='check_password_reset.php'>🔐 Password Reset Database Check</a></li>";
echo "<li><a href='login.html'>🔗 Login Page</a></li>";
echo "<li><a href='setup_email.php'>📧 Email Setup</a></li>";
echo "</ul>";
?>
