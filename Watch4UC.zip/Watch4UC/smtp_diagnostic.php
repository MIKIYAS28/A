<?php
// SMTP Diagnostic Tool - Detailed debugging for email issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 SMTP Diagnostic Tool</h1>";
echo "<style>body{font-family:Arial,sans-serif;max-width:900px;margin:20px auto;padding:20px;}
.success{color:#059669;background:#d1fae5;padding:10px;border-radius:5px;margin:10px 0;}
.error{color:#dc2626;background:#fee2e2;padding:10px;border-radius:5px;margin:10px 0;}
.warning{color:#d97706;background:#fef3c7;padding:10px;border-radius:5px;margin:10px 0;}
.info{color:#2563eb;background:#dbeafe;padding:10px;border-radius:5px;margin:10px 0;}
pre{background:#f3f4f6;padding:15px;border-radius:5px;overflow-x:auto;}
</style>";

// Step 1: Check if configuration file exists and is readable
echo "<h2>📁 Step 1: Configuration File Check</h2>";
$configFile = __DIR__ . '/includes/email_config.php';
if (file_exists($configFile)) {
    echo "<div class='success'>✅ email_config.php found</div>";
    if (is_readable($configFile)) {
        echo "<div class='success'>✅ email_config.php is readable</div>";
        require_once $configFile;
    } else {
        echo "<div class='error'>❌ email_config.php is not readable - check file permissions</div>";
        exit;
    }
} else {
    echo "<div class='error'>❌ email_config.php not found at: $configFile</div>";
    exit;
}

// Step 2: Display current configuration (with masked password)
echo "<h2>⚙️ Step 2: Current SMTP Configuration</h2>";
echo "<div class='info'>";
echo "<strong>SMTP Host:</strong> " . SMTP_HOST . "<br>";
echo "<strong>SMTP Port:</strong> " . SMTP_PORT . "<br>";
echo "<strong>SMTP Security:</strong> " . SMTP_SECURE . "<br>";
echo "<strong>Username:</strong> " . SMTP_USERNAME . "<br>";
echo "<strong>Password:</strong> " . str_repeat('*', strlen(SMTP_PASSWORD)) . " (length: " . strlen(SMTP_PASSWORD) . " chars)<br>";
echo "<strong>From Email:</strong> " . FROM_EMAIL . "<br>";
echo "<strong>From Name:</strong> " . FROM_NAME . "<br>";
echo "<strong>Site Name:</strong> " . SITE_NAME . "<br>";
echo "<strong>Site URL:</strong> " . SITE_URL . "<br>";
echo "</div>";

// Step 3: Check PHPMailer files
echo "<h2>📚 Step 3: PHPMailer Files Check</h2>";
$phpmailerFiles = [
    __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/PHPMailer.php',
    __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/SMTP.php',
    __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/Exception.php'
];

foreach ($phpmailerFiles as $file) {
    if (file_exists($file)) {
        echo "<div class='success'>✅ " . basename($file) . " found</div>";
    } else {
        echo "<div class='error'>❌ " . basename($file) . " not found at: $file</div>";
    }
}

// Step 4: Test basic PHPMailer loading
echo "<h2>🔧 Step 4: PHPMailer Loading Test</h2>";
try {
    require_once __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
    require_once __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/SMTP.php';
    require_once __DIR__ . '/includes/PHPMailer-master/PHPMailer-master/src/Exception.php';
    
    echo "<div class='success'>✅ PHPMailer classes loaded successfully</div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ Failed to load PHPMailer: " . $e->getMessage() . "</div>";
    exit;
}

// Step 5: Test SMTP Connection
echo "<h2>🌐 Step 5: SMTP Connection Test</h2>";
$mail = new PHPMailer\PHPMailer\PHPMailer(true);

try {
    // Enable verbose debug output
    $mail->SMTPDebug = 2;
    $mail->Debugoutput = function($str, $level) {
        echo "<pre style='margin:5px 0;padding:5px;background:#f9f9f9;border-left:3px solid #ddd;'>$str</pre>";
    };
    
    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME;
    $mail->Password = SMTP_PASSWORD;
    $mail->SMTPSecure = SMTP_SECURE;
    $mail->Port = SMTP_PORT;
    $mail->Timeout = 30;
    
    // Test connection
    echo "<div class='info'>🔄 Testing SMTP connection...</div>";
    
    if ($mail->smtpConnect()) {
        echo "<div class='success'>✅ SMTP connection successful!</div>";
        $mail->smtpClose();
    } else {
        echo "<div class='error'>❌ SMTP connection failed</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>❌ SMTP Connection Error: " . $e->getMessage() . "</div>";
}

// Step 6: Test Email Sending (if form submitted)
if ($_POST['test_email'] ?? false) {
    echo "<h2>📧 Step 6: Email Sending Test</h2>";
    
    $testEmail = $_POST['email'] ?? '';
    if (!$testEmail || !filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
        echo "<div class='error'>❌ Invalid email address provided</div>";
    } else {
        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            
            // Server settings (with less verbose debugging for actual send)
            $mail->SMTPDebug = 1;
            $mail->Debugoutput = function($str, $level) {
                echo "<pre style='margin:2px 0;padding:3px;background:#f9f9f9;font-size:12px;'>$str</pre>";
            };
            
            $mail->isSMTP();
            $mail->Host = SMTP_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USERNAME;
            $mail->Password = SMTP_PASSWORD;
            $mail->SMTPSecure = SMTP_SECURE;
            $mail->Port = SMTP_PORT;
            
            // Recipients
            $mail->setFrom(FROM_EMAIL, FROM_NAME);
            $mail->addAddress($testEmail, 'Test User');
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = 'SMTP Test Email - ' . date('Y-m-d H:i:s');
            $mail->Body = '
            <h2>🎉 SMTP Test Successful!</h2>
            <p>This is a test email to verify your SMTP configuration is working correctly.</p>
            <p><strong>Sent at:</strong> ' . date('Y-m-d H:i:s') . '</p>
            <p><strong>From:</strong> ' . FROM_EMAIL . '</p>
            <p><strong>SMTP Host:</strong> ' . SMTP_HOST . '</p>
            <p>If you received this email, your Watch4UC email system is working perfectly! 🚀</p>';
            
            $mail->AltBody = 'SMTP Test Successful! This is a test email sent at ' . date('Y-m-d H:i:s') . ' from ' . FROM_EMAIL;
            
            if ($mail->send()) {
                echo "<div class='success'>✅ Test email sent successfully to: $testEmail</div>";
                echo "<div class='info'>📬 Check your inbox (and spam folder) for the test email</div>";
            } else {
                echo "<div class='error'>❌ Failed to send test email</div>";
            }
            
        } catch (Exception $e) {
            echo "<div class='error'>❌ Email sending failed: " . $e->getMessage() . "</div>";
        }
    }
}

// Step 7: PHP Configuration Check
echo "<h2>🐘 Step 7: PHP Configuration Check</h2>";
echo "<div class='info'>";
echo "<strong>PHP Version:</strong> " . phpversion() . "<br>";
echo "<strong>OpenSSL:</strong> " . (extension_loaded('openssl') ? '✅ Enabled' : '❌ Disabled') . "<br>";
echo "<strong>Socket:</strong> " . (extension_loaded('sockets') ? '✅ Enabled' : '❌ Disabled') . "<br>";
echo "<strong>CURL:</strong> " . (extension_loaded('curl') ? '✅ Enabled' : '❌ Disabled') . "<br>";
echo "<strong>Allow URL fopen:</strong> " . (ini_get('allow_url_fopen') ? '✅ Enabled' : '❌ Disabled') . "<br>";
echo "</div>";

// Step 8: Common Issues and Solutions
echo "<h2>🛠️ Step 8: Common Issues and Solutions</h2>";
echo "<div class='warning'>";
echo "<h3>If you're seeing connection errors:</h3>";
echo "<ul>";
echo "<li><strong>Gmail App Password:</strong> Make sure you're using the 16-character App Password, not your regular Gmail password</li>";
echo "<li><strong>2-Factor Authentication:</strong> Must be enabled on your Gmail account before generating App Password</li>";
echo "<li><strong>Firewall:</strong> Check if your firewall is blocking outgoing connections on port 587</li>";
echo "<li><strong>Antivirus:</strong> Some antivirus software blocks SMTP connections</li>";
echo "<li><strong>ISP Blocking:</strong> Some ISPs block outgoing SMTP connections</li>";
echo "</ul>";

echo "<h3>Alternative Gmail Settings to Try:</h3>";
echo "<ul>";
echo "<li><strong>Port 465 with SSL:</strong> Try changing SMTP_PORT to 465 and SMTP_SECURE to 'ssl'</li>";
echo "<li><strong>Port 25:</strong> Some servers only allow port 25 (though less secure)</li>";
echo "</ul>";
echo "</div>";
?>

<!DOCTYPE html>
<html>
<head>
    <title>SMTP Diagnostic Tool</title>
</head>
<body>
    <hr>
    <h2>🧪 Test Email Sending</h2>
    <form method="POST">
        <p>Enter your email address to test sending:</p>
        <input type="email" name="email" placeholder="your-email@example.com" required style="width: 300px; padding: 10px; margin: 5px;">
        <input type="hidden" name="test_email" value="1">
        <br>
        <button type="submit" style="background: #059669; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Send Test Email</button>
    </form>
    
    <hr>
    <h2>📋 Quick Fixes to Try:</h2>
    <ol>
        <li><strong>Double-check Gmail App Password:</strong> Make sure it's exactly 16 characters with no spaces</li>
        <li><strong>Try Port 465 + SSL:</strong> Some networks prefer this configuration</li>
        <li><strong>Check Gmail Settings:</strong> Go to Gmail → Settings → Forwarding and POP/IMAP → Enable IMAP</li>
        <li><strong>Disable Antivirus Email Protection:</strong> Temporarily disable to test</li>
        <li><strong>Try Different Network:</strong> Test on mobile hotspot to check if ISP is blocking</li>
    </ol>
</body>
</html>
