<?php
echo "<h2>🔐 Password Reset Database Check</h2>";

require_once 'config.php';

try {
    // Get current table structure
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $columnNames = array_column($columns, 'Field');
    $requiredColumns = ['password_reset_token', 'password_reset_expires'];
    
    echo "<h3>Current Database Columns:</h3>";
    echo "<ul>";
    foreach ($columnNames as $column) {
        echo "<li>" . htmlspecialchars($column) . "</li>";
    }
    echo "</ul>";
    
    echo "<h3>Password Reset Columns Check:</h3>";
    $missingColumns = array_diff($requiredColumns, $columnNames);
    
    if (empty($missingColumns)) {
        echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
        echo "<h4>✅ All Required Columns Exist</h4>";
        echo "<p>Your database has all the required columns for password reset.</p>";
        echo "</div>";
    } else {
        echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
        echo "<h4>❌ Missing Required Columns</h4>";
        echo "<p><strong>Missing columns:</strong> " . implode(', ', $missingColumns) . "</p>";
        echo "<p>These columns are required for the password reset functionality to work.</p>";
        echo "</div>";
        
        echo "<h3>🔧 Fix Database Structure:</h3>";
        echo "<div style='background: #f5f5f5; padding: 15px; border-radius: 5px;'>";
        echo "<p>Click the button below to add the missing columns:</p>";
        echo "<form method='post'>";
        echo "<button type='submit' name='fix_db' style='padding: 10px 20px; background: #10b981; color: white; border: none; border-radius: 5px; cursor: pointer;'>🔧 Fix Database</button>";
        echo "</form>";
        echo "</div>";
    }
    
    // Handle database fix
    if (isset($_POST['fix_db'])) {
        echo "<h3>🔧 Adding Missing Columns...</h3>";
        
        try {
            foreach ($missingColumns as $column) {
                if ($column === 'password_reset_token') {
                    $pdo->query("ALTER TABLE users ADD COLUMN password_reset_token VARCHAR(64) NULL");
                    echo "<div style='color: green;'>✅ Added password_reset_token column</div>";
                } elseif ($column === 'password_reset_expires') {
                    $pdo->query("ALTER TABLE users ADD COLUMN password_reset_expires DATETIME NULL");
                    echo "<div style='color: green;'>✅ Added password_reset_expires column</div>";
                }
            }
            
            echo "<div style='color: green; background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
            echo "<h4>🎉 Database Fixed Successfully!</h4>";
            echo "<p>Password reset functionality should now work properly.</p>";
            echo "</div>";
            
            echo "<meta http-equiv='refresh' content='2'>";
            
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                echo "<div style='color: orange; background: #fff3cd; padding: 15px; border-radius: 5px;'>";
                echo "<h4>⚠️ Columns Already Exist</h4>";
                echo "<p>The required columns have already been added to your database.</p>";
                echo "</div>";
            } else {
                echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
                echo "<h4>❌ Error Adding Columns</h4>";
                echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
                echo "</div>";
            }
        }
    }
    
} catch (Exception $e) {
    echo "<div style='color: red; background: #ffebee; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Database Connection Error</h4>";
    echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<hr>";
echo "<h3>🧪 Test Password Reset:</h3>";
echo "<p>After fixing the database, test the password reset functionality:</p>";
echo "<ol>";
echo "<li><a href='login.html'>Go to Login Page</a></li>";
echo "<li>Click 'Forgot Password?'</li>";
echo "<li>Enter an email address of an existing user</li>";
echo "<li>Check if the reset email is sent</li>";
echo "</ol>";

echo "<p><strong>Links:</strong></p>";
echo "<ul>";
echo "<li><a href='login.html'>🔗 Login Page</a></li>";
echo "<li><a href='setup_email.php'>📧 Email Setup</a></li>";
echo "<li><a href='test_email_quick.php'>🧪 Test Email</a></li>";
echo "</ul>";
?>
