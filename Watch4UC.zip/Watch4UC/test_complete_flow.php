<?php
// Complete Flow Test Page
// This page helps you test the entire user registration and login system

session_start();

// Include required files
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/email_functions.php';

$current_user = null;
if (isset($_SESSION['uid'])) {
    try {
        $stmt = $pdo->prepare("SELECT username, email, role, email_verified FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['uid']]);
        $current_user = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Ignore for testing
    }
}

// Handle test actions
$result_message = '';
$result_type = '';

if ($_POST['action'] ?? '' === 'test_complete_signup') {
    try {
        $test_username = $_POST['test_username'] ?? 'TestUser';
        $test_email = $_POST['test_email'] ?? '';
        $test_password = $_POST['test_password'] ?? 'testpass123';
        
        if (!$test_email) {
            $result_message = 'Please provide a test email address';
            $result_type = 'error';
        } else {
            // Check if user already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$test_email]);
            if ($stmt->fetch()) {
                $result_message = "User with email $test_email already exists. Delete it first or use a different email.";
                $result_type = 'warning';
            } else {
                $result_message = "✅ Ready to test signup with: $test_email";
                $result_type = 'success';
            }
        }
    } catch (Exception $e) {
        $result_message = 'Error checking user: ' . $e->getMessage();
        $result_type = 'error';
    }
}

if ($_POST['action'] ?? '' === 'delete_test_user') {
    try {
        $test_email = $_POST['test_email'] ?? '';
        if ($test_email) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE email = ?");
            $stmt->execute([$test_email]);
            $result_message = "Test user with email $test_email has been deleted.";
            $result_type = 'success';
        }
    } catch (Exception $e) {
        $result_message = 'Error deleting user: ' . $e->getMessage();
        $result_type = 'error';
    }
}

if ($_POST['action'] ?? '' === 'check_email_config') {
    $config_status = [];
    
    // Check if email_config.php exists and has settings
    if (file_exists(__DIR__ . '/includes/email_config.php')) {
        $config_status[] = '✅ email_config.php exists';
        
        // Check if constants are defined
        if (defined('SMTP_HOST')) $config_status[] = '✅ SMTP_HOST: ' . SMTP_HOST;
        else $config_status[] = '❌ SMTP_HOST not defined';
        
        if (defined('SMTP_PORT')) $config_status[] = '✅ SMTP_PORT: ' . SMTP_PORT;
        else $config_status[] = '❌ SMTP_PORT not defined';
        
        if (defined('FROM_EMAIL')) $config_status[] = '✅ FROM_EMAIL: ' . FROM_EMAIL;
        else $config_status[] = '❌ FROM_EMAIL not defined';
        
        if (defined('SMTP_USERNAME') && SMTP_USERNAME !== 'your_email@gmail.com') {
            $config_status[] = '✅ SMTP_USERNAME configured';
        } else {
            $config_status[] = '⚠️ SMTP_USERNAME needs to be set';
        }
        
        if (defined('SMTP_PASSWORD') && SMTP_PASSWORD !== 'your_app_password') {
            $config_status[] = '✅ SMTP_PASSWORD configured';
        } else {
            $config_status[] = '⚠️ SMTP_PASSWORD needs to be set';
        }
        
    } else {
        $config_status[] = '❌ email_config.php not found';
    }
    
    // Check PHPMailer
    if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
        $config_status[] = '✅ PHPMailer is available';
    } else {
        $config_status[] = '❌ PHPMailer not found';
    }
    
    $result_message = implode('<br>', $config_status);
    $result_type = 'info';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Flow Test - Watch4UC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #357ABD;
            --success-color: #10B981;
            --error-color: #EF4444;
            --warning-color: #F59E0B;
            --info-color: #3B82F6;
        }
        
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: var(--secondary-color);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .content {
            padding: 40px;
        }
        
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .card {
            background: #f8fafc;
            border-radius: 15px;
            padding: 25px;
            border: 2px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            border-color: var(--primary-color);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .card h3 {
            color: var(--secondary-color);
            margin-bottom: 20px;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        .btn {
            background: var(--primary-color);
            color: #1f2937;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn:hover {
            background: #fbbf24;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: var(--secondary-color);
            color: white;
        }
        
        .btn-secondary:hover {
            background: #2563eb;
        }
        
        .btn-danger {
            background: var(--error-color);
            color: white;
        }
        
        .btn-danger:hover {
            background: #dc2626;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }
        
        .alert-warning {
            background: #fef3c7;
            color: #92400e;
            border: 1px solid #fde68a;
        }
        
        .alert-info {
            background: #dbeafe;
            color: #1e40af;
            border: 1px solid #93c5fd;
        }
        
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .status-item {
            background: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            border: 2px solid #e5e7eb;
        }
        
        .status-item.active {
            border-color: var(--success-color);
            background: #f0fdf4;
        }
        
        .flow-steps {
            background: #f8fafc;
            border-radius: 15px;
            padding: 30px;
            margin-top: 30px;
        }
        
        .step {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 10px;
            border-left: 4px solid var(--primary-color);
        }
        
        .step-number {
            background: var(--primary-color);
            color: #1f2937;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
        }
        
        .quick-links {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        
        .quick-link {
            padding: 10px 20px;
            background: var(--secondary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .quick-link:hover {
            background: #1e40af;
            transform: translateY(-2px);
        }
        
        @media (max-width: 768px) {
            .grid {
                grid-template-columns: 1fr;
            }
            
            .content {
                padding: 20px;
            }
            
            .header {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-flask"></i> Watch4UC Complete Flow Test</h1>
            <p>Test your complete user authentication system including emails, activation, and password reset</p>
        </div>
        
        <div class="content">
            <?php if ($result_message): ?>
                <div class="alert alert-<?php echo $result_type; ?>">
                    <i class="fas fa-info-circle"></i>
                    <?php echo $result_message; ?>
                </div>
            <?php endif; ?>
            
            <!-- Current Session Status -->
            <?php if ($current_user): ?>
                <div class="alert alert-success">
                    <i class="fas fa-user-check"></i>
                    <strong>Currently logged in as:</strong> <?php echo htmlspecialchars($current_user['username']); ?> 
                    (<?php echo htmlspecialchars($current_user['email']); ?>) - 
                    Role: <?php echo htmlspecialchars($current_user['role']); ?> - 
                    Email Verified: <?php echo $current_user['email_verified'] ? 'Yes' : 'No'; ?>
                    <br><br>
                    <a href="users/Dashboard.html" class="btn btn-secondary">
                        <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                    </a>
                    <a href="auth/logout.php" class="btn btn-danger" style="margin-left: 10px;">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            <?php endif; ?>
            
            <div class="grid">
                <!-- Email Configuration Check -->
                <div class="card">
                    <h3><i class="fas fa-envelope-open-text"></i> Email Configuration</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="check_email_config">
                        <p>Check if your email system is properly configured before testing.</p>
                        <br>
                        <button type="submit" class="btn">
                            <i class="fas fa-check"></i> Check Email Config
                        </button>
                    </form>
                </div>
                
                <!-- Test User Management -->
                <div class="card">
                    <h3><i class="fas fa-user-plus"></i> Test User Management</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="test_complete_signup">
                        <div class="form-group">
                            <label>Test Email Address:</label>
                            <input type="email" name="test_email" placeholder="test@example.com" required>
                        </div>
                        <div class="form-group">
                            <label>Test Username:</label>
                            <input type="text" name="test_username" value="TestUser">
                        </div>
                        <div class="form-group">
                            <label>Test Password:</label>
                            <input type="text" name="test_password" value="testpass123">
                        </div>
                        <button type="submit" class="btn">
                            <i class="fas fa-search"></i> Check Test User
                        </button>
                    </form>
                    
                    <hr style="margin: 20px 0;">
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="delete_test_user">
                        <div class="form-group">
                            <label>Delete Test User:</label>
                            <input type="email" name="test_email" placeholder="test@example.com" required>
                        </div>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete Test User
                        </button>
                    </form>
                </div>
                
                <!-- Direct Email Tests -->
                <div class="card">
                    <h3><i class="fas fa-paper-plane"></i> Direct Email Tests</h3>
                    <p>Test individual email functions directly:</p>
                    <div class="quick-links">
                        <a href="test_email.php" class="quick-link" target="_blank">
                            <i class="fas fa-envelope"></i> Email Test Suite
                        </a>
                        <a href="smtp_diagnostic.php" class="quick-link" target="_blank">
                            <i class="fas fa-stethoscope"></i> SMTP Diagnostic
                        </a>
                        <a href="simple_email_check.php" class="quick-link" target="_blank">
                            <i class="fas fa-check-circle"></i> Simple Email Check
                        </a>
                    </div>
                </div>
                
                <!-- Frontend Testing -->
                <div class="card">
                    <h3><i class="fas fa-desktop"></i> Frontend Testing</h3>
                    <p>Test your frontend forms and user interface:</p>
                    <div class="quick-links">
                        <a href="login.html" class="quick-link" target="_blank">
                            <i class="fas fa-sign-in-alt"></i> Login/Signup Page
                        </a>
                        <a href="users/Dashboard.html" class="quick-link" target="_blank">
                            <i class="fas fa-tachometer-alt"></i> User Dashboard
                        </a>
                        <a href="reset_password.php?token=test" class="quick-link" target="_blank">
                            <i class="fas fa-key"></i> Reset Password Page
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Complete Testing Flow -->
            <div class="flow-steps">
                <h2><i class="fas fa-list-ol"></i> Complete Testing Flow</h2>
                <p>Follow these steps to test your entire system:</p>
                
                <div class="step">
                    <div class="step-number">1</div>
                    <div>
                        <strong>Configure Email Settings</strong><br>
                        Update <code>includes/email_config.php</code> with your SMTP credentials (Gmail App Password recommended)
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">2</div>
                    <div>
                        <strong>Check Email Configuration</strong><br>
                        Use the "Check Email Config" button above to verify your settings
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">3</div>
                    <div>
                        <strong>Test Direct Email Sending</strong><br>
                        Visit <a href="test_email.php" target="_blank">test_email.php</a> to test all email types
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">4</div>
                    <div>
                        <strong>Test Frontend Signup</strong><br>
                        Go to <a href="login.html" target="_blank">login.html</a> and create a new account - check for activation email
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">5</div>
                    <div>
                        <strong>Activate Account</strong><br>
                        Click the activation link in your email - should redirect to success page
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">6</div>
                    <div>
                        <strong>Test Login</strong><br>
                        Login with your activated account - should send welcome back email and redirect to <code>users/Dashboard.html</code>
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">7</div>
                    <div>
                        <strong>Test Password Reset</strong><br>
                        Use "Forgot Password" on login page - check email and test reset link
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">8</div>
                    <div>
                        <strong>Verify Dashboard Access</strong><br>
                        Ensure successful login redirects to <code>/users/Dashboard.html</code> (not <code>/dashboard.html</code>)
                    </div>
                </div>
            </div>
            
            <!-- System Status -->
            <div class="flow-steps">
                <h2><i class="fas fa-server"></i> System Status Check</h2>
                <div class="status-grid">
                    <div class="status-item <?php echo file_exists(__DIR__ . '/config.php') ? 'active' : ''; ?>">
                        <i class="fas fa-database"></i><br>
                        Database Config<br>
                        <?php echo file_exists(__DIR__ . '/config.php') ? '✅ Ready' : '❌ Missing'; ?>
                    </div>
                    
                    <div class="status-item <?php echo file_exists(__DIR__ . '/includes/email_config.php') ? 'active' : ''; ?>">
                        <i class="fas fa-envelope"></i><br>
                        Email Config<br>
                        <?php echo file_exists(__DIR__ . '/includes/email_config.php') ? '✅ Present' : '❌ Missing'; ?>
                    </div>
                    
                    <div class="status-item <?php echo class_exists('PHPMailer\\PHPMailer\\PHPMailer') ? 'active' : ''; ?>">
                        <i class="fas fa-mail-bulk"></i><br>
                        PHPMailer<br>
                        <?php echo class_exists('PHPMailer\\PHPMailer\\PHPMailer') ? '✅ Loaded' : '❌ Missing'; ?>
                    </div>
                    
                    <div class="status-item <?php echo file_exists(__DIR__ . '/users/Dashboard.html') ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i><br>
                        User Dashboard<br>
                        <?php echo file_exists(__DIR__ . '/users/Dashboard.html') ? '✅ Exists' : '❌ Missing'; ?>
                    </div>
                    
                    <div class="status-item <?php echo file_exists(__DIR__ . '/login.html') ? 'active' : ''; ?>">
                        <i class="fas fa-sign-in-alt"></i><br>
                        Login Page<br>
                        <?php echo file_exists(__DIR__ . '/login.html') ? '✅ Ready' : '❌ Missing'; ?>
                    </div>
                    
                    <div class="status-item <?php echo file_exists(__DIR__ . '/auth/login.php') ? 'active' : ''; ?>">
                        <i class="fas fa-code"></i><br>
                        Auth Backend<br>
                        <?php echo file_exists(__DIR__ . '/auth/login.php') ? '✅ Ready' : '❌ Missing'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
