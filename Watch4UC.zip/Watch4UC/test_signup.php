<?php
echo "=== Testing Signup Functionality ===\n\n";

// Test 1: Test signup API directly
echo "1. Testing signup API with POST data...\n";

$test_username = 'testuser_' . time();
$test_email = 'test' . time() . '@example.com';
$test_password = 'testpass123';

// Simulate POST data
$_POST = [
    'username' => $test_username,
    'email' => $test_email,
    'password' => $test_password
];
$_SERVER['REQUEST_METHOD'] = 'POST';

ob_start();
try {
    include 'auth/signup.php';
    $output = ob_get_clean();
    
    echo "Signup response: " . $output . "\n";
    
    $json = json_decode($output, true);
    if ($json && isset($json['success']) && $json['success']) {
        echo "✓ Signup API working correctly\n";
        
        // Test if user was created in database
        require 'config.php';
        $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE email = ?");
        $stmt->execute([$test_email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo "✓ User created in database: " . $user['username'] . "\n";
            
            // Clean up test user
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user['id']]);
            echo "✓ Test user cleaned up\n";
        } else {
            echo "✗ User not found in database\n";
        }
    } else {
        echo "✗ Signup failed\n";
        if (isset($json['error'])) {
            echo "Error: " . $json['error'] . "\n";
        }
    }
} catch (Exception $e) {
    ob_get_clean();
    echo "✗ Exception during signup test: " . $e->getMessage() . "\n";
}

echo "\n=== Test Complete ===\n";
echo "If you see ✓ marks, signup should work from the web interface.\n";
echo "Try signing up at: http://localhost/Watch4UC/login.html\n";
?>
