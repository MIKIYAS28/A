<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/email_functions.php';

$error = '';
$success = '';
$email = '';

if ($_POST['email'] ?? false) {
    $email = trim($_POST['email']);
    
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } else {
        try {
            // Find user with this email who isn't verified yet
            $stmt = $pdo->prepare("
                SELECT id, username, email, email_verified 
                FROM users 
                WHERE email = ?
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                if ($user['email_verified']) {
                    $success = 'Your account is already activated! You can log in now.';
                } else {
                    // Generate new activation token
                    $activationToken = bin2hex(random_bytes(32));
                    $expiryTime = date('Y-m-d H:i:s', time() + 86400); // 24 hours
                    
                    // Update user with new token
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET email_verification_token = ?, email_verification_expires = ? 
                        WHERE id = ?
                    ");
                    $stmt->execute([$activationToken, $expiryTime, $user['id']]);
                    
                    // Send new activation email
                    try {
                        $emailSent = sendActivationEmail($email, $user['username'], $activationToken);
                        
                        if ($emailSent) {
                            $success = 'A new activation email has been sent to your email address. Please check your inbox (and spam folder).';
                        } else {
                            $error = 'Failed to send activation email. Please try again later or contact support.';
                        }
                    } catch (Exception $e) {
                        error_log("Failed to resend activation email to $email: " . $e->getMessage());
                        $error = 'Failed to send activation email. Please try again later.';
                    }
                }
            } else {
                // Don't reveal that email doesn't exist for security
                $success = 'If an account exists with this email address, an activation email has been sent.';
            }
        } catch (PDOException $e) {
            error_log("Database error in resend activation: " . $e->getMessage());
            $error = 'A database error occurred. Please try again later.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resend Activation Email - Watch4UC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #10b981;
            --secondary-color: #059669;
            --error-color: #ef4444;
            --background: #ffffff;
            --foreground: #111827;
            --gray: #e5e7eb;
            --gray-2: #6b7280;
        }

        html.dark {
            --background: #121212;
            --foreground: #ffffff;
            --gray: #333333;
            --gray-2: #aaaaaa;
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        body {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--foreground);
            padding: 20px;
        }

        .container {
            background: var(--background);
            padding: 2rem;
            border-radius: 1.5rem;
            box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
            width: 100%;
            max-width: 450px;
            text-align: center;
        }

        .logo {
            margin-bottom: 2rem;
        }

        .logo h1 {
            color: var(--primary-color);
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--foreground);
        }

        .input-group {
            position: relative;
            width: 100%;
        }

        .input-group i {
            position: absolute;
            top: 50%;
            left: 1rem;
            transform: translateY(-50%);
            font-size: 1.2rem;
            color: var(--gray-2);
        }

        .input-group input {
            width: 100%;
            padding: 1rem 3rem;
            font-size: 1rem;
            background-color: var(--gray);
            border-radius: 0.5rem;
            border: 0.125rem solid var(--gray);
            outline: none;
            color: var(--foreground);
            transition: border-color 0.3s ease;
        }

        .input-group input:focus {
            border-color: var(--primary-color);
        }

        .btn {
            cursor: pointer;
            width: 100%;
            border: none;
            padding: 1rem 0;
            border-radius: 0.5rem;
            font-size: 1.2rem;
            font-weight: 600;
            outline: none;
            transition: all 0.3s ease;
            margin: 10px 0;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--secondary-color);
        }

        .btn-secondary {
            background-color: var(--gray);
            color: var(--foreground);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn-secondary:hover {
            background-color: var(--gray-2);
            color: white;
        }

        .message {
            padding: 1rem;
            border-radius: 0.5rem;
            margin: 1rem 0;
            font-size: 1rem;
            line-height: 1.5;
        }

        .success-message {
            background: #d1fae5;
            color: #059669;
            border-left: 4px solid var(--primary-color);
        }

        .error-message {
            background: #fee2e2;
            color: #dc2626;
            border-left: 4px solid var(--error-color);
        }

        .info-box {
            background: #dbeafe;
            color: #2563eb;
            padding: 1rem;
            border-radius: 0.5rem;
            margin: 1rem 0;
            border-left: 4px solid #3b82f6;
            text-align: left;
        }

        .info-box h4 {
            margin-bottom: 0.5rem;
        }

        .info-box ul {
            margin-left: 1rem;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }

        .toggle {
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
            transition: transform 0.3s ease;
            width: 48px;
            height: 48px;
            position: relative;
        }

        .toggle .face {
            position: relative;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: var(--background);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toggle .face:before {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(-45deg, var(--primary-color), var(--secondary-color));
            opacity: 0.7;
        }

        .toggle svg {
            position: relative;
            width: 24px;
            height: 24px;
            z-index: 2;
            color: var(--foreground);
        }

        .hide {
            display: none;
        }
    </style>
</head>
<body>
    <div class="theme-toggle">
        <button aria-pressed="false" class="toggle" id="themeToggle">
            <div class="face">
                <svg id="darkIcon" class="hide" viewBox="0 0 24 24" fill="none">
                    <path d="M12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" fill="currentColor"/>
                </svg>
                <svg id="lightIcon" viewBox="0 0 24 24" fill="none">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" fill="currentColor"/>
                </svg>
            </div>
        </button>
    </div>

    <div class="container">
        <div class="logo">
            <h1>Watch4UC</h1>
            <p>Resend Activation Email</p>
        </div>

        <?php if ($success): ?>
            <div class="success-message message">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
            </div>
            
            <a href="login.html" class="btn btn-primary">
                <i class="fas fa-sign-in-alt"></i> Go to Login
            </a>
            
        <?php elseif ($error): ?>
            <div class="error-message message">
                <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if (!$success): ?>
            <div class="info-box">
                <h4>📧 Need a new activation email?</h4>
                <p>Enter your email address below to receive a new activation link.</p>
            </div>

            <form method="POST">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-group">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" 
                               value="<?php echo htmlspecialchars($email); ?>" 
                               placeholder="Enter your email address" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-paper-plane"></i> Send Activation Email
                </button>
            </form>

            <div class="info-box">
                <h4>💡 Tips:</h4>
                <ul>
                    <li>Check your spam/junk folder</li>
                    <li>Make sure you entered the correct email</li>
                    <li>Activation links expire after 24 hours</li>
                    <li>You can request a new link if the old one expired</li>
                </ul>
            </div>
        <?php endif; ?>

        <a href="login.html" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Login
        </a>
    </div>

    <script>
        // Theme toggle functionality
        const themeToggle = document.getElementById('themeToggle');
        const darkIcon = document.getElementById('darkIcon');
        const lightIcon = document.getElementById('lightIcon');
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

        if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
            document.documentElement.classList.add('dark');
            lightIcon.style.display = 'none';
            darkIcon.style.display = 'block';
        } else {
            document.documentElement.classList.remove('dark');
            lightIcon.style.display = 'block';
            darkIcon.style.display = 'none';
        }

        themeToggle.addEventListener('click', () => {
            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('theme', 'light');
                lightIcon.style.display = 'block';
                darkIcon.style.display = 'none';
            } else {
                document.documentElement.classList.add('dark');
                localStorage.setItem('theme', 'dark');
                lightIcon.style.display = 'none';
                darkIcon.style.display = 'block';
            }
        });

        // Auto redirect after successful email send
        <?php if ($success): ?>
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 3000);
        <?php endif; ?>
    </script>
</body>
</html>
