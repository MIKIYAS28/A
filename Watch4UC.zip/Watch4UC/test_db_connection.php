<?php
echo "Testing database connection...\n";

try {
    require_once 'config.php';
    echo "✅ Config loaded successfully\n";
    
    if (isset($pdo)) {
        echo "✅ PDO object exists\n";
        
        // Test query
        $stmt = $pdo->query("SELECT 1");
        echo "✅ Test query successful\n";
        
        // Check users table
        $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
        if ($stmt->fetch()) {
            echo "✅ Users table exists\n";
            
            // Show users table structure
            $stmt = $pdo->query("DESCRIBE users");
            echo "\nUsers table structure:\n";
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo sprintf("  %-20s %-20s %s\n", $row['Field'], $row['Type'], $row['Null']);
            }
            
            // Count users
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
            $count = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "\nTotal users: " . $count['count'] . "\n";
            
            // Check for test users
            $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE username IN (?, ?) OR email LIKE ?");
            $stmt->execute(['Mikiyas', 'Nahome', '%test%']);
            echo "\nTest users found:\n";
            while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "  ID: {$user['id']}, Username: {$user['username']}, Email: {$user['email']}\n";
            }
            
        } else {
            echo "❌ Users table NOT found\n";
            
            // List all tables
            $stmt = $pdo->query("SHOW TABLES");
            echo "\nAvailable tables:\n";
            while ($row = $stmt->fetch(PDO::FETCH_COLUMN)) {
                echo "  - $row\n";
            }
        }
        
    } else {
        echo "❌ PDO object not created\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
    echo "Error code: " . $e->getCode() . "\n";
} catch (Exception $e) {
    echo "❌ General error: " . $e->getMessage() . "\n";
}

// Check session
echo "\nSession status:\n";
if (session_status() === PHP_SESSION_NONE) {
    echo "  Session not started\n";
} else {
    echo "  Session is active\n";
    echo "  Session ID: " . session_id() . "\n";
}
?>
