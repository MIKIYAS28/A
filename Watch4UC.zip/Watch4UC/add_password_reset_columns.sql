-- Add password reset functionality columns to users table
-- Run this SQL command in your phpMyAdmin or MySQL client

ALTER TABLE users 
ADD COLUMN password_reset_token VARCHAR(64) NULL DEFAULT NULL,
ADD COLUMN password_reset_expires DATETIME NULL DEFAULT NULL;

-- Create index for faster password reset token lookups
CREATE INDEX idx_password_reset_token ON users(password_reset_token);

-- Optional: Clean up any existing expired tokens (run periodically)
-- UPDATE users SET password_reset_token = NULL, password_reset_expires = NULL WHERE password_reset_expires < NOW();
