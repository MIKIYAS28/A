<?php
require_once __DIR__ . '/PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/PHPMailer-master/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/email_config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

/**
 * Initialize PHPMailer with SMTP configuration
 * @return PHPMailer
 */
function createMailer() {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port       = SMTP_PORT;
        
        // Sender info
        $mail->setFrom(FROM_EMAIL, FROM_NAME);
        
        // Content settings
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        
        return $mail;
    } catch (Exception $e) {
        error_log("PHPMailer setup error: " . $e->getMessage());
        return null;
    }
}

/**
 * Send welcome email for new user signup
 * @param string $email User's email address
 * @param string $username User's username
 * @return bool Success status
 */
function sendWelcomeEmail($email, $username) {
    $mail = createMailer();
    if (!$mail) return false;
    
    try {
        $mail->addAddress($email, $username);
        $mail->Subject = 'Welcome to ' . SITE_NAME . '! 🎉';
        
        // HTML email template
        $htmlBody = getWelcomeEmailTemplate($username, 'signup');
        $mail->Body = $htmlBody;
        
        // Plain text alternative
        $mail->AltBody = getWelcomeEmailText($username, 'signup');
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Welcome email error: " . $e->getMessage());
        return false;
    }
}

/**
 * Send welcome back email for user login
 * @param string $email User's email address
 * @param string $username User's username
 * @return bool Success status
 */
function sendWelcomeBackEmail($email, $username) {
    $mail = createMailer();
    if (!$mail) return false;
    
    try {
        $mail->addAddress($email, $username);
        $mail->Subject = 'Welcome back to ' . SITE_NAME . '! 👋';
        
        // HTML email template
        $htmlBody = getWelcomeEmailTemplate($username, 'login');
        $mail->Body = $htmlBody;
        
        // Plain text alternative
        $mail->AltBody = getWelcomeEmailText($username, 'login');
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Welcome back email error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get HTML email template for welcome messages
 * @param string $username User's username
 * @param string $type 'signup' or 'login'
 * @return string HTML email content
 */
function getWelcomeEmailTemplate($username, $type = 'signup') {
    $isSignup = ($type === 'signup');
    $title = $isSignup ? 'Welcome to ' . SITE_NAME . '!' : 'Welcome Back!';
    $greeting = $isSignup ? 
        "We're thrilled to have you join our community!" : 
        "Great to see you again!";
    
    $mainMessage = $isSignup ? 
        "Your account has been successfully created. You can now start earning points by watching videos and completing daily tasks." :
        "You've successfully logged in. Don't forget to check out today's tasks and new videos!";
    
    $actionText = $isSignup ? "Get Started" : "View Dashboard";
    $actionUrl = SITE_URL . "/users/Dashboard.html";
    
    return "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>$title</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-align: center; padding: 30px; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .btn { display: inline-block; background: #667eea; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .btn:hover { background: #5a6fd8; }
            .features { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #667eea; }
            .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
            .emoji { font-size: 24px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>$title</h1>
                <p class='emoji'>" . ($isSignup ? "🎉✨" : "👋🌟") . "</p>
            </div>
            
            <div class='content'>
                <h2>Hi $username!</h2>
                <p>$greeting</p>
                <p>$mainMessage</p>
                
                <div class='features'>
                    <h3>What you can do:</h3>
                    <ul>
                        <li>🎬 Watch videos and earn points</li>
                        <li>✅ Complete daily tasks for bonus rewards</li>
                        <li>💰 Redeem your points for PUBG UC</li>
                        <li>🏆 Track your progress and earnings</li>
                    </ul>
                </div>
                
                <div style='text-align: center;'>
                    <a href='$actionUrl' class='btn'>$actionText</a>
                </div>
                
                <p>If you have any questions, feel free to reach out to our support team.</p>
                
                <p>Happy earning!<br>
                <strong>The " . SITE_NAME . " Team</strong></p>
            </div>
            
            <div class='footer'>
                <p>&copy; 2024 " . SITE_NAME . ". All rights reserved.</p>
                <p>This email was sent to $username because you " . ($isSignup ? "signed up for" : "logged into") . " our platform.</p>
            </div>
        </div>
    </body>
    </html>";
}

/**
 * Send password reset email
 * @param string $email User's email address
 * @param string $username User's username
 * @param string $resetToken Password reset token
 * @return bool Success status
 */
function sendPasswordResetEmail($email, $username, $resetToken) {
    $mail = createMailer();
    if (!$mail) return false;
    
    try {
        $mail->addAddress($email, $username);
        $mail->Subject = 'Password Reset Request - ' . SITE_NAME . ' 🔐';
        
        // HTML email template
        $htmlBody = getPasswordResetEmailTemplate($username, $resetToken);
        $mail->Body = $htmlBody;
        
        // Plain text alternative
        $mail->AltBody = getPasswordResetEmailText($username, $resetToken);
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Password reset email error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get HTML email template for password reset
 * @param string $username User's username
 * @param string $resetToken Password reset token
 * @return string HTML email content
 */
function getPasswordResetEmailTemplate($username, $resetToken) {
    $resetUrl = SITE_URL . "/reset_password.php?token=" . urlencode($resetToken);
    
    return "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Password Reset - " . SITE_NAME . "</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%); color: white; text-align: center; padding: 30px; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .btn { display: inline-block; background: #ff6b6b; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; font-weight: bold; }
            .btn:hover { background: #ee5a24; }
            .warning { background: #fff3cd; color: #856404; padding: 15px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #ffc107; }
            .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
            .emoji { font-size: 24px; }
            .code { background: #e9ecef; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 16px; text-align: center; margin: 15px 0; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Password Reset Request</h1>
                <p class='emoji'>🔐🔑</p>
            </div>
            
            <div class='content'>
                <h2>Hi $username!</h2>
                <p>We received a request to reset your password for your " . SITE_NAME . " account.</p>
                
                <div class='warning'>
                    <strong>⚠️ Important Security Notice:</strong><br>
                    If you didn't request this password reset, please ignore this email. Your account is still secure.
                </div>
                
                <p>To reset your password, click the button below:</p>
                
                <div style='text-align: center;'>
                    <a href='$resetUrl' class='btn'>Reset My Password</a>
                </div>
                
                <p><strong>Or copy and paste this link into your browser:</strong></p>
                <div class='code'>$resetUrl</div>
                
                <p><strong>This link will expire in 1 hour for security reasons.</strong></p>
                
                <p>If you continue to have problems, please contact our support team.</p>
                
                <p>Best regards,<br>
                <strong>The " . SITE_NAME . " Team</strong></p>
            </div>
            
            <div class='footer'>
                <p>&copy; 2024 " . SITE_NAME . ". All rights reserved.</p>
                <p>This email was sent because a password reset was requested for your account.</p>
            </div>
        </div>
    </body>
    </html>";
}

/**
 * Get plain text email content for password reset
 * @param string $username User's username
 * @param string $resetToken Password reset token
 * @return string Plain text email content
 */
function getPasswordResetEmailText($username, $resetToken) {
    $resetUrl = SITE_URL . "/reset_password.php?token=" . urlencode($resetToken);
    
    return "
Password Reset Request - " . SITE_NAME . "

Hi $username!

We received a request to reset your password for your " . SITE_NAME . " account.

⚠️ IMPORTANT: If you didn't request this password reset, please ignore this email. Your account is still secure.

To reset your password, visit this link:
$resetUrl

This link will expire in 1 hour for security reasons.

If you continue to have problems, please contact our support team.

Best regards,
The " . SITE_NAME . " Team

© 2024 " . SITE_NAME . ". All rights reserved.
This email was sent because a password reset was requested for your account.
    ";
}

/**
 * Send email activation email
 * @param string $email User's email address
 * @param string $username User's username
 * @param string $activationToken Email activation token
 * @return bool Success status
 */
function sendActivationEmail($email, $username, $activationToken) {
    if (!$activationToken) {
        error_log("Cannot send activation email: no token provided");
        return false;
    }
    
    $mail = createMailer();
    if (!$mail) return false;
    
    try {
        $mail->addAddress($email, $username);
        $mail->Subject = 'Activate Your Account - ' . SITE_NAME . ' 🎆';
        
        // HTML email template
        $htmlBody = getActivationEmailTemplate($username, $activationToken);
        $mail->Body = $htmlBody;
        
        // Plain text alternative
        $mail->AltBody = getActivationEmailText($username, $activationToken);
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Activation email error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get HTML email template for email activation
 * @param string $username User's username
 * @param string $activationToken Email activation token
 * @return string HTML email content
 */
function getActivationEmailTemplate($username, $activationToken) {
    $activationUrl = SITE_URL . "/activate_account.php?token=" . urlencode($activationToken);
    
    return "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Activate Your Account - " . SITE_NAME . "</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; text-align: center; padding: 30px; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .btn { display: inline-block; background: #10b981; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; font-weight: bold; }
            .btn:hover { background: #059669; }
            .warning { background: #fff3cd; color: #856404; padding: 15px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #ffc107; }
            .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
            .emoji { font-size: 24px; }
            .code { background: #e9ecef; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 16px; text-align: center; margin: 15px 0; }
            .features { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #10b981; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Welcome to " . SITE_NAME . "!</h1>
                <p class='emoji'>🎆✨</p>
            </div>
            
            <div class='content'>
                <h2>Hi $username!</h2>
                <p>Thank you for signing up for " . SITE_NAME . "! We're excited to have you join our community.</p>
                
                <div class='warning'>
                    <strong>📬 Important:</strong> To complete your registration and start earning points, please activate your account by clicking the button below.
                </div>
                
                <div style='text-align: center;'>
                    <a href='$activationUrl' class='btn'>Activate My Account</a>
                </div>
                
                <p><strong>Or copy and paste this link into your browser:</strong></p>
                <div class='code'>$activationUrl</div>
                
                <div class='features'>
                    <h3>Once activated, you can:</h3>
                    <ul>
                        <li>🎥 Watch videos and earn points</li>
                        <li>✅ Complete daily tasks for bonus rewards</li>
                        <li>💰 Redeem your points for PUBG UC</li>
                        <li>🏆 Track your progress and earnings</li>
                        <li>🎁 Participate in special promotions</li>
                    </ul>
                </div>
                
                <p><strong>This activation link will expire in 24 hours for security reasons.</strong></p>
                
                <p>If you didn't create this account, please ignore this email.</p>
                
                <p>Welcome to the community!<br>
                <strong>The " . SITE_NAME . " Team</strong></p>
            </div>
            
            <div class='footer'>
                <p>&copy; 2024 " . SITE_NAME . ". All rights reserved.</p>
                <p>This email was sent because you signed up for an account with us.</p>
            </div>
        </div>
    </body>
    </html>";
}

/**
 * Get plain text email content for email activation
 * @param string $username User's username
 * @param string $activationToken Email activation token
 * @return string Plain text email content
 */
function getActivationEmailText($username, $activationToken) {
    $activationUrl = SITE_URL . "/activate_account.php?token=" . urlencode($activationToken);
    
    return "
Welcome to " . SITE_NAME . "!

Hi $username!

Thank you for signing up for " . SITE_NAME . "! We're excited to have you join our community.

IMPORTANT: To complete your registration and start earning points, please activate your account by visiting this link:

$activationUrl

Once activated, you can:
- Watch videos and earn points
- Complete daily tasks for bonus rewards
- Redeem your points for PUBG UC
- Track your progress and earnings
- Participate in special promotions

This activation link will expire in 24 hours for security reasons.

If you didn't create this account, please ignore this email.

Welcome to the community!
The " . SITE_NAME . " Team

© 2024 " . SITE_NAME . ". All rights reserved.
This email was sent because you signed up for an account with us.
    ";
}

/**
 * Get plain text email content for welcome messages
 * @param string $username User's username
 * @param string $type 'signup' or 'login'
 * @return string Plain text email content
 */
function getWelcomeEmailText($username, $type = 'signup') {
    $isSignup = ($type === 'signup');
    $title = $isSignup ? 'Welcome to ' . SITE_NAME . '!' : 'Welcome Back!';
    $greeting = $isSignup ? 
        "We're thrilled to have you join our community!" : 
        "Great to see you again!";
    
    $mainMessage = $isSignup ? 
        "Your account has been successfully created. You can now start earning points by watching videos and completing daily tasks." :
        "You've successfully logged in. Don't forget to check out today's tasks and new videos!";
    
    $actionUrl = SITE_URL . "/users/Dashboard.html";
    
    return "
$title

Hi $username!

$greeting

$mainMessage

What you can do:
- Watch videos and earn points
- Complete daily tasks for bonus rewards
- Redeem your points for PUBG UC
- Track your progress and earnings

Visit your dashboard: $actionUrl

If you have any questions, feel free to reach out to our support team.

Happy earning!
The " . SITE_NAME . " Team

© 2024 " . SITE_NAME . ". All rights reserved.
This email was sent to $username because you " . ($isSignup ? "signed up for" : "logged into") . " our platform.
    ";
}
?>
