<?php
// Alternative Email Configuration Settings
// Copy the working configuration to email_config.php

// Gmail Configuration Option 1 (TLS - Most Common)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USERNAME', 'yourrealemail@gmail.com'); // Replace with your Gmail
define('SMTP_PASSWORD', 'tvmenidragkwmebr'); // Replace with your App Password

// Gmail Configuration Option 2 (SSL Alternative)
// define('SMTP_HOST', 'smtp.gmail.com');
// define('SMTP_PORT', 465);
// define('SMTP_SECURE', 'ssl');
// define('SMTP_USERNAME', 'yourrealemail@gmail.com');
// define('SMTP_PASSWORD', 'tvmenidragkwmebr');

// Gmail Configuration Option 3 (Less Secure - Port 25)
// define('SMTP_HOST', 'smtp.gmail.com');
// define('SMTP_PORT', 25);
// define('SMTP_SECURE', 'tls');
// define('SMTP_USERNAME', 'yourrealemail@gmail.com');
// define('SMTP_PASSWORD', 'tvmenidragkwmebr');

// From Email Settings - IMPORTANT: Use a valid email address
define('FROM_EMAIL', 'yourrealemail@gmail.com'); // Should match SMTP_USERNAME
define('FROM_NAME', 'Watch4UC Team');

// Site Information
define('SITE_NAME', 'Watch4UC');
define('SITE_URL', 'http://localhost/Watch4UC');

/*
TROUBLESHOOTING STEPS:

1. VERIFY GMAIL SETUP:
   - Go to https://myaccount.google.com
   - Security → 2-Step Verification → Make sure it's ON
   - Security → App passwords → Generate new password for "Mail"
   - Use the 16-character password (with no spaces)

2. COMMON ISSUES:
   - Using regular Gmail password instead of App Password
   - 2FA not enabled on Gmail account
   - Firewall blocking SMTP connections
   - Antivirus blocking email sending
   - ISP blocking SMTP ports

3. TEST DIFFERENT CONFIGURATIONS:
   - Try Port 465 with SSL instead of 587 with TLS
   - Try Port 25 if others don't work
   - Make sure FROM_EMAIL matches SMTP_USERNAME

4. GMAIL IMAP SETTING:
   - Go to Gmail → Settings → Forwarding and POP/IMAP
   - Make sure IMAP is enabled

5. NETWORK TROUBLESHOOTING:
   - Try from a different network (mobile hotspot)
   - Temporarily disable firewall/antivirus
   - Check if your ISP blocks SMTP

6. PHP REQUIREMENTS:
   - Make sure OpenSSL is enabled in PHP
   - Check if curl extension is loaded
*/
?>
