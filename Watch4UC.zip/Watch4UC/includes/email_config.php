<?php
// Email Configuration Settings
// Update these settings based on your email provider

define('SMTP_HOST', 'smtp.gmail.com'); // Change to your SMTP host
define('SMTP_PORT', 587); // Common ports: 587 (TLS), 465 (SSL), 25 (non-secure)
define('SMTP_SECURE', 'tls'); // 'tls' or 'ssl'
define('SMTP_USERNAME', 'mikiyasolana382@gmail.com'); // Your Gmail address
define('SMTP_PASSWORD', 'orat ojoy nvcx oshj'); // Your 16-character app password

// From Email Settings
define('FROM_EMAIL', 'mikiyasolana382@gmail.com'); // Sender email
define('FROM_NAME', 'Watch4UC MI'); // Sender name

// Site Information
define('SITE_NAME', 'Watch4UC');
define('SITE_URL', 'http://localhost/Watch4UC'); // Update with your domain

// Note: For Gmail, you need to:
// 1. Enable 2-factor authentication
// 2. Generate an App Password
// 3. Use the App Password instead of your regular password
// 4. Or use OAuth2 (more complex but more secure)

// For other providers like Yahoo, Outlook, etc., update the SMTP settings accordingly
?>
