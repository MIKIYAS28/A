<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$username = $_SESSION['username'] ?? 'Guest';
$rawPic = $_SESSION['profile_pic'] ?? '';

// Build a web-safe absolute path for the profile picture
$appBase = '/' . explode('/', trim($_SERVER['SCRIPT_NAME'], '/'))[0]; // e.g., /Watch4UC
if (!empty($rawPic)) {
    if (preg_match('/^https?:\/\//i', $rawPic)) {
        $profilePic = $rawPic; // already absolute URL
    } else {
        $profilePic = $appBase . '/' . ltrim($rawPic, '/'); // prefix app base for relative paths
    }
} else {
    // Friendly default avatar using initials
    $display = $username ?: 'User';
    $profilePic = 'https://ui-avatars.com/api/?name=' . urlencode($display) . '&background=FFD700&color=000';
}
?>
