<?php
// Test script to debug login and session issues

require_once 'config.php';

echo "<h2>Session Test After Login</h2>";

// Check if we have a session
if (!empty($_SESSION['uid'])) {
    echo "<div style='color: green;'>";
    echo "<h3>✓ Session Found</h3>";
    echo "<p><strong>User ID:</strong> " . $_SESSION['uid'] . "</p>";
    echo "<p><strong>Username:</strong> " . ($_SESSION['username'] ?? 'Not set') . "</p>";
    echo "<p><strong>Role:</strong> " . ($_SESSION['role'] ?? 'Not set') . "</p>";
    echo "</div>";
    
    // Test database connection
    try {
        $stmt = $pdo->prepare("SELECT username, role, joined_at, email FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['uid']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo "<div style='color: blue;'>";
            echo "<h3>✓ Database User Found</h3>";
            echo "<p><strong>Username:</strong> " . $user['username'] . "</p>";
            echo "<p><strong>Role:</strong> " . $user['role'] . "</p>";
            echo "<p><strong>Email:</strong> " . $user['email'] . "</p>";
            echo "<p><strong>Joined:</strong> " . $user['joined_at'] . "</p>";
            echo "</div>";
        } else {
            echo "<div style='color: red;'>";
            echo "<h3>✗ User Not Found in Database</h3>";
            echo "<p>Session has user ID " . $_SESSION['uid'] . " but no matching user in database</p>";
            echo "</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color: red;'>";
        echo "<h3>✗ Database Error</h3>";
        echo "<p>Error: " . $e->getMessage() . "</p>";
        echo "</div>";
    }
    
    // Test what me.php would return
    echo "<h3>Testing me.php endpoint</h3>";
    $meResponse = ['loggedIn' => false, 'role' => null];
    
    if (!empty($_SESSION['uid'])) {
        $stmt = $pdo->prepare("SELECT username, role, joined_at, balance FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['uid']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            $meResponse = [
                'loggedIn' => true,
                'role'     => $row['role'],
                'username' => $row['username'],
                'joined_at' => $row['joined_at'],
                'balance'  => $row['balance'] ?? 0,
                'profile_pic' => null
            ];
        }
    }
    
    echo "<div style='background: #f0f0f0; padding: 10px; border-radius: 5px;'>";
    echo "<h4>me.php would return:</h4>";
    echo "<pre>" . json_encode($meResponse, JSON_PRETTY_PRINT) . "</pre>";
    echo "</div>";
    
} else {
    echo "<div style='color: red;'>";
    echo "<h3>✗ No Session Found</h3>";
    echo "<p>Please log in first at <a href='login.html'>login.html</a></p>";
    echo "</div>";
}

echo "<hr>";
echo "<h3>Links for Testing</h3>";
echo "<p><a href='login.html'>Go to Login Page</a></p>";
echo "<p><a href='users/Dashboard.html'>Go to Dashboard</a></p>";
echo "<p><a href='debug_session.php'>View Session Debug Info</a></p>";
echo "<p><a href='auth/me.php'>Test me.php directly</a></p>";
?>
